<?php
/**
 * Plugin Name: Vite DOCX Bulk Draft Importer
 * Description: Imports blog drafts from a ZIP of DOCX files using a fixed SEO template with dry run + detailed logs.
 * Version: 1.0.0
 * Author: Vite SEO
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('vite_render_seo_tools_landing')) {
	function vite_render_seo_tools_landing(): void {
		echo '<div class="wrap"><h1>SEO Tools</h1><p>Use the submenu items to open each SEO tool.</p></div>';
	}
}

if (!function_exists('vite_register_seo_tools_menu')) {
	function vite_register_seo_tools_menu(): void {
		static $added = false;
		if ($added) {
			return;
		}

		add_menu_page(
			'SEO Tools',
			'SEO Tools',
			'edit_posts',
			'vite-seo-tools',
			'vite_render_seo_tools_landing',
			'dashicons-chart-area',
			58
		);

		$added = true;
	}
}

final class Vite_DOCX_Bulk_Draft_Importer {
	const PAGE_SLUG = 'vite-docx-bulk-draft-importer';
	const META_SEO_TITLE = 'vite_seo_title';
	const META_META_DESCRIPTION = 'vite_meta_description';
	const META_SCHEMA = 'vite_schema_jsonld';
	const META_IMPORT_MARKER = '_vite_docx_import_source';
	const DEFAULT_POLYLANG_LANG = 'en';
	const MAX_DOCX_FILES = 1000;
	const MAX_IMAGE_KB = 200;
	const WEBP_QUALITY_STEPS = [86, 82, 78, 74, 70];

	public static function init(): void {
		add_action('admin_menu', [__CLASS__, 'register_page']);
		add_action('admin_post_vite_docx_download_sample', [__CLASS__, 'handle_sample_download']);
	}

	public static function register_page(): void {
		vite_register_seo_tools_menu();
		add_submenu_page(
			'vite-seo-tools',
			'DOCX Bulk Draft Importer',
			'DOCX Bulk Draft Importer',
			'manage_options',
			self::PAGE_SLUG,
			[__CLASS__, 'render_page']
		);
	}

	public static function render_page(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}

		$requirements = self::read_requirements_from_request();
		$result = null;
		if (
			isset($_POST['vite_docx_import_action'], $_POST['vite_docx_import_nonce']) &&
			wp_verify_nonce((string) $_POST['vite_docx_import_nonce'], 'vite_docx_bulk_import')
		) {
			$action = sanitize_key((string) $_POST['vite_docx_import_action']);
			$mode = $action === 'apply' ? 'apply' : 'dry_run';
			$result = self::process_upload($mode, $requirements);
		}
		self::render_admin_styles();

		echo '<div class="wrap vite-docx-page">';
		echo '<div class="vite-docx-page__header">';
		echo '<h1 style="margin:0;">DOCX Bulk Draft Importer</h1>';
		echo '</div>';
		echo '<div class="vite-docx-card vite-docx-intro-card">';
		echo '<p>Upload a <code>.zip</code> that contains <code>.docx</code> files. This tool imports posts as <strong>draft</strong> using your SEO template labels.</p>';
		echo '<p><strong>Expected labels in each DOCX:</strong> <code>Title Tag:</code>, <code>Meta Description:</code>, <code>URL Slug:</code>, <code>H1 (Blog Title):</code>, optional <code>Lang:</code>, optional <code>Categories:</code>, optional <code>Tags:</code>, optional <code>Page Type:</code>, optional <code>Excerpt:</code>, optional <code>Featured Image:</code>, optional <code>Featured Image Alt:</code>, optional <code>Content Image Alt:</code>, optional <code>Schema:</code>, and <code>Body:</code>.</p>';
		echo '</div>';
		self::render_docs_modal();

		echo '<form method="post" enctype="multipart/form-data" class="vite-docx-card vite-docx-form-card">';
		wp_nonce_field('vite_docx_bulk_import', 'vite_docx_import_nonce');
		echo '<p><label for="vite_docx_zip_file"><strong>ZIP file</strong></label><br />';
		echo '<input class="vite-docx-file-input" type="file" id="vite_docx_zip_file" name="vite_docx_zip_file" accept=".zip,application/zip" required /></p>';
		echo '<fieldset class="vite-docx-validation-fieldset">';
		echo '<legend><strong>Validation Options</strong></legend>';
		echo '<p class="vite-docx-validation-list">';
		echo '<label><input type="checkbox" name="vite_docx_strict_labels" value="1" ' . checked($requirements['strict_labels'], true, false) . ' /> Strict label format (recommended): metadata labels must use <code>:</code></label><br />';
		echo '<label><input type="checkbox" name="vite_docx_require_title_tag" value="1" ' . checked($requirements['require_title_tag'], true, false) . ' /> Require <code>Title Tag</code></label><br />';
		echo '<label><input type="checkbox" name="vite_docx_require_meta_description" value="1" ' . checked($requirements['require_meta_description'], true, false) . ' /> Require <code>Meta Description</code></label><br />';
		echo '<label><input type="checkbox" name="vite_docx_require_h1" value="1" ' . checked($requirements['require_h1'], true, false) . ' /> Require explicit <code>H1 (Blog Title)</code> label</label><br />';
		echo '<label><input type="checkbox" name="vite_docx_require_body_label" value="1" ' . checked($requirements['require_body_label'], true, false) . ' /> Require explicit <code>Body</code> label</label><br />';
		echo '<label><input type="checkbox" name="vite_docx_allow_duplicate_slug_zip" value="1" ' . checked($requirements['allow_duplicate_slug_zip'], true, false) . ' /> Allow duplicate slug inside same ZIP (process all, last file wins)</label>';
		echo '</p>';
		echo '<p class="description" style="margin:0;">Slug and non-empty post content are always required. If labels are not required, importer will use smart fallbacks.</p>';
		echo '</fieldset>';
		echo '<p class="vite-docx-actions">';
		echo '<button type="submit" class="button button-secondary" name="vite_docx_import_action" value="dry_run">Dry Run (Preview Only)</button>';
		echo '<button type="submit" class="button button-primary" name="vite_docx_import_action" value="apply">Apply Import</button>';
		echo '<button type="button" class="button vite-docx-guide-btn" id="vite-docx-open-guide" aria-haspopup="dialog" aria-controls="vite-docx-guide-modal">Open Guide</button>';
		echo '</p>';
		echo '<p class="description">Dry Run validates files only. Apply Import creates/updates tool-managed draft posts and writes SEO meta.</p>';
		echo '</form>';

		if (is_array($result)) {
			self::render_result($result);
		}

		echo '</div>';
	}

	private static function render_admin_styles(): void {
		echo '<style>
		.vite-docx-page { max-width: none; width: 95%; }
		.vite-docx-page__header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom: 12px; flex-wrap: wrap; }
		.vite-docx-card { background:#fff; border:1px solid #dcdcde; border-radius: 10px; box-shadow: 0 1px 2px rgba(16,24,40,.04); padding: 16px 18px; margin: 0 0 14px; }
		.vite-docx-intro-card p { margin: 8px 0; font-size: 13.5px; line-height: 1.55; }
		.vite-docx-guide-btn { border-color:#dba617 !important; background:#ffe082 !important; color:#5f4500 !important; font-weight:600; }
		.vite-docx-guide-btn:hover, .vite-docx-guide-btn:focus { border-color:#c79312 !important; background:#ffd45a !important; color:#4f3900 !important; }
		.vite-docx-form-card label { line-height: 1.55; }
		.vite-docx-file-input { width: 100%; max-width: 540px; background:#fff; border:1px solid #8c8f94; border-radius: 7px; padding: 8px; }
		.vite-docx-validation-fieldset { margin: 14px 0; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 8px; background: #fcfcfd; }
		.vite-docx-validation-list { margin: 4px 0 8px; }
		.vite-docx-actions { display:flex; gap:10px; align-items:center; margin: 14px 0 8px; flex-wrap: wrap; }
		.vite-docx-actions .button { min-height: 34px; }
		.vite-docx-result-card { margin-top: 16px; }
		.vite-docx-summary-grid { display:grid; grid-template-columns: repeat(5, minmax(0,1fr)); gap: 10px; margin: 12px 0 4px; }
		.vite-docx-summary-item { border: 1px solid #dcdcde; border-radius: 8px; padding: 10px; background: #fff; }
		.vite-docx-summary-item__label { display:block; color:#50575e; font-size:12px; margin-bottom: 4px; }
		.vite-docx-summary-item__value { display:block; font-size:20px; line-height: 1.2; font-weight: 600; color:#1d2327; }
		.vite-docx-log-table th { font-weight: 600; }
		.vite-docx-status-pill { display:inline-block; border-radius:999px; padding:2px 10px; font-size:12px; font-weight:600; line-height:1.7; }
		.vite-docx-status-pill--success { background:#edfaef; color:#0f6f2e; }
		.vite-docx-status-pill--warn { background:#fff7e6; color:#8a5a00; }
		.vite-docx-status-pill--error { background:#fdecec; color:#9f2626; }
		.vite-docx-status-pill--neutral { background:#f0f0f1; color:#3c434a; }
		@media (max-width: 1100px) {
			.vite-docx-summary-grid { grid-template-columns: repeat(3, minmax(0,1fr)); }
		}
		@media (max-width: 782px) {
			.vite-docx-page__header { align-items:flex-start; }
			.vite-docx-summary-grid { grid-template-columns: repeat(2, minmax(0,1fr)); }
		}
		</style>';
	}

	private static function render_docs_modal(): void {
		echo '<style>
		#vite-docx-guide-modal[hidden] { display: none !important; }
		#vite-docx-guide-modal { position: fixed; inset: 0; z-index: 100000; background: rgba(0,0,0,.45); display: flex; align-items: center; justify-content: center; padding: 20px; }
		#vite-docx-guide-modal .vite-docx-guide__panel { width: min(980px, calc(100vw - 24px)); max-height: 86vh; overflow: auto; background: #fff; border-radius: 10px; box-shadow: 0 16px 38px rgba(0,0,0,.18); }
		#vite-docx-guide-modal .vite-docx-guide__header { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #dcdcde; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
		#vite-docx-guide-modal .vite-docx-guide__body { padding: 16px; }
		#vite-docx-guide-modal h3 { margin: 18px 0 8px; }
		#vite-docx-guide-modal p { margin: 8px 0; line-height: 1.5; }
		#vite-docx-guide-modal ul, #vite-docx-guide-modal ol { margin: 8px 0 10px 18px; }
		#vite-docx-guide-modal pre { background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 6px; padding: 10px; white-space: pre-wrap; word-break: break-word; }
		@media (max-width: 782px) {
			#vite-docx-guide-modal { padding: 10px; }
			#vite-docx-guide-modal .vite-docx-guide__header { padding: 10px 12px; }
			#vite-docx-guide-modal .vite-docx-guide__body { padding: 12px; }
		}
		</style>';

		echo '<div id="vite-docx-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="vite-docx-guide-title">';
		echo '<div class="vite-docx-guide__panel">';
		echo '<div class="vite-docx-guide__header">';
		echo '<strong id="vite-docx-guide-title">DOCX Importer Guide (Quick Help)</strong>';
		echo '<button type="button" class="button" id="vite-docx-close-guide" aria-label="Close guide">Close</button>';
		echo '</div>';
		echo '<div class="vite-docx-guide__body">';

		echo '<p>This tool helps content teams upload many blog drafts at once from a ZIP file of DOCX files. It is designed for non-technical users and SEO specialists.</p>';

		echo '<h3>What this plugin does</h3>';
		echo '<ul>';
		echo '<li>Reads one ZIP file that contains many <code>.docx</code> files.</li>';
		echo '<li>Creates or updates <strong>draft</strong> blog posts from those files.</li>';
		echo '<li>Saves SEO fields (SEO title, meta description, schema JSON-LD).</li>';
		echo '<li>Optionally sets Polylang language using <code>Lang:</code> (for example: <code>en</code>, <code>ko</code>, <code>ja</code>, <code>th</code>).</li>';
		echo '<li>If the same base slug appears in one ZIP with different languages, importer builds final slug by language (example: <code>post1</code> for EN/default, <code>post1-ko</code>, <code>post1-ja</code>).</li>';
		echo '<li>When <code>Body:</code> exists, importer treats it as the content section: first line becomes post title (if H1 label is missing), and lines below become post content.</li>';
		echo '<li><code>Schema:</code> value is saved to SEO schema meta only and is not inserted into post content.</li>';
		echo '<li>Optionally sets <code>Categories</code>, <code>Tags</code>, and Content Graph <code>Page Type</code> (<code>Glossary</code>, <code>Pillar</code>, <code>Hub</code>, <code>Section</code>).</li>';
		echo '<li>Embedded DOCX images are imported into Media Library during Apply Import.</li>';
		echo '<li><code>Featured Image:</code> supports image index override (for example <code>1</code>, <code>2</code>). If omitted, the first image before <code>Body:</code> is used as Featured Image when available.</li>';
		echo '<li><code>Featured Image Alt:</code> and <code>Content Image Alt:</code> support strict alt-text validation for imported images.</li>';
		echo '<li>Imported JPG/JPEG/PNG images are converted to WebP with performance target of up to 200KB when possible. GIF/SVG remain unchanged.</li>';
		echo '</ul>';

		echo '<h3>Required vs optional labels in each DOCX</h3>';
		echo '<p><strong>Required:</strong> <code>URL Slug</code> (or <code>Slug</code>/<code>URL</code>) and post body content.</p>';
		echo '<p><strong>Optional:</strong> <code>Title Tag</code>, <code>Meta Description</code>, <code>H1 (Blog Title)</code>, <code>Lang</code>, <code>Categories</code>, <code>Tags</code>, <code>Page Type</code>, <code>Excerpt</code>, <code>Featured Image</code>, <code>Featured Image Alt</code>, <code>Content Image Alt</code>, <code>Schema</code>, and <code>Body</code> label.</p>';
		echo '<p>If optional labels are missing, the importer tries smart fallbacks (unless your Validation Options require specific labels).</p>';

		echo '<h3>Step-by-step workflow</h3>';
		echo '<ol>';
		echo '<li>Prepare DOCX files (1 file = 1 blog post).</li>';
		echo '<li>Put all DOCX files into one ZIP.</li>';
		echo '<li>Upload ZIP and choose Validation Options.</li>';
		echo '<li>If you have same base slug with different languages, use <code>Lang:</code> (example <code>en</code>, <code>ko</code>, <code>ja</code>) so final slug is generated correctly.</li>';
		echo '<li>If your DOCX includes images, provide complete alt text labels (featured + all content images) before import.</li>';
		echo '<li>To force a specific featured image, set <code>Featured Image:</code> to the image position index (for example <code>1</code>).</li>';
		echo '<li>Run <strong>Dry Run</strong> first to preview what will happen.</li>';
		echo '<li>Fix any failed rows, then run <strong>Apply Import</strong>.</li>';
		echo '</ol>';

		echo '<h3>Simple DOCX example</h3>';
		$sample_url = wp_nonce_url(
			add_query_arg(['action' => 'vite_docx_download_sample'], admin_url('admin-post.php')),
			'vite_docx_download_sample'
		);
		echo '<p><a class="button button-secondary" href="' . esc_url($sample_url) . '">Download DOCX Sample</a></p>';
		echo '<pre>Title Tag: Example SEO Title
Meta Description: Example summary for search engines
URL Slug: example-blog-post
Lang: en
Categories: SEO
Tags: Bangkok, First Timer, Thailand
Page Type: Pillar
Excerpt: Short preview text (optional)
Featured Image: 1
Featured Image Alt: Main visual alt text
Content Image Alt: first body image alt, second body image alt
Schema: {"@context":"https://schema.org","@type":"BlogPosting","headline":"Example Blog Post Title"}
Body:
Example Blog Post Title
Insert your first image under this line in DOCX
Write your blog content here...</pre>';

		echo '<h3>Validation Options explained</h3>';
		echo '<ul>';
		echo '<li><strong>Strict label format:</strong> each metadata label must use <code>:</code> (recommended).</li>';
		echo '<li><strong>Require Title Tag:</strong> fail files that do not include <code>Title Tag</code>.</li>';
		echo '<li><strong>Require Meta Description:</strong> fail files that do not include <code>Meta Description</code>.</li>';
		echo '<li><strong>Require H1 label:</strong> fail files without explicit <code>H1 (Blog Title)</code>.</li>';
		echo '<li><strong>Require Body label:</strong> fail files without explicit <code>Body:</code> label.</li>';
		echo '<li><strong>Allow duplicate slug in ZIP:</strong> applies only when final slug is still the same after language suffix logic. If enabled, duplicates are processed in order and later file can overwrite earlier one.</li>';
		echo '</ul>';

		echo '<h3>How to read Dry Run and Detailed Log</h3>';
		echo '<ul>';
		echo '<li><strong>Would Import:</strong> file is valid and ready.</li>';
		echo '<li><strong>Imported:</strong> file was successfully saved (Apply Import only).</li>';
		echo '<li><strong>Skipped:</strong> intentionally ignored (for example duplicate slug or existing unmanaged post).</li>';
		echo '<li><strong>Failed:</strong> needs a fix in the DOCX file before import.</li>';
		echo '</ul>';

		echo '</div>';
		echo '</div>';
		echo '</div>';

		echo '<script>
		(function () {
			function initGuideModal() {
				var openBtn = document.getElementById("vite-docx-open-guide");
				var closeBtn = document.getElementById("vite-docx-close-guide");
				var modal = document.getElementById("vite-docx-guide-modal");
				if (!openBtn || !closeBtn || !modal) return;

				function openGuide() {
					modal.hidden = false;
					modal.setAttribute("aria-hidden", "false");
				}

				function closeGuide() {
					modal.hidden = true;
					modal.setAttribute("aria-hidden", "true");
				}

				openBtn.addEventListener("click", openGuide);
				closeBtn.addEventListener("click", closeGuide);
				modal.addEventListener("click", function (event) {
					if (event.target === modal) closeGuide();
				});
				document.addEventListener("keydown", function (event) {
					if (event.key === "Escape" && !modal.hidden) {
						closeGuide();
					}
				});
			}

			if (document.readyState === "loading") {
				document.addEventListener("DOMContentLoaded", initGuideModal);
			} else {
				initGuideModal();
			}
		})();
		</script>';
	}

	public static function handle_sample_download(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}
		check_admin_referer('vite_docx_download_sample');

		$docx = self::build_sample_docx_binary();
		if (!$docx['ok']) {
			wp_die(esc_html((string) $docx['message']));
		}

		$filename = 'vite-docx-import-sample.docx';
		nocache_headers();
		header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Content-Length: ' . strlen((string) $docx['binary']));
		echo (string) $docx['binary'];
		exit;
	}

	private static function build_sample_docx_binary(): array {
		if (!class_exists('ZipArchive')) {
			return ['ok' => false, 'message' => 'ZipArchive is required to generate DOCX sample.', 'binary' => ''];
		}

		$tmp = wp_tempnam('vite-docx-sample');
		if (!is_string($tmp) || $tmp === '') {
			return ['ok' => false, 'message' => 'Could not create temporary file for sample DOCX.', 'binary' => ''];
		}

		$zip = new ZipArchive();
		if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
			@unlink($tmp);
			return ['ok' => false, 'message' => 'Could not create sample DOCX package.', 'binary' => ''];
		}

		$lines = [
			'Title Tag: Example SEO Title',
			'Meta Description: Example summary for search engines',
			'URL Slug: example-blog-post',
			'Lang: en',
			'Categories: SEO',
			'Tags: Bangkok, First Timer, Thailand',
			'Page Type: Pillar',
			'Excerpt: Short preview text (optional)',
			'Featured Image: 1',
			'Featured Image Alt: Main visual alt text',
			'Content Image Alt: first body image alt, second body image alt',
			'Schema: {"@context":"https://schema.org","@type":"BlogPosting","headline":"Example Blog Post Title"}',
			'Body:',
			'Example Blog Post Title',
			'Insert your first image under this line in DOCX',
			'Write your blog content here...',
		];

		$paragraphs = '';
		foreach ($lines as $line) {
			$paragraphs .= '<w:p><w:r><w:t xml:space="preserve">' . esc_html($line) . '</w:t></w:r></w:p>';
		}

		$document_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
			. '<w:body>' . $paragraphs . '</w:body>'
			. '</w:document>';

		$zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
			. '</Types>');
		$zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
			. '</Relationships>');
		$zip->addFromString('word/document.xml', $document_xml);

		$zip->close();
		$binary = file_get_contents($tmp);
		@unlink($tmp);

		if (!is_string($binary) || $binary === '') {
			return ['ok' => false, 'message' => 'Could not read generated sample DOCX.', 'binary' => ''];
		}

		return ['ok' => true, 'message' => '', 'binary' => $binary];
	}

	private static function read_requirements_from_request(): array {
		return [
			'require_title_tag' => !empty($_POST['vite_docx_require_title_tag']),
			'require_meta_description' => !empty($_POST['vite_docx_require_meta_description']),
			'require_h1' => !empty($_POST['vite_docx_require_h1']),
			'require_body_label' => !empty($_POST['vite_docx_require_body_label']),
			'allow_duplicate_slug_zip' => !empty($_POST['vite_docx_allow_duplicate_slug_zip']),
			'strict_labels' => !isset($_POST['vite_docx_strict_labels']) ? true : !empty($_POST['vite_docx_strict_labels']),
		];
	}

	private static function process_upload(string $mode, array $requirements): array {
		$is_apply = $mode === 'apply';

		if (!class_exists('ZipArchive')) {
			return self::fatal_result('Server is missing ZIP support (ZipArchive). Please ask your developer/host to enable it.');
		}

		if (empty($_FILES['vite_docx_zip_file']) || !is_array($_FILES['vite_docx_zip_file'])) {
			return self::fatal_result('No ZIP file was uploaded.');
		}

		$file = $_FILES['vite_docx_zip_file'];
		$error_code = isset($file['error']) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
		if ($error_code !== UPLOAD_ERR_OK) {
			return self::fatal_result('Upload failed. Please try again and confirm the file is a valid ZIP.');
		}

		$tmp_name = isset($file['tmp_name']) ? (string) $file['tmp_name'] : '';
		if ($tmp_name === '' || !is_uploaded_file($tmp_name)) {
			return self::fatal_result('Uploaded file could not be verified.');
		}

		$zip = new ZipArchive();
		$open_result = $zip->open($tmp_name);
		if ($open_result !== true) {
			return self::fatal_result('Could not open ZIP file. Please upload a valid ZIP archive.');
		}

		$entries = [];
		for ($i = 0; $i < $zip->numFiles; $i++) {
			$name = (string) $zip->getNameIndex($i);
			if ($name === '' || substr($name, -1) === '/') {
				continue;
			}
			$lower = strtolower($name);
			if (strpos($lower, '__macosx/') === 0) {
				continue;
			}
			if (substr($lower, -5) === '.docx') {
				$entries[] = $name;
			}
		}

		if (empty($entries)) {
			$zip->close();
			return self::fatal_result('ZIP does not contain any .docx files.');
		}

		if (count($entries) > self::MAX_DOCX_FILES) {
			$zip->close();
			return self::fatal_result('ZIP contains too many DOCX files. Limit is ' . self::MAX_DOCX_FILES . ' files per upload.');
		}

		$summary = [
			'total_files' => 0,
			'would_import' => 0,
			'imported' => 0,
			'skipped' => 0,
			'failed' => 0,
		];
		$rows = [];
		$seen_slugs = [];

		foreach ($entries as $index => $entry_name) {
			$row_no = $index + 1;
			$summary['total_files']++;

			$docx_binary = $zip->getFromName($entry_name);
			if (!is_string($docx_binary) || $docx_binary === '') {
				$rows[] = self::log_row($row_no, $entry_name, '', '', 'Failed', 'Could not read this DOCX file from ZIP.');
				$summary['failed']++;
				continue;
			}

			$docx_info = self::extract_text_from_docx_binary($docx_binary);
			if (!$docx_info['ok']) {
				$rows[] = self::log_row($row_no, $entry_name, '', '', 'Failed', $docx_info['message']);
				$summary['failed']++;
				continue;
			}

			$parsed = self::parse_doc_template((string) $docx_info['text'], $requirements, (array) ($docx_info['blocks'] ?? []));
			if (!$parsed['ok']) {
				$rows[] = self::log_row($row_no, $entry_name, '', '', 'Failed', $parsed['message']);
				$summary['failed']++;
				continue;
			}

			$data = is_array($parsed['data']) ? $parsed['data'] : [];
			$docx_images = is_array($docx_info['images'] ?? null) ? $docx_info['images'] : [];
			$data['_docx_images'] = $docx_images;
			$image_validation = self::validate_docx_image_references($data, $docx_images);
			if (!$image_validation['ok']) {
				$rows[] = self::log_row($row_no, $entry_name, '', '', 'Failed', (string) $image_validation['message']);
				$summary['failed']++;
				continue;
			}
			$base_slug = sanitize_title((string) ($data['url_slug'] ?? ''));
			if ($base_slug === '') {
				$rows[] = self::log_row($row_no, $entry_name, '', '', 'Failed', 'URL Slug is missing or invalid.');
				$summary['failed']++;
				continue;
			}
			$lang_for_slug = self::normalize_language_code((string) ($data['language'] ?? ''));
			if ($lang_for_slug === '') {
				$lang_for_slug = self::DEFAULT_POLYLANG_LANG;
			}
			$slug = self::build_slug_for_language($base_slug, $lang_for_slug);
			if ($slug !== $base_slug) {
				$data['_notes'][] = 'Language-based slug applied: "' . $base_slug . '" -> "' . $slug . '"';
			}

			if (isset($seen_slugs[$slug])) {
				if (empty($requirements['allow_duplicate_slug_zip'])) {
					$rows[] = self::log_row($row_no, $entry_name, $slug, '', 'Skipped', 'Duplicate final slug found in this ZIP. Only the first file for each slug is processed.');
					$summary['skipped']++;
					continue;
				}
				$data['_notes'][] = 'Duplicate slug in ZIP allowed: this file may overwrite earlier file data for the same slug';
			}
			$seen_slugs[$slug] = true;

			$schema_raw = trim((string) ($data['schema'] ?? ''));
			$schema_json = '';
			if ($schema_raw !== '') {
				$schema_info = self::normalize_schema_json($schema_raw);
				if (!$schema_info['ok']) {
					$rows[] = self::log_row($row_no, $entry_name, $slug, '', 'Failed', $schema_info['message']);
					$summary['failed']++;
					continue;
				}
				$schema_json = (string) $schema_info['json'];
			}

			$existing = self::find_post_by_slug($slug);
			$post_label = '';
			$action_text = '';

			if ($existing instanceof WP_Post) {
				$post_label = sprintf('#%d - %s', (int) $existing->ID, get_the_title($existing->ID) ?: '(No title)');
				$managed = (string) get_post_meta((int) $existing->ID, self::META_IMPORT_MARKER, true);
				$is_managed = $managed !== '';

				if (!$is_managed) {
					$rows[] = self::log_row(
						$row_no,
						$entry_name,
						$slug,
						$post_label,
						'Skipped',
						'Slug already exists in a post not managed by this importer. Skipped to avoid overwriting existing content.'
					);
					$summary['skipped']++;
					continue;
				}

				$action_text = 'Update existing importer-managed draft post';
			} else {
				$action_text = 'Create new draft post';
			}

			if (!$is_apply) {
				$fallback_notes = !empty($data['_notes']) ? ' (' . implode('; ', (array) $data['_notes']) . ')' : '';
				$rows[] = self::log_row($row_no, $entry_name, $slug, $post_label, 'Would Import', $action_text . $fallback_notes . '.');
				$summary['would_import']++;
				continue;
			}

			$save_result = self::save_post_and_meta($existing, $data, $slug, $schema_json, $entry_name);
			if (!$save_result['ok']) {
				$rows[] = self::log_row($row_no, $entry_name, $slug, $post_label, 'Failed', (string) $save_result['message']);
				$summary['failed']++;
				continue;
			}

			$saved_id = (int) ($save_result['post_id'] ?? 0);
			$saved_label = $saved_id > 0 ? sprintf('#%d - %s', $saved_id, get_the_title($saved_id) ?: '(No title)') : $post_label;
			$fallback_notes = !empty($data['_notes']) ? ' (' . implode('; ', (array) $data['_notes']) . ')' : '';
			$save_note = trim((string) ($save_result['message'] ?? ''));
			$details = $action_text . $fallback_notes . ' completed.';
			if ($save_note !== '') {
				$details .= ' ' . $save_note;
			}
			$rows[] = self::log_row($row_no, $entry_name, $slug, $saved_label, 'Imported', $details);
			$summary['imported']++;
		}

		$zip->close();

		return [
			'ok' => true,
			'mode' => $is_apply ? 'apply' : 'dry_run',
			'requirements' => $requirements,
			'summary' => $summary,
			'rows' => $rows,
		];
	}

	private static function extract_text_from_docx_binary(string $binary): array {
		$tmp_file = wp_tempnam('vite-docx-import');
		if (!is_string($tmp_file) || $tmp_file === '') {
			return ['ok' => false, 'message' => 'Server could not create temporary file for DOCX parsing.', 'text' => ''];
		}

		$written = file_put_contents($tmp_file, $binary);
		if ($written === false) {
			@unlink($tmp_file);
			return ['ok' => false, 'message' => 'Server could not write DOCX temporary file.', 'text' => ''];
		}

		$zip = new ZipArchive();
		$open_result = $zip->open($tmp_file);
		if ($open_result !== true) {
			@unlink($tmp_file);
			return ['ok' => false, 'message' => 'DOCX file appears invalid or corrupted.', 'text' => ''];
		}

		$xml = $zip->getFromName('word/document.xml');
		$rels_xml = $zip->getFromName('word/_rels/document.xml.rels');
		$images = self::extract_docx_image_assets($zip, is_string($rels_xml) ? $rels_xml : '');
		$zip->close();
		@unlink($tmp_file);

		if (!is_string($xml) || trim($xml) === '') {
			return ['ok' => false, 'message' => 'DOCX is missing document content (word/document.xml).', 'text' => ''];
		}

		$text = self::xml_to_text($xml);
		$blocks = self::xml_to_blocks($xml);
		if (trim($text) === '') {
			return ['ok' => false, 'message' => 'DOCX content is empty after text extraction.', 'text' => ''];
		}

		return ['ok' => true, 'message' => '', 'text' => $text, 'blocks' => $blocks, 'images' => $images];
	}

	private static function extract_docx_image_assets(ZipArchive $zip, string $rels_xml): array {
		if ($rels_xml === '') {
			return [];
		}
		$dom = new DOMDocument();
		$old = libxml_use_internal_errors(true);
		$loaded = $dom->loadXML($rels_xml);
		libxml_clear_errors();
		libxml_use_internal_errors($old);
		if (!$loaded) {
			return [];
		}

		$xp = new DOMXPath($dom);
		$xp->registerNamespace('rel', 'http://schemas.openxmlformats.org/package/2006/relationships');
		$rels = $xp->query('/rel:Relationships/rel:Relationship');
		if (!$rels) {
			return [];
		}

		$assets = [];
		foreach ($rels as $rel) {
			if (!$rel instanceof DOMElement) {
				continue;
			}
			$type = (string) $rel->getAttribute('Type');
			if ($type === '' || stripos($type, '/image') === false) {
				continue;
			}
			$rid = trim((string) $rel->getAttribute('Id'));
			$target = trim((string) $rel->getAttribute('Target'));
			if ($rid === '' || $target === '') {
				continue;
			}
			$path = self::resolve_docx_target_path('word/document.xml', $target);
			if ($path === '') {
				continue;
			}
			$binary = $zip->getFromName($path);
			if (!is_string($binary) || $binary === '') {
				continue;
			}
			$filename = basename($path);
			$filetype = wp_check_filetype($filename, null);
			$assets[$rid] = [
				'rel_id' => $rid,
				'path' => $path,
				'filename' => $filename,
				'binary' => $binary,
				'mime' => (string) ($filetype['type'] ?? ''),
			];
		}
		return $assets;
	}

	private static function resolve_docx_target_path(string $base_part, string $target): string {
		$target = str_replace('\\', '/', trim($target));
		if ($target === '') {
			return '';
		}
		if (strpos($target, '/') === 0) {
			return ltrim($target, '/');
		}
		$base_dir = dirname($base_part);
		$combined = $base_dir . '/' . $target;
		$parts = explode('/', $combined);
		$stack = [];
		foreach ($parts as $part) {
			$part = trim((string) $part);
			if ($part === '' || $part === '.') {
				continue;
			}
			if ($part === '..') {
				array_pop($stack);
				continue;
			}
			$stack[] = $part;
		}
		return implode('/', $stack);
	}

	private static function xml_to_text(string $xml): string {
		$xml = str_replace(["\r\n", "\r"], "\n", $xml);
		$xml = preg_replace('~<w:tab[^>]*/>~i', "\t", $xml);
		$xml = preg_replace('~<w:br[^>]*/>~i', "\n", $xml);
		$xml = preg_replace('~</w:p>~i', "\n", $xml);
		$xml = preg_replace('~</w:tr>~i', "\n", $xml);
		$text = strip_tags($xml);
		$text = html_entity_decode((string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$text = str_replace("\xC2\xA0", ' ', $text);
		$text = preg_replace("~\n{3,}~", "\n\n", (string) $text);
		return trim((string) $text);
	}

	private static function xml_to_blocks(string $xml): array {
		$dom = new DOMDocument();
		$old = libxml_use_internal_errors(true);
		$loaded = $dom->loadXML($xml);
		libxml_clear_errors();
		libxml_use_internal_errors($old);

		if (!$loaded) {
			return [];
		}

		$xp = new DOMXPath($dom);
		$xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
		$xp->registerNamespace('a', 'http://schemas.openxmlformats.org/drawingml/2006/main');
		$xp->registerNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');

		$nodes = $xp->query('/w:document/w:body/*');
		if (!$nodes) {
			return [];
		}

		$blocks = [];
		foreach ($nodes as $node) {
			if (!$node instanceof DOMElement) {
				continue;
			}

			if ($node->localName === 'p') {
				$text = trim(self::paragraph_text_from_node($xp, $node));
				$image_refs = self::paragraph_image_refs_from_node($xp, $node);
				if ($text === '') {
					foreach ($image_refs as $rid) {
						$blocks[] = [
							'type' => 'image',
							'text' => '',
							'rel_id' => $rid,
							'html' => '<figure class="wp-block-image">[[DOCX_IMAGE:' . $rid . ']]</figure>',
						];
					}
					continue;
				}

				$style = strtolower(trim((string) $xp->evaluate('string(./w:pPr/w:pStyle/@w:val)', $node)));
				$is_list_item = (bool) $xp->evaluate('boolean(./w:pPr/w:numPr)', $node);

				if ($is_list_item) {
					$blocks[] = [
						'type' => 'list_item',
						'text' => $text,
						'html' => '<li>' . esc_html($text) . '</li>',
					];
					continue;
				}

				$level = self::heading_level_from_style($style);
				if ($level > 0) {
					$level = max(1, min(6, $level));
					$blocks[] = [
						'type' => 'heading',
						'level' => $level,
						'text' => $text,
						'html' => '<h' . $level . '>' . esc_html($text) . '</h' . $level . '>',
					];
					continue;
				}

				if (preg_match('~(?:quote|blockquote)~i', $style)) {
					$blocks[] = [
						'type' => 'blockquote',
						'text' => $text,
						'html' => '<blockquote><p>' . nl2br(esc_html($text)) . '</p></blockquote>',
					];
					continue;
				}

				$html = '<p>' . nl2br(esc_html($text)) . '</p>';
				$blocks[] = [
					'type' => 'paragraph',
					'text' => $text,
					'html' => $html,
				];
				foreach ($image_refs as $rid) {
					$blocks[] = [
						'type' => 'image',
						'text' => '',
						'rel_id' => $rid,
						'html' => '<figure class="wp-block-image">[[DOCX_IMAGE:' . $rid . ']]</figure>',
					];
				}
				continue;
			}

			if ($node->localName === 'tbl') {
				$table = self::table_html_from_node($xp, $node);
				if ($table['html'] !== '') {
					$blocks[] = [
						'type' => 'table',
						'text' => $table['text'],
						'html' => $table['html'],
					];
				}
			}
		}

		return $blocks;
	}

	private static function paragraph_image_refs_from_node(DOMXPath $xp, DOMElement $p): array {
		$out = [];
		$blips = $xp->query('.//a:blip[@r:embed]', $p);
		if ($blips) {
			foreach ($blips as $blip) {
				if (!$blip instanceof DOMElement) {
					continue;
				}
				$rid = trim((string) $blip->getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'embed'));
				if ($rid === '') {
					$rid = trim((string) $blip->getAttribute('r:embed'));
				}
				if ($rid !== '') {
					$out[] = $rid;
				}
			}
		}
		return array_values(array_unique($out));
	}

	private static function heading_level_from_style(string $style): int {
		if ($style === '') {
			return 0;
		}
		if (preg_match('~heading\s*([1-6])~i', $style, $m)) {
			return (int) $m[1];
		}
		if (preg_match('~^h([1-6])$~i', $style, $m)) {
			return (int) $m[1];
		}
		if ($style === 'title') {
			return 1;
		}
		return 0;
	}

	private static function paragraph_text_from_node(DOMXPath $xp, DOMElement $p): string {
		$parts = [];
		$text_nodes = $xp->query('.//w:t|.//w:tab|.//w:br|.//w:cr', $p);
		if ($text_nodes) {
			foreach ($text_nodes as $n) {
				if (!$n instanceof DOMElement) {
					continue;
				}
				$local = $n->localName;
				if ($local === 't') {
					$parts[] = (string) $n->textContent;
				} elseif ($local === 'tab') {
					$parts[] = "\t";
				} elseif ($local === 'br' || $local === 'cr') {
					$parts[] = "\n";
				}
			}
		}

		$text = implode('', $parts);
		$text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$text = str_replace("\xC2\xA0", ' ', $text);
		$text = preg_replace('~[ \t]+~', ' ', (string) $text);
		$text = preg_replace("~\n{2,}~", "\n", (string) $text);
		return trim((string) $text);
	}

	private static function table_html_from_node(DOMXPath $xp, DOMElement $tbl): array {
		$rows = $xp->query('./w:tr', $tbl);
		if (!$rows || $rows->length === 0) {
			return ['html' => '', 'text' => ''];
		}

		$html = '<figure class="wp-block-table"><div class="vite-docx-table-wrap" style="overflow-x:auto;"><table style="width:100%;min-width:640px;">';
		$text_rows = [];
		$row_index = 0;

		foreach ($rows as $row) {
			if (!$row instanceof DOMElement) {
				continue;
			}
			$cells = $xp->query('./w:tc', $row);
			if (!$cells || $cells->length === 0) {
				continue;
			}

			$html .= '<tr>';
			$text_cells = [];
			foreach ($cells as $cell) {
				if (!$cell instanceof DOMElement) {
					continue;
				}
				$cell_text = trim(self::paragraph_text_from_node($xp, $cell));
				$cell_html_text = nl2br(esc_html($cell_text));
				if ($row_index === 0) {
					$html .= '<th>' . $cell_html_text . '</th>';
				} else {
					$html .= '<td>' . $cell_html_text . '</td>';
				}
				$text_cells[] = $cell_text;
			}
			$html .= '</tr>';
			$row_index++;
			$text_rows[] = implode("\t", $text_cells);
		}

		$html .= '</table></div></figure>';
		return ['html' => $html, 'text' => implode("\n", $text_rows)];
	}

	private static function parse_doc_template(string $text, array $requirements, array $blocks = []): array {
		$lines = preg_split("~\r\n|\n|\r~", $text) ?: [];
		$fields = [
			'title_tag' => '',
			'meta_description' => '',
			'url_slug' => '',
			'h1_blog_title' => '',
			'language' => '',
			'categories' => [],
			'tags' => [],
			'page_type' => '',
			'_has_categories_label' => false,
			'_has_tags_label' => false,
			'_has_page_type_label' => false,
			'excerpt' => '',
			'featured_image_directive' => '',
			'featured_image_alt' => '',
			'content_image_alts' => [],
			'featured_image_rel_id' => '',
			'body_image_rel_ids' => [],
			'image_name_suggestions' => [],
			'schema' => '',
			'body' => '',
			'_notes' => [],
		];

		$metadata_line_max = -1;
		$strict_labels = !empty($requirements['strict_labels']);

		$title_info = self::extract_field_from_lines($lines, ['title\s*tag'], false, $strict_labels);
		$meta_info = self::extract_field_from_lines($lines, ['meta\s*description'], false, $strict_labels);
		$slug_info = self::extract_field_from_lines($lines, ['url\s*slug', 'slug', 'url'], false, $strict_labels);
		$h1_info = self::extract_field_from_lines($lines, ['h1\s*\(\s*blog\s*title\s*\)', 'h1', 'blog\s*title'], false, $strict_labels);
		$lang_info = self::extract_field_from_lines($lines, ['lang(?:uage)?'], false, $strict_labels);
		$categories_info = self::extract_field_from_lines($lines, ['categor(?:y|ies)'], false, $strict_labels);
		$tags_info = self::extract_field_from_lines($lines, ['tags?'], false, $strict_labels);
		$page_type_info = self::extract_field_from_lines($lines, ['page\s*type'], false, $strict_labels);
		$excerpt_info = self::extract_field_from_lines($lines, ['excerpt'], false, $strict_labels);
		$featured_image_alt_info = self::extract_field_from_lines($lines, ['featured\s*image\s*alt'], false, $strict_labels);
		$content_image_alt_info = self::extract_field_from_lines($lines, ['content\s*image\s*alt'], false, $strict_labels);
		$featured_image_info = self::extract_field_from_lines($lines, ['featured\s*image(?!\s*alt\b)'], false, $strict_labels);
		$schema_info = self::extract_field_from_lines($lines, ['schema(?:\s*json(?:\s*-\s*ld)?)?'], false, $strict_labels);
		$body_label_info = self::extract_field_from_lines($lines, ['body'], true, $strict_labels);

		if ($title_info['found']) {
			$fields['title_tag'] = trim((string) $title_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $title_info['line']);
		}
		if ($meta_info['found']) {
			$fields['meta_description'] = trim((string) $meta_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $meta_info['line']);
		}
		if ($slug_info['found']) {
			$fields['url_slug'] = self::normalize_slug_candidate((string) $slug_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $slug_info['line']);
		}
		if ($h1_info['found']) {
			$fields['h1_blog_title'] = trim((string) $h1_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $h1_info['line']);
		}
		if ($lang_info['found']) {
			$fields['language'] = self::normalize_language_code((string) $lang_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $lang_info['line']);
			if ($fields['language'] !== '') {
				$fields['_notes'][] = 'Language code detected: ' . $fields['language'];
			}
		}
		if ($categories_info['found']) {
			$fields['_has_categories_label'] = true;
			$fields['categories'] = self::normalize_term_list((string) $categories_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $categories_info['line']);
			if (!empty($fields['categories'])) {
				$fields['_notes'][] = 'Categories detected: ' . implode(', ', $fields['categories']);
			}
		}
		if ($tags_info['found']) {
			$fields['_has_tags_label'] = true;
			$fields['tags'] = self::normalize_term_list((string) $tags_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $tags_info['line']);
			if (!empty($fields['tags'])) {
				$fields['_notes'][] = 'Tags detected: ' . implode(', ', $fields['tags']);
			}
		}
		if ($page_type_info['found']) {
			$fields['_has_page_type_label'] = true;
			$raw_page_type = (string) $page_type_info['value'];
			$fields['page_type'] = self::normalize_page_type_value($raw_page_type);
			$metadata_line_max = max($metadata_line_max, (int) $page_type_info['line']);
			if ($fields['page_type'] !== '') {
				$fields['_notes'][] = 'Page Type detected: ' . ucfirst($fields['page_type']);
			} elseif (trim($raw_page_type) !== '') {
				$fields['_notes'][] = 'Page Type label found, but value is invalid (allowed: glossary, pillar, hub, section).';
			}
		}
		if ($excerpt_info['found']) {
			$fields['excerpt'] = trim((string) $excerpt_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $excerpt_info['line']);
		}
		if ($featured_image_alt_info['found']) {
			$fields['featured_image_alt'] = trim((string) $featured_image_alt_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $featured_image_alt_info['line']);
		}
		if ($content_image_alt_info['found']) {
			$fields['content_image_alts'] = self::normalize_alt_list((string) $content_image_alt_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $content_image_alt_info['line']);
		}
		if ($featured_image_info['found']) {
			$fields['featured_image_directive'] = trim((string) $featured_image_info['value']);
			$metadata_line_max = max($metadata_line_max, (int) $featured_image_info['line']);
		}
		if ($schema_info['found']) {
			$schema_span = self::collect_schema_block_from_lines($lines, (int) $schema_info['line'], (string) $schema_info['value']);
			$fields['schema'] = trim((string) ($schema_span['value'] ?? ''));
			$metadata_line_max = max($metadata_line_max, (int) ($schema_span['end_line'] ?? $schema_info['line']));
		}

		if (!empty($requirements['require_title_tag']) && $fields['title_tag'] === '') {
			return ['ok' => false, 'message' => 'Missing required label/value: Title Tag.', 'data' => []];
		}
		if (!empty($requirements['require_meta_description']) && $fields['meta_description'] === '') {
			return ['ok' => false, 'message' => 'Missing required label/value: Meta Description.', 'data' => []];
		}
		if ($fields['url_slug'] === '') {
			return ['ok' => false, 'message' => 'Missing required label/value: URL Slug/Slug/URL.', 'data' => []];
		}
		if (!empty($requirements['require_h1']) && $fields['h1_blog_title'] === '') {
			return ['ok' => false, 'message' => 'Missing required label/value: H1 (Blog Title).', 'data' => []];
		}
		if (!empty($requirements['require_body_label']) && !$body_label_info['found']) {
			return ['ok' => false, 'message' => 'Missing required label/value: Body.', 'data' => []];
		}

		if (!$body_label_info['found']) {
			$fields['_notes'][] = 'Body label not found, fallback body detection used';
		}

		$body = '';
		if ($body_label_info['found']) {
			$body_start = (int) $body_label_info['line'];
			$first = trim((string) $body_label_info['value']);
			if ($first !== '' && !self::is_any_label_line($first)) {
				$body = $first;
			}
			for ($i = $body_start + 1; $i < count($lines); $i++) {
				$line_raw = (string) $lines[$i];
				$line_trim = trim($line_raw);
				if ($line_trim === '') {
					$body = self::append_line($body, '');
					continue;
				}
				if (self::normalize_label_line($line_trim) === '') {
					continue;
				}
				// Prevent metadata labels from leaking into post content.
				if (self::is_any_label_line($line_trim)) {
					continue;
				}
				$body = self::append_line($body, $line_raw);
			}

			// Body-mode rule: first real line after "Body:" is the blog title when H1 label is missing.
			if ($fields['h1_blog_title'] === '') {
				$body_lines = preg_split("~\r\n|\n|\r~", (string) $body) ?: [];
				$title_from_body = '';
				$title_idx = -1;
				foreach ($body_lines as $idx => $body_line) {
					$candidate = trim((string) $body_line);
					if ($candidate === '') {
						continue;
					}
					if (self::is_any_label_line($candidate)) {
						continue;
					}
					$title_from_body = $candidate;
					$title_idx = (int) $idx;
					break;
				}
				if ($title_from_body !== '') {
					$fields['h1_blog_title'] = $title_from_body;
					$fields['_notes'][] = 'H1 label missing, first line under Body used as post title';
					$remaining = [];
					foreach ($body_lines as $idx => $body_line) {
						if ((int) $idx === $title_idx) {
							continue;
						}
						$remaining[] = (string) $body_line;
					}
					$body = trim(implode("\n", $remaining));
				}
			}
		} else {
			$h1_line = -1;
			if ($fields['h1_blog_title'] !== '') {
				$h1_line = self::find_line_by_text_after((array) $lines, $fields['h1_blog_title'], max(0, $metadata_line_max + 1));
			}

			if ($h1_line < 0) {
				$h1_line = self::find_first_content_line_after((array) $lines, max(0, $metadata_line_max + 1));
				if ($h1_line >= 0 && $fields['h1_blog_title'] === '') {
					$fields['h1_blog_title'] = trim((string) $lines[$h1_line]);
					$fields['_notes'][] = 'H1 label missing, first heading/content line used as post title';
				}
			}

			$start = $h1_line >= 0 ? $h1_line + 1 : max(0, $metadata_line_max + 1);
			for ($i = $start; $i < count($lines); $i++) {
				$line_raw = (string) $lines[$i];
				$line_trim = trim($line_raw);
				if ($line_trim === '') {
					$body = self::append_line($body, '');
					continue;
				}
				if (self::normalize_label_line($line_trim) === '') {
					continue;
				}
				if (self::is_any_label_line($line_trim)) {
					continue;
				}
				$body = self::append_line($body, $line_raw);
			}
		}

		$fields['body'] = trim((string) $body);

		if ($fields['h1_blog_title'] === '') {
			$fallback_title_line = self::find_first_content_line_after((array) $lines, max(0, $metadata_line_max + 1));
			if ($fallback_title_line >= 0) {
				$fields['h1_blog_title'] = trim((string) $lines[$fallback_title_line]);
				$fields['_notes'][] = 'Post title extracted from first heading/content line';
			}
		}

		if (!empty($blocks)) {
			// No Body label: use first real DOCX heading as title anchor (ignore schema-adjacent noise).
			$selected_title_for_blocks = $fields['h1_blog_title'];
			if (empty($body_label_info['found']) && empty($h1_info['found'])) {
				$selected_title_for_blocks = '';
			}
			$structured = self::extract_structured_content_from_blocks($blocks, $selected_title_for_blocks, !empty($body_label_info['found']));
			if (!empty($structured['title']) && ($fields['h1_blog_title'] === '' || (empty($body_label_info['found']) && empty($h1_info['found'])))) {
				$fields['h1_blog_title'] = (string) $structured['title'];
				$fields['_notes'][] = 'Post title extracted from first DOCX heading';
			}
			if (!empty($structured['body_html'])) {
				$fields['body'] = (string) $structured['body_html'];
				$fields['_notes'][] = 'Structured DOCX content preserved (headings/lists/tables)';
			}
			$body_image_rel_ids = is_array($structured['body_image_rel_ids'] ?? null) ? $structured['body_image_rel_ids'] : [];
			$pre_body_image_rel_ids = is_array($structured['pre_body_image_rel_ids'] ?? null) ? $structured['pre_body_image_rel_ids'] : [];
			$body_image_name_map = is_array($structured['body_image_name_map'] ?? null) ? $structured['body_image_name_map'] : [];
			$fields['body_image_rel_ids'] = array_values(array_filter(array_map('strval', $body_image_rel_ids)));
			$featured_candidates = array_values(array_filter(array_map('strval', $pre_body_image_rel_ids)));
			$featured_all_candidates = array_values(array_unique(array_merge($featured_candidates, $fields['body_image_rel_ids'])));
			$directive = strtolower(trim((string) $fields['featured_image_directive']));
			if (!empty($featured_candidates)) {
				$fields['featured_image_rel_id'] = (string) $featured_candidates[0];
			}
			if ($directive !== '' && preg_match('~^\d+$~', $directive)) {
				$idx = ((int) $directive) - 1;
				if ($idx >= 0 && isset($featured_all_candidates[$idx])) {
					$fields['featured_image_rel_id'] = (string) $featured_all_candidates[$idx];
					$fields['_notes'][] = 'Featured image index override applied: ' . ($idx + 1) . '.';
				}
			}
			$image_name_suggestions = [];
			foreach ($body_image_name_map as $rid => $name) {
				$rid = trim((string) $rid);
				$name = trim((string) $name);
				if ($rid !== '' && $name !== '') {
					$image_name_suggestions[$rid] = $name;
				}
			}
			if ($fields['featured_image_rel_id'] !== '' && $fields['h1_blog_title'] !== '') {
				$image_name_suggestions[(string) $fields['featured_image_rel_id']] = (string) $fields['h1_blog_title'];
			}
			$fields['image_name_suggestions'] = $image_name_suggestions;
		}

		if ($fields['featured_image_rel_id'] !== '' && $fields['featured_image_alt'] === '') {
			return ['ok' => false, 'message' => 'Missing required label/value: Featured Image Alt (featured image detected in DOCX).', 'data' => []];
		}
		if (!empty($fields['body_image_rel_ids'])) {
			$total_body_images = count($fields['body_image_rel_ids']);
			if (count($fields['content_image_alts']) < $total_body_images) {
				return ['ok' => false, 'message' => 'Missing required label/value: Content Image Alt has fewer items than body images (' . $total_body_images . ' image(s) detected).', 'data' => []];
			}
			$missing_positions = [];
			for ($i = 0; $i < $total_body_images; $i++) {
				$alt = trim((string) ($fields['content_image_alts'][$i] ?? ''));
				if ($alt === '') {
					$missing_positions[] = (string) ($i + 1);
				}
			}
			if (!empty($missing_positions)) {
				return ['ok' => false, 'message' => 'Missing required Content Image Alt at position(s): ' . implode(', ', $missing_positions) . '.', 'data' => []];
			}
		}

		if ($fields['h1_blog_title'] === '') {
			return ['ok' => false, 'message' => 'Could not determine blog title (H1).', 'data' => []];
		}
		if ($fields['body'] === '') {
			return ['ok' => false, 'message' => 'Body content is empty after parsing.', 'data' => []];
		}

		return ['ok' => true, 'message' => '', 'data' => $fields];
	}

	private static function extract_structured_content_from_blocks(array $blocks, string $selected_title, bool $body_mode = false): array {
		$title = trim($selected_title);
		$start_idx = -1;
		$body_boundary_idx = -1;
		$inline_body_text = '';
		$schema_range = self::detect_schema_block_range($blocks);
		$schema_start = (int) ($schema_range['start'] ?? -1);
		$schema_end = (int) ($schema_range['end'] ?? -1);

		if ($body_mode) {
			foreach ($blocks as $i => $b) {
				$text = trim((string) ($b['text'] ?? ''));
				if ($text === '') {
					continue;
				}
				$norm = self::normalize_label_line($text);
				if (preg_match('~^body\s*:\s*(.*)$~iu', $norm, $m)) {
					$start_idx = $i + 1;
					$body_boundary_idx = $start_idx;
					$inline_body_text = trim((string) ($m[1] ?? ''));
					break;
				}
				if (preg_match('~^body\s*$~iu', $norm)) {
					$start_idx = $i + 1;
					$body_boundary_idx = $start_idx;
					break;
				}
			}
		}

		if ($title !== '') {
			$norm_title = self::normalize_compare_text($title);
			foreach ($blocks as $i => $b) {
				$text = trim((string) ($b['text'] ?? ''));
				if ($text === '') {
					continue;
				}
				if (self::normalize_compare_text($text) === $norm_title) {
					$start_idx = $i + 1;
					break;
				}
			}
		}

		if ($start_idx < 0) {
			foreach ($blocks as $i => $b) {
				$type = (string) ($b['type'] ?? '');
				$text = trim((string) ($b['text'] ?? ''));
				if ($text === '' || self::looks_like_metadata_text($text)) {
					continue;
				}
				if ($type === 'heading') {
					if ($title === '') {
						$title = $text;
					}
					$start_idx = $i + 1;
					break;
				}
			}
		}

		if ($start_idx < 0) {
			$start_idx = 0;
		}
		$pre_body_image_rel_ids = [];
		$pre_body_limit = $body_boundary_idx >= 0 ? $body_boundary_idx : $start_idx;
		for ($i = 0; $i < $pre_body_limit; $i++) {
			$block = $blocks[$i] ?? null;
			if (!is_array($block)) {
				continue;
			}
			if ((string) ($block['type'] ?? '') !== 'image') {
				continue;
			}
			$rid = trim((string) ($block['rel_id'] ?? ''));
			if ($rid !== '') {
				$pre_body_image_rel_ids[] = $rid;
			}
		}

		$body_blocks = [];
		if ($inline_body_text !== '' && !self::is_any_label_line($inline_body_text)) {
			$body_blocks[] = [
				'type' => 'paragraph',
				'text' => $inline_body_text,
				'html' => '<p>' . nl2br(esc_html($inline_body_text)) . '</p>',
			];
		}
		for ($i = $start_idx; $i < count($blocks); $i++) {
			if ($schema_start >= 0 && $schema_end >= $schema_start && $i >= $schema_start && $i <= $schema_end) {
				continue;
			}
			$block = $blocks[$i];
			$type = (string) ($block['type'] ?? '');
			if ($type === 'image') {
				$body_blocks[] = $block;
				continue;
			}
			$text = trim((string) ($block['text'] ?? ''));
			if ($text === '') {
				continue;
			}
			if (self::normalize_label_line($text) === '') {
				continue;
			}
			if ($i < 8 && self::looks_like_metadata_text($text)) {
				continue;
			}
			$body_blocks[] = $block;
		}

		if ($body_mode) {
			$norm_title = self::normalize_compare_text($title);
			foreach ($body_blocks as $idx => $block) {
				$type = (string) ($block['type'] ?? '');
				if ($type === 'image') {
					continue;
				}
				$text = trim((string) ($block['text'] ?? ''));
				if ($text === '' || self::is_any_label_line($text)) {
					continue;
				}
				if (self::normalize_label_line($text) === '') {
					continue;
				}
				if ($title === '') {
					$title = $text;
					$norm_title = self::normalize_compare_text($title);
				}
				if ($norm_title !== '' && self::normalize_compare_text($text) === $norm_title) {
					unset($body_blocks[$idx]);
				}
				break;
			}
			$body_blocks = array_values($body_blocks);
		}

		$html = self::render_blocks_to_html($body_blocks);
		$body_image_rel_ids = [];
		$body_image_name_map = [];
		$active_section_heading = '';
		foreach ($body_blocks as $block) {
			if (!is_array($block)) {
				continue;
			}
			$type = (string) ($block['type'] ?? '');
			if ($type === 'heading') {
				$lvl = (int) ($block['level'] ?? 0);
				$heading_text = trim((string) ($block['text'] ?? ''));
				if ($heading_text !== '' && in_array($lvl, [2, 3, 4], true)) {
					$active_section_heading = $heading_text;
				}
			}
			if ($type !== 'image') {
				continue;
			}
			$rid = trim((string) ($block['rel_id'] ?? ''));
			if ($rid !== '') {
				$body_image_rel_ids[] = $rid;
				$suggested = $active_section_heading !== '' ? $active_section_heading : $title;
				if ($suggested !== '' && !isset($body_image_name_map[$rid])) {
					$body_image_name_map[$rid] = $suggested;
				}
			}
		}
		return [
			'title' => $title,
			'body_html' => $html,
			'body_image_rel_ids' => array_values(array_unique($body_image_rel_ids)),
			'pre_body_image_rel_ids' => array_values(array_unique($pre_body_image_rel_ids)),
			'body_image_name_map' => $body_image_name_map,
		];
	}

	private static function detect_schema_block_range(array $blocks): array {
		$start = -1;
		$end = -1;
		$total = count($blocks);

		for ($i = 0; $i < $total; $i++) {
			$text = trim((string) (($blocks[$i]['text'] ?? '')));
			if ($text === '') {
				continue;
			}
			$norm = self::normalize_label_line($text);
			if (!preg_match('~^schema(?:\s*json(?:\s*-\s*ld)?)?\s*:?\s*(.*)$~iu', $norm)) {
				continue;
			}

			$start = $i;
			$end = $i;
			$inline_value = '';
			if (preg_match('~^schema(?:\s*json(?:\s*-\s*ld)?)?\s*:?\s*(.*)$~iu', $norm, $m)) {
				$inline_value = self::normalize_schema_raw_text((string) ($m[1] ?? ''));
			}
			$schema_text = '';
			if ($inline_value !== '' && !self::is_schema_placeholder_value($inline_value)) {
				$inline_json = self::trim_to_first_json_start($inline_value);
				if ($inline_json !== '') {
					$schema_text = $inline_json;
				}
			}
			if (self::schema_json_appears_complete($schema_text)) {
				break;
			}

			for ($j = $i + 1; $j < $total; $j++) {
				$next_text = trim((string) (($blocks[$j]['text'] ?? '')));
				if ($next_text === '') {
					$end = $j;
					continue;
				}
				$next_norm = self::normalize_label_line($next_text);
				if (
					self::is_any_label_line($next_norm) &&
					!preg_match('~^schema(?:\s*json(?:\s*-\s*ld)?)?\s*:?\s*~iu', $next_norm)
				) {
					break;
				}
				$clean_next = self::normalize_schema_raw_text($next_text);
				if ($schema_text === '') {
					$clean_next = self::trim_to_first_json_start($clean_next);
				}
				if ($clean_next !== '') {
					$schema_text = $schema_text === '' ? $clean_next : ($schema_text . "\n" . $clean_next);
				}
				$end = $j;
				if (self::schema_json_appears_complete($schema_text)) {
					break;
				}
			}
			break;
		}

		return ['start' => $start, 'end' => $end];
	}

	private static function looks_like_metadata_text(string $text): bool {
		$text = trim($text);
		if ($text === '') {
			return false;
		}
		$text = self::normalize_label_line($text);
		return (bool) preg_match('~^(title\s*tag|meta\s*description|url\s*slug|slug|url|h1\s*\(\s*blog\s*title\s*\)|h1|blog\s*title|lang(?:uage)?|categor(?:y|ies)|tags?|page\s*type|excerpt|featured\s*image\s*alt|content\s*image\s*alt|featured\s*image|schema|body)\s*:?\s*~iu', $text);
	}

	private static function normalize_compare_text(string $text): string {
		$text = strtolower(trim($text));
		$text = preg_replace('~\s+~', ' ', (string) $text);
		return trim((string) $text);
	}

	private static function render_blocks_to_html(array $blocks): string {
		$out = '';
		$open_list = false;

		foreach ($blocks as $block) {
			$type = (string) ($block['type'] ?? '');
			$html = (string) ($block['html'] ?? '');
			if ($type === 'list_item') {
				if (!$open_list) {
					$out .= '<ul>';
					$open_list = true;
				}
				$out .= $html;
				continue;
			}

			if ($open_list) {
				$out .= '</ul>';
				$open_list = false;
			}

			$out .= $html;
		}

		if ($open_list) {
			$out .= '</ul>';
		}

		return trim($out);
	}

	private static function normalize_label_line(string $line): string {
		$line = trim($line);
		$line = str_replace("\xC2\xA0", ' ', $line);
		// Remove hidden/private-use glyphs sometimes injected by DOCX editors (e.g.  / ).
		$line = preg_replace('~[\x{200B}-\x{200D}\x{FEFF}\x{E000}-\x{F8FF}]~u', '', (string) $line);
		// Normalize common full-width punctuation copied from docs/editors.
		$line = str_replace('：', ':', $line);
		$line = preg_replace('~^[\|\-\*\x{2022}\s]+~u', '', (string) $line);
		return trim((string) $line);
	}

	private static function extract_field_from_lines(array $lines, array $aliases, bool $allow_multiline = false, bool $require_colon = false): array {
		$aliases_regex = '(?:' . implode('|', $aliases) . ')';
		$regex = $require_colon
			? '~^\s*' . $aliases_regex . '\s*:\s*(.*)$~iu'
			: '~^\s*' . $aliases_regex . '\s*(?::\s*(.*))?$~iu';
		$total = count($lines);

		for ($i = 0; $i < $total; $i++) {
			$line = self::normalize_label_line((string) $lines[$i]);
			if (!preg_match($regex, $line, $m)) {
				continue;
			}

			$value = trim((string) ($m[1] ?? ''));
			if ($value === '') {
				for ($j = $i + 1; $j < $total; $j++) {
					$next = trim((string) $lines[$j]);
					if ($next === '') {
						continue;
					}
					$next_norm = self::normalize_label_line($next);
					if (self::is_any_label_line($next_norm)) {
						break;
					}
					$value = $next;
					if ($allow_multiline) {
						for ($k = $j + 1; $k < $total; $k++) {
							$more = trim((string) $lines[$k]);
							if ($more === '') {
								break;
							}
							$more_norm = self::normalize_label_line($more);
							if (self::is_any_label_line($more_norm)) {
								break;
							}
							$value .= "\n" . (string) $lines[$k];
						}
					}
					break;
				}
			}

			return [
				'found' => true,
				'value' => trim((string) $value),
				'line' => $i,
			];
		}

		return ['found' => false, 'value' => '', 'line' => -1];
	}

	private static function is_any_label_line(string $line): bool {
		$line = self::normalize_label_line($line);
		return (bool) preg_match('~^\s*(title\s*tag|meta\s*description|url\s*slug|slug|url|h1\s*\(\s*blog\s*title\s*\)|h1|blog\s*title|lang(?:uage)?|categor(?:y|ies)|tags?|page\s*type|excerpt|featured\s*image\s*alt|content\s*image\s*alt|featured\s*image|schema|body)\s*:?\s*~iu', $line);
	}

	private static function normalize_language_code(string $value): string {
		$value = strtolower(trim($value));
		$value = str_replace('_', '-', $value);
		$value = preg_replace('~\s+~', '', (string) $value);
		if (!is_string($value) || $value === '') {
			return '';
		}
		if (!preg_match('~^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$~', $value)) {
			return '';
		}
		return $value;
	}

	private static function normalize_term_list(string $value): array {
		$value = trim($value);
		if ($value === '') {
			return [];
		}
		$parts = preg_split('~[\n\r,;|]+~', $value) ?: [];
		$out = [];
		foreach ($parts as $part) {
			$term = trim((string) $part);
			if ($term === '') {
				continue;
			}
			$out[] = $term;
		}
		return array_values(array_unique($out));
	}

	private static function normalize_alt_list(string $value): array {
		$value = trim($value);
		if ($value === '') {
			return [];
		}
		$value = preg_replace('~[\r\n]+~', ',', $value);
		$tokens = str_getcsv((string) $value, ',', '"', '\\');
		if (!is_array($tokens) || !$tokens) {
			return [];
		}
		$out = [];
		foreach ($tokens as $token) {
			$out[] = trim((string) $token);
		}
		return $out;
	}

	private static function normalize_page_type_value(string $value): string {
		$normalized = strtolower(trim($value));
		$normalized = str_replace(['_', '-'], ' ', $normalized);
		$normalized = preg_replace('~\s+~', ' ', (string) $normalized);
		$normalized = trim((string) $normalized);

		$map = [
			'pillar' => 'pillar',
			'hub' => 'hub',
			'section' => 'section',
			'glossary' => 'glossary',
		];
		return $map[$normalized] ?? '';
	}

	private static function upsert_category_terms(array $category_names): array {
		$ids = [];
		foreach ($category_names as $name) {
			$name = trim((string) $name);
			if ($name === '') {
				continue;
			}
			$term = get_term_by('name', $name, 'category');
			if (!$term || is_wp_error($term)) {
				$created = wp_insert_term($name, 'category');
				if (is_wp_error($created)) {
					return ['ok' => false, 'message' => 'Failed to create category "' . $name . '": ' . $created->get_error_message(), 'ids' => []];
				}
				$term_id = (int) ($created['term_id'] ?? 0);
			} else {
				$term_id = (int) $term->term_id;
			}
			if ($term_id > 0) {
				$ids[] = $term_id;
			}
		}

		return ['ok' => true, 'message' => '', 'ids' => array_values(array_unique($ids))];
	}

	private static function resolve_polylang_language(string $requested_code): array {
		if (!function_exists('pll_set_post_language')) {
			return [
				'active' => false,
				'lang' => '',
				'note' => '',
			];
		}

		$requested = self::normalize_language_code($requested_code);
		$available = [];
		if (function_exists('pll_languages_list')) {
			$list = pll_languages_list(['fields' => 'slug']);
			if (is_array($list)) {
				$available = array_values(array_unique(array_map('strval', $list)));
			}
		}

		$default_en = self::DEFAULT_POLYLANG_LANG;
		$target = '';
		$note = '';

		if ($requested !== '') {
			if (empty($available) || in_array($requested, $available, true)) {
				$target = $requested;
			} else {
				if (in_array($default_en, $available, true)) {
					$target = $default_en;
					$note = 'DOCX language "' . $requested . '" is not configured in Polylang. Fallback applied: ' . $default_en . '.';
				} else {
					$fallback_default = function_exists('pll_default_language') ? (string) pll_default_language('slug') : '';
					if ($fallback_default !== '' && in_array($fallback_default, $available, true)) {
						$target = $fallback_default;
						$note = 'DOCX language "' . $requested . '" is not configured in Polylang. Fallback applied: ' . $fallback_default . '.';
					} elseif (!empty($available)) {
						$target = (string) $available[0];
						$note = 'DOCX language "' . $requested . '" is not configured in Polylang. Fallback applied: ' . $target . '.';
					} else {
						$target = $default_en;
						$note = 'DOCX language "' . $requested . '" is not configured. Fallback applied: ' . $default_en . '.';
					}
				}
			}
		} else {
			if (empty($available) || in_array($default_en, $available, true)) {
				$target = $default_en;
				$note = 'No DOCX language provided. Default applied: ' . $default_en . '.';
			} else {
				$fallback_default = function_exists('pll_default_language') ? (string) pll_default_language('slug') : '';
				if ($fallback_default !== '' && in_array($fallback_default, $available, true)) {
					$target = $fallback_default;
					$note = 'No DOCX language provided. English (' . $default_en . ') is not configured; fallback applied: ' . $fallback_default . '.';
				} else {
					$target = (string) $available[0];
					$note = 'No DOCX language provided. English (' . $default_en . ') is not configured; fallback applied: ' . $target . '.';
				}
			}
		}

		return [
			'active' => true,
			'lang' => $target,
			'note' => $note,
		];
	}

	private static function normalize_slug_candidate(string $value): string {
		$value = trim($value);
		if ($value === '') {
			return '';
		}

		$value = preg_replace('~\s+~', '', (string) $value);
		$value = preg_replace('~[?#].*$~', '', (string) $value);

		if (preg_match('~^https?://~i', $value) || strpos($value, '/') !== false) {
			$path = (string) wp_parse_url($value, PHP_URL_PATH);
			if ($path === '') {
				$path = $value;
			}
			$path = trim($path, '/');
			if ($path !== '') {
				$parts = array_values(array_filter(explode('/', $path), static function ($v) {
					return trim((string) $v) !== '';
				}));
				if (!empty($parts)) {
					$value = (string) end($parts);
				}
			}
		}

		$value = rawurldecode($value);
		return sanitize_title($value);
	}

	private static function build_slug_for_language(string $base_slug, string $lang): string {
		$base_slug = sanitize_title($base_slug);
		if ($base_slug === '') {
			return '';
		}
		$lang = self::normalize_language_code($lang);
		$default_lang = self::normalize_language_code(self::DEFAULT_POLYLANG_LANG);
		if ($lang === '' || $lang === $default_lang) {
			return $base_slug;
		}
		if (preg_match('~-' . preg_quote($lang, '~') . '$~i', $base_slug)) {
			return $base_slug;
		}
		return sanitize_title($base_slug . '-' . strtolower($lang));
	}

	private static function find_line_by_text_after(array $lines, string $needle, int $start): int {
		$needle_norm = strtolower(trim(preg_replace('~\s+~', ' ', $needle)));
		if ($needle_norm === '') {
			return -1;
		}
		$total = count($lines);
		for ($i = max(0, $start); $i < $total; $i++) {
			$candidate = strtolower(trim((string) preg_replace('~\s+~', ' ', (string) $lines[$i])));
			if ($candidate === $needle_norm) {
				return $i;
			}
		}
		return -1;
	}

	private static function find_first_content_line_after(array $lines, int $start): int {
		$total = count($lines);
		for ($i = max(0, $start); $i < $total; $i++) {
			$line = trim((string) $lines[$i]);
			if ($line === '') {
				continue;
			}
			$line_normalized = self::normalize_label_line($line);
			if ($line_normalized === '') {
				continue;
			}
			if (self::is_any_label_line($line)) {
				continue;
			}
			return $i;
		}
		return -1;
	}

	private static function append_line(string $existing, string $line): string {
		if ($existing === '') {
			return $line;
		}
		return $existing . "\n" . $line;
	}

	private static function normalize_schema_json(string $schema_raw): array {
		$raw = trim($schema_raw);
		if ($raw === '') {
			return ['ok' => true, 'message' => '', 'json' => ''];
		}

		$raw = self::normalize_text_encoding_utf8($raw);
		$raw = html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$raw = self::normalize_schema_raw_text($raw);
		$raw = trim($raw);

		$candidate = $raw;
		if (preg_match('~<script[^>]*application/ld\+json[^>]*>(.*?)</script>~is', $raw, $m)) {
			$candidate = trim((string) ($m[1] ?? ''));
		}
		$candidate = self::normalize_text_encoding_utf8($candidate);
		$candidate = self::normalize_schema_raw_text($candidate);

		$candidate = trim(self::strip_utf8_bom($candidate));
		if ($candidate === '') {
			return ['ok' => false, 'message' => 'Schema label exists but the value is empty.', 'json' => ''];
		}

		$first_json = self::extract_first_complete_json_candidate($candidate);
		if ($first_json !== '') {
			$candidate = $first_json;
		}

		$decoded = self::decode_schema_json_with_fallback($candidate);
		if (!is_array($decoded)) {
			$error_msg = function_exists('json_last_error_msg') ? (string) json_last_error_msg() : 'Unknown JSON error';
			$preview = preg_replace('~\s+~u', ' ', (string) substr($candidate, 0, 180));
			return [
				'ok' => false,
				'message' => 'Schema is not valid JSON (' . $error_msg . '). Preview: ' . $preview,
				'json' => '',
			];
		}

		$normalized = wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if (!is_string($normalized) || trim($normalized) === '') {
			return ['ok' => false, 'message' => 'Schema JSON could not be normalized for saving.', 'json' => ''];
		}

		return ['ok' => true, 'message' => '', 'json' => $normalized];
	}

	private static function decode_schema_json_with_fallback(string $candidate): ?array {
		$candidate = trim((string) $candidate);
		if ($candidate === '') {
			return null;
		}

		$attempts = [];
		$attempts[] = $candidate;

		$first_json = self::extract_first_complete_json_candidate($candidate);
		if ($first_json !== '' && $first_json !== $candidate) {
			$attempts[] = $first_json;
		}

		$compact = preg_replace('~[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]~', '', $candidate);
		if (is_string($compact) && $compact !== '' && $compact !== $candidate) {
			$attempts[] = $compact;
		}

		if (function_exists('wp_check_invalid_utf8')) {
			$utf8_clean = (string) wp_check_invalid_utf8($candidate, true);
			if ($utf8_clean !== '' && $utf8_clean !== $candidate) {
				$attempts[] = $utf8_clean;
			}
		}

		$repaired = self::repair_common_schema_json_issues($candidate);
		if ($repaired !== '' && $repaired !== $candidate) {
			$attempts[] = $repaired;
			$repaired_first_json = self::extract_first_complete_json_candidate($repaired);
			if ($repaired_first_json !== '' && $repaired_first_json !== $repaired) {
				$attempts[] = $repaired_first_json;
			}
		}

		foreach ($attempts as $attempt) {
			$attempt = trim((string) $attempt);
			if ($attempt === '') {
				continue;
			}
			$attempt = self::normalize_text_encoding_utf8($attempt);
			$decoded = json_decode($attempt, true);
			if (is_array($decoded)) {
				return $decoded;
			}
		}

		return null;
	}

	private static function normalize_text_encoding_utf8(string $text): string {
		$text = (string) $text;
		if ($text === '') {
			return '';
		}

		if (function_exists('mb_detect_encoding') && function_exists('mb_convert_encoding')) {
			if (mb_detect_encoding($text, 'UTF-8', true) !== false) {
				return $text;
			}
			foreach (['Windows-1252', 'ISO-8859-1', 'ISO-8859-15'] as $src) {
				$converted = @mb_convert_encoding($text, 'UTF-8', $src);
				if (is_string($converted) && $converted !== '' && mb_detect_encoding($converted, 'UTF-8', true) !== false) {
					return $converted;
				}
			}
		}

		if (function_exists('iconv')) {
			foreach (['Windows-1252', 'ISO-8859-1', 'ISO-8859-15'] as $src) {
				$converted = @iconv($src, 'UTF-8//IGNORE', $text);
				if (is_string($converted) && $converted !== '') {
					return $converted;
				}
			}
		}

		if (function_exists('wp_check_invalid_utf8')) {
			$cleaned = (string) wp_check_invalid_utf8($text, true);
			if ($cleaned !== '') {
				return $cleaned;
			}
		}

		return $text;
	}

	private static function repair_common_schema_json_issues(string $text): string {
		$text = trim((string) $text);
		if ($text === '') {
			return '';
		}

		// Remove trailing commas before object/array close.
		$text = preg_replace('~,\s*([}\]])~', '$1', $text);
		$text = is_string($text) ? $text : '';
		if ($text === '') {
			return '';
		}

		// Remove duplicated braces (e.g. "{{" / "}}") outside string literals.
		$len = strlen($text);
		$out = '';
		$in_string = false;
		$escaped = false;
		$prev_sig = '';
		for ($i = 0; $i < $len; $i++) {
			$ch = $text[$i];

			if ($in_string) {
				$out .= $ch;
				if ($escaped) {
					$escaped = false;
					continue;
				}
				if ($ch === '\\') {
					$escaped = true;
					continue;
				}
				if ($ch === '"') {
					$in_string = false;
				}
				continue;
			}

			if ($ch === '"') {
				$in_string = true;
				$out .= $ch;
				$prev_sig = '"';
				continue;
			}

			if (($ch === '{' || $ch === '}') && $prev_sig === $ch) {
				continue;
			}

			$out .= $ch;
			if (!ctype_space($ch)) {
				$prev_sig = $ch;
			}
		}

		return trim($out);
	}

	private static function strip_utf8_bom(string $text): string {
		if (strncmp($text, "\xEF\xBB\xBF", 3) === 0) {
			return substr($text, 3);
		}
		return $text;
	}

	private static function normalize_schema_raw_text(string $text): string {
		$text = (string) $text;
		$text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$text = str_replace("\xC2\xA0", ' ', $text);
		$text = strtr($text, [
			"\xE2\x80\x9C" => '"',
			"\xE2\x80\x9D" => '"',
			"\xE2\x80\x98" => "'",
			"\xE2\x80\x99" => "'",
		]);
		$text = preg_replace('~[\x{200B}-\x{200D}\x{FEFF}\x{E000}-\x{F8FF}]~u', '', (string) $text);
		$text = preg_replace('~^[\s\|\-\*\x{2022}]+~u', '', (string) $text);
		$text = preg_replace('~[\s\|\-\*\x{2022}]+$~u', '', (string) $text);
		return trim((string) $text);
	}

	private static function trim_to_first_json_start(string $text): string {
		$text = trim((string) $text);
		if ($text === '') {
			return '';
		}
		$first_object = strpos($text, '{');
		$first_array = strpos($text, '[');
		if ($first_object === false && $first_array === false) {
			return '';
		}
		if ($first_object === false) {
			$start = (int) $first_array;
		} elseif ($first_array === false) {
			$start = (int) $first_object;
		} else {
			$start = min((int) $first_object, (int) $first_array);
		}
		return trim((string) substr($text, $start));
	}

	private static function extract_first_complete_json_candidate(string $text): string {
		$text = trim((string) $text);
		if ($text === '') {
			return '';
		}

		$start_pos = null;
		$in_string = false;
		$escaped = false;
		$obj_depth = 0;
		$arr_depth = 0;
		$len = strlen($text);

		for ($i = 0; $i < $len; $i++) {
			$ch = $text[$i];

			if ($start_pos === null) {
				if ($ch === '{' || $ch === '[') {
					$start_pos = $i;
					if ($ch === '{') {
						$obj_depth = 1;
					} else {
						$arr_depth = 1;
					}
				}
				continue;
			}

			if ($in_string) {
				if ($escaped) {
					$escaped = false;
					continue;
				}
				if ($ch === '\\') {
					$escaped = true;
					continue;
				}
				if ($ch === '"') {
					$in_string = false;
				}
				continue;
			}

			if ($ch === '"') {
				$in_string = true;
				continue;
			}
			if ($ch === '{') {
				$obj_depth++;
				continue;
			}
			if ($ch === '}') {
				$obj_depth--;
			} elseif ($ch === '[') {
				$arr_depth++;
			} elseif ($ch === ']') {
				$arr_depth--;
			}

			if ($obj_depth === 0 && $arr_depth === 0) {
				return trim((string) substr($text, (int) $start_pos, $i - (int) $start_pos + 1));
			}
		}

		return '';
	}

	private static function is_schema_placeholder_value(string $value): bool {
		$value = strtolower(trim((string) $value));
		$value = preg_replace('~\s+~u', ' ', (string) $value);
		$placeholders = [
			'json',
			'json-ld',
			'json ld',
			'ld+json',
			'application/json',
			'application/ld+json',
			'schema',
			'schema json',
			'schema json-ld',
		];
		return in_array((string) $value, $placeholders, true);
	}

	/**
	 * Collect schema value from label line + continuation lines.
	 * Handles "Schema: json" followed by multiline JSON body and skips odd wrapper symbols.
	 */
	private static function collect_schema_block_from_lines(array $lines, int $schema_line, string $initial_value): array {
		$total = count($lines);
		$line_idx = max(0, min($schema_line, max(0, $total - 1)));
		$value = self::normalize_schema_raw_text($initial_value);
		$end_line = $line_idx;

		$parts = [];
		if ($value !== '' && !self::is_schema_placeholder_value($value)) {
			$inline_json = self::trim_to_first_json_start($value);
			if ($inline_json !== '') {
				$parts[] = $inline_json;
			}
		}
		$seed_first_part = isset($parts[0]) ? trim((string) $parts[0]) : '';
		$skip_first_duplicate_seed = ($seed_first_part === '{' || $seed_first_part === '[');

		$has_json_start = (strpos($value, '{') !== false || strpos($value, '[') !== false);
		$scan_following = !$has_json_start || self::is_schema_placeholder_value($value) || empty($parts);
		$combined = trim(implode("\n", $parts));

		if (self::schema_json_appears_complete($combined)) {
			return ['value' => $combined, 'end_line' => $end_line];
		}
		if (!$scan_following) {
			// If schema starts with "{" or "[" but is not complete yet, keep scanning.
			$scan_following = true;
		}

		if ($scan_following) {
			for ($i = $line_idx + 1; $i < $total; $i++) {
				$raw_line = (string) $lines[$i];
				$trimmed = trim($raw_line);
				if ($trimmed === '') {
					$end_line = $i;
					continue;
				}

				$norm = self::normalize_label_line($trimmed);
				if (self::is_any_label_line($norm)) {
					break;
				}

				$clean = self::normalize_schema_raw_text($raw_line);
				if (empty($parts)) {
					$clean = self::trim_to_first_json_start($clean);
				}
				// Avoid duplicated opening token when extract_field_from_lines already
				// captured the next line value (e.g. Schema:\n{ ...).
				if (
					$skip_first_duplicate_seed &&
					$i === ($line_idx + 1) &&
					trim((string) $clean) === $seed_first_part
				) {
					$end_line = $i;
					continue;
				}
				if ($clean !== '') {
					$parts[] = $clean;
					$combined = trim(implode("\n", $parts));
					$end_line = $i;
					if (self::schema_json_appears_complete($combined)) {
						break;
					}
				}
			}
		}

		$combined = trim(implode("\n", $parts));
		return ['value' => $combined, 'end_line' => $end_line];
	}

	private static function schema_json_appears_complete(string $text): bool {
		$text = trim((string) $text);
		if ($text === '' || (strpos($text, '{') === false && strpos($text, '[') === false)) {
			return false;
		}

		$in_string = false;
		$escaped = false;
		$obj_depth = 0;
		$arr_depth = 0;
		$started = false;
		$len = strlen($text);

		for ($i = 0; $i < $len; $i++) {
			$ch = $text[$i];
			if ($in_string) {
				if ($escaped) {
					$escaped = false;
					continue;
				}
				if ($ch === '\\') {
					$escaped = true;
					continue;
				}
				if ($ch === '"') {
					$in_string = false;
				}
				continue;
			}

			if ($ch === '"') {
				$in_string = true;
				continue;
			}
			if ($ch === '{') {
				$obj_depth++;
				$started = true;
				continue;
			}
			if ($ch === '}') {
				$obj_depth--;
				continue;
			}
			if ($ch === '[') {
				$arr_depth++;
				$started = true;
				continue;
			}
			if ($ch === ']') {
				$arr_depth--;
				continue;
			}
		}

		return $started && $obj_depth === 0 && $arr_depth === 0;
	}

	private static function validate_docx_image_references(array $data, array $docx_images): array {
		$required_rel_ids = [];
		$featured_rel_id = trim((string) ($data['featured_image_rel_id'] ?? ''));
		if ($featured_rel_id !== '') {
			$required_rel_ids[] = $featured_rel_id;
		}
		$body_rel_ids = is_array($data['body_image_rel_ids'] ?? null) ? $data['body_image_rel_ids'] : [];
		foreach ($body_rel_ids as $rid) {
			$rid = trim((string) $rid);
			if ($rid !== '') {
				$required_rel_ids[] = $rid;
			}
		}
		$required_rel_ids = array_values(array_unique($required_rel_ids));
		foreach ($required_rel_ids as $rid) {
			if (!isset($docx_images[$rid])) {
				return ['ok' => false, 'message' => 'DOCX image reference "' . $rid . '" could not be resolved from word/media.'];
			}
		}
		return ['ok' => true, 'message' => ''];
	}

	private static function find_post_by_slug(string $slug): ?WP_Post {
		$results = get_posts([
			'post_type' => 'post',
			'post_status' => 'any',
			'name' => $slug,
			'numberposts' => 1,
			'suppress_filters' => true,
		]);

		if (is_array($results) && !empty($results[0]) && $results[0] instanceof WP_Post) {
			return $results[0];
		}

		return null;
	}

	private static function save_post_and_meta(?WP_Post $existing, array $data, string $slug, string $schema_json, string $source_file): array {
		$title = trim((string) ($data['h1_blog_title'] ?? ''));
		$content = trim((string) ($data['body'] ?? ''));
		$seo_title = trim((string) ($data['title_tag'] ?? ''));
		$meta_desc = trim((string) ($data['meta_description'] ?? ''));
		$excerpt = trim((string) ($data['excerpt'] ?? ''));
		$requested_lang = (string) ($data['language'] ?? '');
		$categories = is_array($data['categories'] ?? null) ? $data['categories'] : [];
		$tags = is_array($data['tags'] ?? null) ? $data['tags'] : [];
		$page_type = (string) ($data['page_type'] ?? '');
		$has_categories_label = !empty($data['_has_categories_label']);
		$has_tags_label = !empty($data['_has_tags_label']);
		$has_page_type_label = !empty($data['_has_page_type_label']);
		$featured_image_rel_id = trim((string) ($data['featured_image_rel_id'] ?? ''));
		$featured_image_alt = trim((string) ($data['featured_image_alt'] ?? ''));
		$body_image_rel_ids = is_array($data['body_image_rel_ids'] ?? null) ? array_values(array_map('strval', $data['body_image_rel_ids'])) : [];
		$content_image_alts = is_array($data['content_image_alts'] ?? null) ? array_values(array_map('strval', $data['content_image_alts'])) : [];
		$docx_images = is_array($data['_docx_images'] ?? null) ? $data['_docx_images'] : [];
		$image_name_suggestions = is_array($data['image_name_suggestions'] ?? null) ? $data['image_name_suggestions'] : [];

		if ($existing instanceof WP_Post) {
			$post_id = (int) $existing->ID;
			$updated = wp_update_post([
				'ID' => $post_id,
				'post_type' => 'post',
				'post_status' => 'draft',
				'post_title' => $title,
				'post_name' => $slug,
				'post_excerpt' => $excerpt,
				'post_content' => $content,
			], true);

			if (is_wp_error($updated)) {
				return ['ok' => false, 'message' => 'Failed to update post: ' . $updated->get_error_message(), 'post_id' => 0];
			}
		} else {
			$created = wp_insert_post([
				'post_type' => 'post',
				'post_status' => 'draft',
				'post_title' => $title,
				'post_name' => $slug,
				'post_excerpt' => $excerpt,
				'post_content' => $content,
			], true);

			if (is_wp_error($created) || !(int) $created) {
				$message = is_wp_error($created) ? $created->get_error_message() : 'Unknown create error.';
				return ['ok' => false, 'message' => 'Failed to create draft post: ' . $message, 'post_id' => 0];
			}
			$post_id = (int) $created;
		}

		update_post_meta($post_id, self::META_SEO_TITLE, $seo_title);
		update_post_meta($post_id, self::META_META_DESCRIPTION, $meta_desc);
		if ($schema_json !== '') {
			update_post_meta($post_id, self::META_SCHEMA, $schema_json);
		}
		update_post_meta($post_id, self::META_IMPORT_MARKER, $source_file);

		$notes = [];
		$image_map = self::import_docx_images_to_media_library($post_id, $docx_images, $image_name_suggestions);
		if (!empty($body_image_rel_ids)) {
			$content_with_images = self::replace_docx_image_placeholders($content, $image_map, $content_image_alts);
			$update_content = wp_update_post([
				'ID' => $post_id,
				'post_content' => $content_with_images,
			], true);
			if (is_wp_error($update_content)) {
				return ['ok' => false, 'message' => 'Failed to save content images: ' . $update_content->get_error_message(), 'post_id' => $post_id];
			}
			foreach ($body_image_rel_ids as $idx => $rid) {
				$rid = (string) $rid;
				$alt = trim((string) ($content_image_alts[$idx] ?? ''));
				$attachment_id = (int) ($image_map[$rid]['attachment_id'] ?? 0);
				if ($attachment_id > 0 && $alt !== '') {
					update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
				}
			}
			$notes[] = 'Content images imported: ' . count($body_image_rel_ids) . '.';
		}
		if ($featured_image_rel_id !== '') {
			$featured_attachment_id = (int) ($image_map[$featured_image_rel_id]['attachment_id'] ?? 0);
			if ($featured_attachment_id < 1) {
				return ['ok' => false, 'message' => 'Failed to import featured image from DOCX media.', 'post_id' => $post_id];
			}
			set_post_thumbnail($post_id, $featured_attachment_id);
			if ($featured_image_alt !== '') {
				update_post_meta($featured_attachment_id, '_wp_attachment_image_alt', $featured_image_alt);
			}
			$notes[] = 'Featured image imported.';
		}

		if ($has_categories_label) {
			$cat_ids_result = self::upsert_category_terms($categories);
			if (!$cat_ids_result['ok']) {
				return ['ok' => false, 'message' => (string) $cat_ids_result['message'], 'post_id' => $post_id];
			}
			$cat_ids = is_array($cat_ids_result['ids'] ?? null) ? $cat_ids_result['ids'] : [];
			$set_categories = wp_set_post_terms($post_id, $cat_ids, 'category', false);
			if (is_wp_error($set_categories)) {
				return ['ok' => false, 'message' => 'Failed to assign categories: ' . $set_categories->get_error_message(), 'post_id' => $post_id];
			}
			$notes[] = 'Categories updated.';
		}

		if ($has_tags_label) {
			$set_tags = wp_set_post_terms($post_id, $tags, 'post_tag', false);
			if (is_wp_error($set_tags)) {
				return ['ok' => false, 'message' => 'Failed to assign tags: ' . $set_tags->get_error_message(), 'post_id' => $post_id];
			}
			$notes[] = 'Tags updated.';
		}

		if ($has_page_type_label) {
			if ($page_type === '') {
				delete_post_meta($post_id, 'vite_page_type');
				$notes[] = 'Page Type cleared.';
			} else {
				update_post_meta($post_id, 'vite_page_type', $page_type);
				$notes[] = 'Page Type set to "' . $page_type . '".';
			}
		}

		$language_result = self::resolve_polylang_language($requested_lang);
		if (!empty($language_result['active'])) {
			$target_lang = (string) ($language_result['lang'] ?? '');
			if ($target_lang !== '') {
				$set_ok = pll_set_post_language($post_id, $target_lang);
				if ($set_ok === false) {
					$note = 'Polylang language could not be set to "' . $target_lang . '".';
					$existing_note = trim((string) ($language_result['note'] ?? ''));
					if ($existing_note !== '') {
						$note .= ' ' . $existing_note;
					}
					if (!empty($notes)) {
						$note .= ' ' . implode(' ', $notes);
					}
					return ['ok' => true, 'message' => trim($note), 'post_id' => $post_id];
				}
			}
		}

		$lang_note = trim((string) ($language_result['note'] ?? ''));
		if ($lang_note !== '') {
			$notes[] = $lang_note;
		}
		return ['ok' => true, 'message' => implode(' ', $notes), 'post_id' => $post_id];
	}

	private static function import_docx_images_to_media_library(int $post_id, array $docx_images, array $image_name_suggestions = []): array {
		$map = [];
		if (empty($docx_images)) {
			return $map;
		}
		if (!function_exists('wp_generate_attachment_metadata')) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
		$basename_counts = [];

		foreach ($docx_images as $rid => $asset) {
			$rid = trim((string) $rid);
			if ($rid === '' || !is_array($asset)) {
				continue;
			}
			$binary = $asset['binary'] ?? '';
			if (!is_string($binary) || $binary === '') {
				continue;
			}
			$original_filename = sanitize_file_name((string) ($asset['filename'] ?? ($rid . '.bin')));
			$ext = strtolower((string) pathinfo($original_filename, PATHINFO_EXTENSION));
			if ($ext === '') {
				$ext = 'bin';
			}
			$converted = self::convert_image_binary_for_import($binary, $ext);
			$binary = (string) ($converted['binary'] ?? $binary);
			$ext = strtolower((string) ($converted['ext'] ?? $ext));
			$mime_override = (string) ($converted['mime'] ?? '');
			$name_seed = trim((string) ($image_name_suggestions[$rid] ?? ''));
			if ($name_seed === '') {
				$name_seed = (string) pathinfo($original_filename, PATHINFO_FILENAME);
			}
			$base = self::normalize_image_base_name($name_seed);
			if ($base === '') {
				$base = self::normalize_image_base_name($rid);
			}
			if ($base === '') {
				$base = 'image';
			}
			$count = (int) ($basename_counts[$base] ?? 0) + 1;
			$basename_counts[$base] = $count;
			$final_base = $count > 1 ? ($base . '-' . $count) : $base;
			$filename = sanitize_file_name($final_base . '.' . $ext);
			$uploaded = wp_upload_bits($filename, null, $binary);
			if (!is_array($uploaded) || !empty($uploaded['error']) || empty($uploaded['file'])) {
				continue;
			}
			$file_path = (string) $uploaded['file'];
			$file_url = (string) ($uploaded['url'] ?? '');
			$file_type = wp_check_filetype($file_path, null);
			$attachment = [
				'post_mime_type' => ($mime_override !== '' ? $mime_override : (string) ($file_type['type'] ?? ($asset['mime'] ?? 'application/octet-stream'))),
				'post_title' => sanitize_text_field(str_replace('-', ' ', (string) pathinfo($filename, PATHINFO_FILENAME))),
				'post_content' => '',
				'post_status' => 'inherit',
			];
			$attachment_id = wp_insert_attachment($attachment, $file_path, $post_id, true);
			if (is_wp_error($attachment_id) || (int) $attachment_id < 1) {
				continue;
			}
			$attachment_id = (int) $attachment_id;
			$meta = wp_generate_attachment_metadata($attachment_id, $file_path);
			if (is_array($meta)) {
				wp_update_attachment_metadata($attachment_id, $meta);
			}
			$map[$rid] = [
				'attachment_id' => $attachment_id,
				'url' => $file_url,
			];
		}
		return $map;
	}

	private static function convert_image_binary_for_import(string $binary, string $ext): array {
		$ext = strtolower(trim($ext));
		if (!in_array($ext, ['jpg', 'jpeg', 'png'], true)) {
			return ['binary' => $binary, 'ext' => $ext, 'mime' => ''];
		}
		$converted = self::convert_binary_to_webp_with_size_limit($binary);
		if (!$converted['ok']) {
			return ['binary' => $binary, 'ext' => $ext, 'mime' => ''];
		}
		return [
			'binary' => (string) ($converted['binary'] ?? $binary),
			'ext' => 'webp',
			'mime' => 'image/webp',
		];
	}

	private static function convert_binary_to_webp_with_size_limit(string $binary): array {
		$target_bytes = self::MAX_IMAGE_KB * 1024;
		$steps = self::WEBP_QUALITY_STEPS;
		if (empty($steps)) {
			$steps = [82];
		}
		$best = '';
		foreach ($steps as $q) {
			$quality = (int) $q;
			if ($quality < 1 || $quality > 100) {
				continue;
			}
			$current = self::encode_binary_to_webp($binary, $quality);
			if ($current === '') {
				continue;
			}
			$best = $current;
			if (strlen($current) <= $target_bytes) {
				return ['ok' => true, 'binary' => $current];
			}
		}
		if ($best !== '' && strlen($best) <= $target_bytes) {
			return ['ok' => true, 'binary' => $best];
		}
		return ['ok' => false, 'binary' => ''];
	}

	private static function encode_binary_to_webp(string $binary, int $quality): string {
		$encoded = self::encode_binary_to_webp_imagick($binary, $quality);
		if ($encoded !== '') {
			return $encoded;
		}
		return self::encode_binary_to_webp_gd($binary, $quality);
	}

	private static function encode_binary_to_webp_imagick(string $binary, int $quality): string {
		if (!class_exists('Imagick')) {
			return '';
		}
		try {
			$img = new Imagick();
			$img->readImageBlob($binary);
			if (method_exists($img, 'setImageBackgroundColor')) {
				$img->setImageBackgroundColor(new ImagickPixel('transparent'));
			}
			if (method_exists($img, 'setImageFormat')) {
				$img->setImageFormat('webp');
			}
			if (method_exists($img, 'setImageCompressionQuality')) {
				$img->setImageCompressionQuality($quality);
			}
			$out = $img->getImagesBlob();
			$img->clear();
			$img->destroy();
			return is_string($out) ? $out : '';
		} catch (\Throwable $e) {
			return '';
		}
	}

	private static function encode_binary_to_webp_gd(string $binary, int $quality): string {
		if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
			return '';
		}
		$img = @imagecreatefromstring($binary);
		if (!$img) {
			return '';
		}
		if (function_exists('imagepalettetotruecolor')) {
			@imagepalettetotruecolor($img);
		}
		if (function_exists('imagealphablending')) {
			@imagealphablending($img, true);
		}
		if (function_exists('imagesavealpha')) {
			@imagesavealpha($img, true);
		}
		ob_start();
		$ok = @imagewebp($img, null, $quality);
		$out = ob_get_clean();
		imagedestroy($img);
		if (!$ok || !is_string($out) || $out === '') {
			return '';
		}
		return $out;
	}

	private static function normalize_image_base_name(string $value): string {
		$value = trim($value);
		if ($value === '') {
			return '';
		}
		$value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$base = sanitize_title($value);
		if ($base !== '') {
			return $base;
		}
		$value = preg_replace('~[^a-z0-9]+~i', '-', strtolower($value));
		$value = trim((string) $value, '-');
		return $value;
	}

	private static function replace_docx_image_placeholders(string $content, array $image_map, array $content_image_alts): string {
		if ($content === '' || strpos($content, '[[DOCX_IMAGE:') === false) {
			return $content;
		}
		$counter = 0;
		$result = preg_replace_callback('~\[\[DOCX_IMAGE:([^\]]+)\]\]~', static function (array $m) use (&$counter, $image_map, $content_image_alts): string {
			$rid = trim((string) ($m[1] ?? ''));
			$alt = trim((string) ($content_image_alts[$counter] ?? ''));
			$counter++;
			if ($rid === '' || !isset($image_map[$rid])) {
				return '';
			}
			$attachment_id = (int) ($image_map[$rid]['attachment_id'] ?? 0);
			if ($attachment_id < 1) {
				return '';
			}
			return self::render_content_image_html($attachment_id, $alt);
		}, $content);
		return is_string($result) ? $result : $content;
	}

	private static function render_content_image_html(int $attachment_id, string $alt): string {
		$attrs = [
			'class' => 'wp-image-' . $attachment_id,
			'loading' => 'lazy',
		];
		if ($alt !== '') {
			$attrs['alt'] = $alt;
		}
		$html = wp_get_attachment_image($attachment_id, 'full', false, $attrs);
		if (is_string($html) && $html !== '') {
			return $html;
		}
		$url = wp_get_attachment_url($attachment_id);
		if (!is_string($url) || $url === '') {
			return '';
		}
		return '<img src="' . esc_url($url) . '" class="wp-image-' . (int) $attachment_id . '" alt="' . esc_attr($alt) . '" loading="lazy" />';
	}

	private static function log_row(int $row, string $file, string $slug, string $post, string $status, string $details): array {
		return [
			'row' => $row,
			'file' => $file,
			'slug' => $slug,
			'post' => $post,
			'status' => $status,
			'details' => $details,
		];
	}

	private static function fatal_result(string $message): array {
		return [
			'ok' => false,
			'message' => $message,
			'mode' => 'dry_run',
			'summary' => [
				'total_files' => 0,
				'would_import' => 0,
				'imported' => 0,
				'skipped' => 0,
				'failed' => 0,
			],
			'rows' => [],
		];
	}

	private static function render_result(array $result): void {
		if (empty($result['ok'])) {
			echo '<div class="notice notice-error"><p>' . esc_html((string) ($result['message'] ?? 'Import failed.')) . '</p></div>';
			return;
		}

		$mode = (string) ($result['mode'] ?? 'dry_run');
		$summary = is_array($result['summary'] ?? null) ? $result['summary'] : [];
		$requirements = is_array($result['requirements'] ?? null) ? $result['requirements'] : [];
		$rows = is_array($result['rows'] ?? null) ? $result['rows'] : [];

		echo '<div class="vite-docx-card vite-docx-result-card">';
		echo '<h2 style="margin-top:0;">Result: ' . esc_html($mode === 'apply' ? 'Apply Import' : 'Dry Run') . '</h2>';
		if ($mode === 'dry_run') {
			echo '<p class="description">Dry Run is a safe preview. It validates each file and shows what would happen, but it does not create or update any posts.</p>';
		} else {
			echo '<p class="description">Apply Import writes changes now. Files marked as Imported were saved as draft posts with their SEO fields.</p>';
		}
		echo '<p><strong>Validation used:</strong> '
			. 'Strict labels: <code>' . esc_html(!empty($requirements['strict_labels']) ? 'yes' : 'no') . '</code>, '
			. 'Require Title Tag: <code>' . esc_html(!empty($requirements['require_title_tag']) ? 'yes' : 'no') . '</code>, '
			. 'Require Meta Description: <code>' . esc_html(!empty($requirements['require_meta_description']) ? 'yes' : 'no') . '</code>, '
			. 'Require H1 label: <code>' . esc_html(!empty($requirements['require_h1']) ? 'yes' : 'no') . '</code>, '
			. 'Require Body label: <code>' . esc_html(!empty($requirements['require_body_label']) ? 'yes' : 'no') . '</code>, '
			. 'Allow duplicate slug in ZIP: <code>' . esc_html(!empty($requirements['allow_duplicate_slug_zip']) ? 'yes' : 'no') . '</code>.'
			. '</p>';
		echo '<div class="vite-docx-summary-grid">';
		echo '<div class="vite-docx-summary-item"><span class="vite-docx-summary-item__label">Total files processed</span><span class="vite-docx-summary-item__value">' . esc_html((string) ($summary['total_files'] ?? 0)) . '</span></div>';
		echo '<div class="vite-docx-summary-item"><span class="vite-docx-summary-item__label">Would Import (dry run)</span><span class="vite-docx-summary-item__value">' . esc_html((string) ($summary['would_import'] ?? 0)) . '</span></div>';
		echo '<div class="vite-docx-summary-item"><span class="vite-docx-summary-item__label">Imported (apply)</span><span class="vite-docx-summary-item__value">' . esc_html((string) ($summary['imported'] ?? 0)) . '</span></div>';
		echo '<div class="vite-docx-summary-item"><span class="vite-docx-summary-item__label">Skipped</span><span class="vite-docx-summary-item__value">' . esc_html((string) ($summary['skipped'] ?? 0)) . '</span></div>';
		echo '<div class="vite-docx-summary-item"><span class="vite-docx-summary-item__label">Failed</span><span class="vite-docx-summary-item__value">' . esc_html((string) ($summary['failed'] ?? 0)) . '</span></div>';
		echo '</div>';
		echo '<p class="description" style="margin-top:8px;">Status guide: <strong>Would Import</strong> = ready, <strong>Imported</strong> = saved, <strong>Skipped</strong> = intentionally ignored, <strong>Failed</strong> = needs correction.</p>';
		echo '</div>';

		if (empty($rows)) {
			return;
		}

		echo '<h3 style="margin-top:20px;">Detailed Log</h3>';
		echo '<table class="widefat striped fixed vite-docx-log-table">';
		echo '<thead><tr>';
		echo '<th style="width:56px;">#</th>';
		echo '<th style="width:24%;">File</th>';
		echo '<th style="width:14%;">Slug</th>';
		echo '<th style="width:20%;">Post</th>';
		echo '<th style="width:12%;">Status</th>';
		echo '<th>Details</th>';
		echo '</tr></thead><tbody>';

		foreach ($rows as $row) {
			$status = (string) ($row['status'] ?? '');
			$pill_class = 'vite-docx-status-pill vite-docx-status-pill--neutral';
			if ($status === 'Imported' || $status === 'Would Import') {
				$pill_class = 'vite-docx-status-pill vite-docx-status-pill--success';
			} elseif ($status === 'Skipped') {
				$pill_class = 'vite-docx-status-pill vite-docx-status-pill--warn';
			} elseif ($status === 'Failed') {
				$pill_class = 'vite-docx-status-pill vite-docx-status-pill--error';
			}

			echo '<tr>';
			echo '<td>' . esc_html((string) ($row['row'] ?? '')) . '</td>';
			echo '<td><code>' . esc_html((string) ($row['file'] ?? '')) . '</code></td>';
			echo '<td><code>' . esc_html((string) ($row['slug'] ?? '')) . '</code></td>';
			echo '<td>' . esc_html((string) ($row['post'] ?? '')) . '</td>';
			echo '<td><span class="' . esc_attr($pill_class) . '">' . esc_html($status) . '</span></td>';
			echo '<td>' . esc_html((string) ($row['details'] ?? '')) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}
}

Vite_DOCX_Bulk_Draft_Importer::init();

