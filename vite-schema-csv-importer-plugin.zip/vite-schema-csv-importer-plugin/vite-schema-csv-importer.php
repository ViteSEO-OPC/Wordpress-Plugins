<?php
/**
 * Plugin Name: Vite Schema CSV Importer
 * Description: Admin tool to import post SEO/meta updates from CSV with dry run, detailed logs, and export-ready image audit columns.
 * Version: 2.0.0
 * Author: Vite SEO
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('vite_render_seo_tools_landing')) {
	function vite_render_seo_tools_landing(): void {
		echo '<div class="wrap"><h1>SEO Tools</h1><p>Use the submenu items to open each SEO tool.</p></div>';
	}
}

if (!function_exists('vite_register_seo_tools_menu')) {
	function vite_register_seo_tools_menu(): void {
		static $added = false;
		if ($added) {
			return;
		}

		add_menu_page(
			'SEO Tools',
			'SEO Tools',
			'edit_posts',
			'vite-seo-tools',
			'vite_render_seo_tools_landing',
			'dashicons-chart-area',
			58
		);

		$added = true;
	}
}

final class Vite_Schema_CSV_Importer {
	const PAGE_SLUG = 'vite-schema-csv-importer';
	const META_SCHEMA = 'vite_schema_jsonld';
	const META_SEO_TITLE = 'vite_seo_title';
	const META_META_DESCRIPTION = 'vite_meta_description';
	const META_META_ROBOTS = 'vite_meta_robots';
	const META_PAGE_TYPE = 'vite_page_type';
	const MAX_ROWS = 5000;
	const EXPORT_BATCH_DEFAULT = 150;

	public static function init(): void {
		add_action('admin_menu', [__CLASS__, 'register_page']);
		add_action('admin_post_vite_schema_csv_download_sample', [__CLASS__, 'handle_sample_download']);
		add_action('admin_post_vite_schema_csv_download_posts', [__CLASS__, 'handle_posts_download']);
	}

	public static function register_page(): void {
		vite_register_seo_tools_menu();
		add_submenu_page(
			'vite-seo-tools',
			'Schema CSV Importer',
			'Schema CSV Importer',
			'manage_options',
			self::PAGE_SLUG,
			[__CLASS__, 'render_page']
		);
	}

	public static function render_page(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}

		$result = null;
		$overwrite_existing = !empty($_POST['vite_schema_csv_overwrite_existing']);
		if (
			isset($_POST['vite_schema_csv_action'], $_POST['vite_schema_csv_nonce']) &&
			wp_verify_nonce((string) $_POST['vite_schema_csv_nonce'], 'vite_schema_csv_import')
		) {
			$action = sanitize_key((string) $_POST['vite_schema_csv_action']);
			$mode = $action === 'apply' ? 'apply' : 'dry_run';
			$result = self::process_upload($mode, $overwrite_existing);
		}

		self::render_admin_styles();
		echo '<div class="wrap vite-schema-csv-page">';
		echo '<div class="vite-schema-csv-page__header">';
		echo '<h1 style="margin:0;">Schema CSV Importer</h1>';
		echo '</div>';
		self::render_docs_modal();
		echo '<div class="vite-schema-csv-card">';
		echo '<p>Upload a CSV with at least one identifier column: <code>CONTENT_ID</code>, <code>SLUG</code>, or <code>POST_LINK</code>. Editable optional columns: <code>TITLE</code>, <code>EXCERPT</code>, <code>LANG</code>, <code>SCHEMA</code>, <code>SEO_TITLE</code>, <code>META_DESCRIPTION</code>, <code>META_ROBOTS</code>, <code>CATEGORIES</code>, <code>TAGS</code>, <code>PAGE_TYPE</code>, <code>FEATURED_IMAGE_ALT</code>, <code>CONTENT_IMAGE_ALT</code>.</p>';
		echo '<p><strong>URL columns:</strong> <code>POST_LINK</code> is the canonical encoded URL (used for matching). <code>POST_LINK_READABLE</code> is export-only for easier reading of non-Latin URLs (for example Korean) and is ignored during import.</p>';
		echo '<p><strong>Image rule:</strong> <code>FEATURED_IMAGE_URL</code>, <code>FEATURED_IMAGE_SIZE_KB</code>, <code>FEATURED_IMAGE_TYPE</code>, <code>CONTENT_IMAGE_URLS</code>, <code>CONTENT_IMAGE_SIZES_KB</code>, and <code>CONTENT_IMAGE_TYPES</code> are export-only reference columns and are never updated by import.</p>';
		echo '<p><strong>Post scope:</strong> post type <code>post</code> only, any status (published, draft, pending, private, etc.).</p>';
		echo '<p><strong>Language matching:</strong> <code>LANG</code> is optional. If provided, it validates language for the matched post. If blank, <code>CONTENT_ID</code>/<code>POST_LINK</code> can match any language; slug lookup uses default language fallback.</p>';
		echo '</div>';
		self::render_export_posts_card();

		echo '<form method="post" enctype="multipart/form-data" class="vite-schema-csv-card vite-schema-csv-form-card">';
		wp_nonce_field('vite_schema_csv_import', 'vite_schema_csv_nonce');
		echo '<p><label for="vite_schema_csv_file"><strong>CSV file</strong></label><br />';
		echo '<input class="vite-schema-csv-file-input" type="file" id="vite_schema_csv_file" name="vite_schema_csv_file" accept=".csv,text/csv" required /></p>';
		echo '<p><label><input type="checkbox" name="vite_schema_csv_overwrite_existing" value="1" ' . checked($overwrite_existing, true, false) . ' /> Replace existing values using CSV (recommended only when your CSV is final and already QA-checked)</label></p>';
		echo '<p class="vite-schema-csv-actions">';
		echo '<button type="submit" class="button button-secondary" name="vite_schema_csv_action" value="dry_run">Dry Run (Preview Only)</button>';
		echo '<button type="submit" class="button button-primary" name="vite_schema_csv_action" value="apply">Apply Import</button>';
		echo '<button type="button" class="button vite-schema-csv-guide-btn" id="vite-schema-csv-open-guide" aria-haspopup="dialog" aria-controls="vite-schema-csv-guide-modal">Open Guide</button>';
		echo '</p>';
		echo '<p class="description"><strong>Unchecked (safer):</strong> only fills empty fields and keeps existing values. <strong>Checked (replace mode):</strong> updates existing values in editable columns you provided in CSV. Read-only image URL/size/type columns stay unchanged in both modes.</p>';
		echo '</form>';

		if (is_array($result)) {
			self::render_result($result);
		}

		echo '</div>';
	}

	private static function render_export_posts_card(): void {
		$filters = self::get_export_filters_from_request();
		$total_posts = self::count_exportable_posts($filters);
		$per_page = self::get_export_batch_size_from_request();
		$total_pages = max(1, (int) ceil($total_posts / max(1, $per_page)));
		$sizes = [50, 100, 150];

		echo '<div class="vite-schema-csv-card">';
		echo '<h2 style="margin-top:0;">Download Current Posts CSV</h2>';
		echo '<p class="description">Use this to export existing post data with all supported headers (including CONTENT_ID and POST_LINK). To reduce server load, download in batches (recommended: 150 rows per file).</p>';
		echo '<p><strong>Total posts available:</strong> ' . esc_html((string) $total_posts) . '</p>';
		echo '<form method="get" class="vite-schema-csv-export-size" style="margin-top:10px;">';
		echo '<input type="hidden" name="page" value="' . esc_attr(self::PAGE_SLUG) . '" />';
		echo '<label for="vite-schema-export-month"><strong>Month</strong></label>';
		echo '<input id="vite-schema-export-month" type="month" name="export_month" value="' . esc_attr($filters['month']) . '" />';
		echo '<label for="vite-schema-export-date-from"><strong>Date from</strong></label>';
		echo '<input id="vite-schema-export-date-from" type="date" name="export_date_from" value="' . esc_attr($filters['date_from']) . '" />';
		echo '<label for="vite-schema-export-date-to"><strong>Date to</strong></label>';
		echo '<input id="vite-schema-export-date-to" type="date" name="export_date_to" value="' . esc_attr($filters['date_to']) . '" />';
		echo '<button type="submit" class="button button-secondary">Apply Filter</button>';
		if ($filters['month'] !== '' || $filters['date_from'] !== '' || $filters['date_to'] !== '') {
			$clear_url = add_query_arg(['page' => self::PAGE_SLUG], admin_url('admin.php'));
			echo '<a class="button" href="' . esc_url($clear_url) . '">Clear Filter</a>';
		}
		echo '</form>';

		echo '<div class="vite-schema-csv-export-size">';
		echo '<span><strong>Batch size:</strong></span>';
		foreach ($sizes as $size) {
			$url = add_query_arg(
				[
					'page' => self::PAGE_SLUG,
					'export_per_page' => $size,
					'export_month' => $filters['month'],
					'export_date_from' => $filters['date_from'],
					'export_date_to' => $filters['date_to'],
				],
				admin_url('admin.php')
			);
			$cls = 'button button-small' . ($size === $per_page ? ' button-primary' : ' button-secondary');
			echo '<a class="' . esc_attr($cls) . '" href="' . esc_url($url) . '">' . esc_html((string) $size) . ' / file</a>';
		}
		echo '</div>';

		if ($total_posts <= 0) {
			echo '<p class="description">No posts found to export yet.</p>';
			echo '</div>';
			return;
		}

		echo '<div class="vite-schema-csv-export-phases">';
		for ($phase = 1; $phase <= $total_pages; $phase++) {
			$start = (($phase - 1) * $per_page) + 1;
			$end = min($phase * $per_page, $total_posts);
			$download_url = wp_nonce_url(
				add_query_arg(
					[
						'action' => 'vite_schema_csv_download_posts',
						'phase' => $phase,
						'per_page' => $per_page,
						'export_month' => $filters['month'],
						'export_date_from' => $filters['date_from'],
						'export_date_to' => $filters['date_to'],
					],
					admin_url('admin-post.php')
				),
				'vite_schema_csv_download_posts'
			);
			echo '<a class="button button-secondary button-small" href="' . esc_url($download_url) . '">Phase ' . esc_html((string) $phase) . ' (' . esc_html((string) $start) . '-' . esc_html((string) $end) . ')</a>';
		}
		echo '</div>';
		echo '<p class="description" style="margin-top:8px;">Example: 600 posts with 150/file gives 4 phase buttons.</p>';
		echo '</div>';
	}

	private static function count_exportable_posts(array $filters = []): int {
		$post_statuses = array_values(array_diff(get_post_stati(['internal' => false]), ['trash', 'auto-draft', 'inherit']));
		if (!$post_statuses) {
			$post_statuses = ['publish', 'draft', 'pending', 'future', 'private'];
		}
		$args = [
			'post_type' => 'post',
			'post_status' => $post_statuses,
			'posts_per_page' => 1,
			'paged' => 1,
			'fields' => 'ids',
			'no_found_rows' => false,
			'suppress_filters' => false,
		];
		$date_query = self::build_export_date_query($filters['month'] ?? '', $filters['date_from'] ?? '', $filters['date_to'] ?? '');
		if ($date_query) {
			$args['date_query'] = $date_query;
		}
		$q = new WP_Query($args);
		return max(0, (int) $q->found_posts);
	}

	private static function get_export_batch_size_from_request(): int {
		$raw = isset($_GET['export_per_page']) ? (int) $_GET['export_per_page'] : self::EXPORT_BATCH_DEFAULT;
		return in_array($raw, [50, 100, 150], true) ? $raw : self::EXPORT_BATCH_DEFAULT;
	}

	private static function sanitize_month_filter(string $value): string {
		$value = trim($value);
		return preg_match('/^\d{4}-\d{2}$/', $value) ? $value : '';
	}

	private static function sanitize_date_filter(string $value): string {
		$value = trim($value);
		return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : '';
	}

	private static function get_export_filters_from_request(): array {
		return [
			'month' => isset($_GET['export_month']) ? self::sanitize_month_filter((string) $_GET['export_month']) : '',
			'date_from' => isset($_GET['export_date_from']) ? self::sanitize_date_filter((string) $_GET['export_date_from']) : '',
			'date_to' => isset($_GET['export_date_to']) ? self::sanitize_date_filter((string) $_GET['export_date_to']) : '',
		];
	}

	private static function build_export_date_query(string $month, string $date_from, string $date_to): array {
		if ($month !== '') {
			$parts = explode('-', $month);
			$year = isset($parts[0]) ? (int) $parts[0] : 0;
			$month_num = isset($parts[1]) ? (int) $parts[1] : 0;
			if ($year > 0 && $month_num >= 1 && $month_num <= 12) {
				return [[
					'year' => $year,
					'monthnum' => $month_num,
				]];
			}
		}
		if ($date_from !== '' || $date_to !== '') {
			$rule = ['inclusive' => true];
			if ($date_from !== '') {
				$rule['after'] = $date_from;
			}
			if ($date_to !== '') {
				$rule['before'] = $date_to;
			}
			return [$rule];
		}
		return [];
	}

	private static function process_upload(string $mode, bool $overwrite_existing): array {
		$is_apply = $mode === 'apply';

		if (empty($_FILES['vite_schema_csv_file']) || !is_array($_FILES['vite_schema_csv_file'])) {
			return self::fatal_result('No CSV file was uploaded.');
		}

		$file = $_FILES['vite_schema_csv_file'];
		$error_code = isset($file['error']) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
		if ($error_code !== UPLOAD_ERR_OK) {
			return self::fatal_result('Upload failed. Please try again and make sure the file is a valid CSV.');
		}

		$tmp_name = isset($file['tmp_name']) ? (string) $file['tmp_name'] : '';
		if ($tmp_name === '' || !is_uploaded_file($tmp_name)) {
			return self::fatal_result('Uploaded file could not be verified.');
		}

		$handle = fopen($tmp_name, 'r');
		if (!is_resource($handle)) {
			return self::fatal_result('Could not open the uploaded CSV file.');
		}

		$header = self::read_csv_row($handle);
		if (!is_array($header) || empty($header)) {
			fclose($handle);
			return self::fatal_result('CSV appears empty or the header row is missing.');
		}

		$indexes = self::resolve_header_indexes($header);
		if (empty($indexes['has_identifier'])) {
			fclose($handle);
			return self::fatal_result('CSV header must include at least one identifier column: CONTENT_ID, SLUG, or POST_LINK.');
		}
		if (!$indexes['has_payload']) {
			fclose($handle);
			return self::fatal_result('CSV must include at least one supported editable column: TITLE, EXCERPT, SCHEMA, SEO_TITLE, META_DESCRIPTION, META_ROBOTS, CATEGORIES, TAGS, PAGE_TYPE, FEATURED_IMAGE_ALT, or CONTENT_IMAGE_ALT.');
		}

		$rows = [];
		$seen_targets = [];
		$row_number = 1;
		$total = 0;

		$summary = [
			'total_rows' => 0,
			'would_import' => 0,
			'imported' => 0,
			'skipped_no_changes' => 0,
			'skipped_duplicate' => 0,
			'failed' => 0,
		];

		while (($csv_row = self::read_csv_row($handle)) !== false) {
			$row_number++;
			$total++;
			if ($total > self::MAX_ROWS) {
				$rows[] = self::log_row($row_number, '', '', '', 'Failed', 'Import stopped: too many rows. Limit is ' . self::MAX_ROWS . ' rows per upload.');
				$summary['failed']++;
				break;
			}

			$content_id_raw = $indexes['content_id'] >= 0 ? trim((string) ($csv_row[$indexes['content_id']] ?? '')) : '';
			$slug_lookup_raw = $indexes['slug'] >= 0 ? trim((string) ($csv_row[$indexes['slug']] ?? '')) : '';
			$post_link_raw = $indexes['post_link'] >= 0 ? trim((string) ($csv_row[$indexes['post_link']] ?? '')) : '';
			$schema_raw = $indexes['schema'] >= 0 ? trim((string) ($csv_row[$indexes['schema']] ?? '')) : '';
			$seo_title_raw = $indexes['seo_title'] >= 0 ? trim((string) ($csv_row[$indexes['seo_title']] ?? '')) : '';
			$meta_desc_raw = $indexes['meta_description'] >= 0 ? trim((string) ($csv_row[$indexes['meta_description']] ?? '')) : '';
			$meta_robots_raw = $indexes['meta_robots'] >= 0 ? trim((string) ($csv_row[$indexes['meta_robots']] ?? '')) : '';
			$lang_raw = $indexes['lang'] >= 0 ? trim((string) ($csv_row[$indexes['lang']] ?? '')) : '';
			$post_title_raw = $indexes['post_title'] >= 0 ? trim((string) ($csv_row[$indexes['post_title']] ?? '')) : '';
			$post_excerpt_raw = $indexes['post_excerpt'] >= 0 ? trim((string) ($csv_row[$indexes['post_excerpt']] ?? '')) : '';
			$categories_raw = $indexes['categories'] >= 0 ? trim((string) ($csv_row[$indexes['categories']] ?? '')) : '';
			$tags_raw = $indexes['tags'] >= 0 ? trim((string) ($csv_row[$indexes['tags']] ?? '')) : '';
			$page_type_raw = $indexes['page_type'] >= 0 ? trim((string) ($csv_row[$indexes['page_type']] ?? '')) : '';
			$featured_image_alt_raw = $indexes['featured_image_alt'] >= 0 ? trim((string) ($csv_row[$indexes['featured_image_alt']] ?? '')) : '';
			$content_image_alt_raw = $indexes['content_image_alt'] >= 0 ? trim((string) ($csv_row[$indexes['content_image_alt']] ?? '')) : '';
			$featured_image_url_raw = $indexes['featured_image_url'] >= 0 ? trim((string) ($csv_row[$indexes['featured_image_url']] ?? '')) : '';
			$featured_image_size_raw = $indexes['featured_image_size_kb'] >= 0 ? trim((string) ($csv_row[$indexes['featured_image_size_kb']] ?? '')) : '';
			$featured_image_type_raw = $indexes['featured_image_type'] >= 0 ? trim((string) ($csv_row[$indexes['featured_image_type']] ?? '')) : '';
			$content_image_urls_raw = $indexes['content_image_urls'] >= 0 ? trim((string) ($csv_row[$indexes['content_image_urls']] ?? '')) : '';
			$content_image_sizes_raw = $indexes['content_image_sizes_kb'] >= 0 ? trim((string) ($csv_row[$indexes['content_image_sizes_kb']] ?? '')) : '';
			$content_image_types_raw = $indexes['content_image_types'] >= 0 ? trim((string) ($csv_row[$indexes['content_image_types']] ?? '')) : '';

			if ($content_id_raw === '' && $slug_lookup_raw === '' && $post_link_raw === '' && $post_title_raw === '' && $post_excerpt_raw === '' && $schema_raw === '' && $seo_title_raw === '' && $meta_desc_raw === '' && $meta_robots_raw === '' && $categories_raw === '' && $tags_raw === '' && $page_type_raw === '' && $featured_image_alt_raw === '' && $content_image_alt_raw === '' && $featured_image_url_raw === '' && $featured_image_size_raw === '' && $featured_image_type_raw === '' && $content_image_urls_raw === '' && $content_image_sizes_raw === '' && $content_image_types_raw === '') {
				$rows[] = self::log_row($row_number, '', '', '', 'Skipped', 'Row is empty, so it was skipped.');
				continue;
			}

			$schema_info = self::normalize_schema_json($schema_raw);
			if (!$schema_info['ok']) {
				$rows[] = self::log_row($row_number, $content_id_raw !== '' ? $content_id_raw : ($slug_lookup_raw !== '' ? $slug_lookup_raw : $post_link_raw), '', '', 'Failed', $schema_info['message']);
				$summary['failed']++;
				continue;
			}

			$robots_info = self::normalize_meta_robots($meta_robots_raw);
			if (!$robots_info['ok']) {
				$rows[] = self::log_row($row_number, $content_id_raw !== '' ? $content_id_raw : ($slug_lookup_raw !== '' ? $slug_lookup_raw : $post_link_raw), '', '', 'Failed', $robots_info['message']);
				$summary['failed']++;
				continue;
			}

			$lang_info = self::normalize_lang($lang_raw);
			if (!$lang_info['ok']) {
				$rows[] = self::log_row($row_number, $content_id_raw !== '' ? $content_id_raw : ($slug_lookup_raw !== '' ? $slug_lookup_raw : $post_link_raw), '', '', 'Failed', $lang_info['message']);
				$summary['failed']++;
				continue;
			}
			$lang = (string) $lang_info['lang'];
			$lang_is_explicit = ($indexes['lang'] >= 0 && $lang_raw !== '');

			$resolved = self::find_post_from_identifiers($content_id_raw, $slug_lookup_raw, $post_link_raw, $lang, $lang_is_explicit);
			if (!$resolved['ok']) {
				$rows[] = self::log_row($row_number, (string) ($resolved['lookup'] ?? ''), (string) ($resolved['slug'] ?? ''), '', 'Failed', (string) ($resolved['message'] ?? 'No matching post found.'));
				$summary['failed']++;
				continue;
			}

			$post = $resolved['post'] ?? null;
			if (!$post instanceof WP_Post) {
				$rows[] = self::log_row($row_number, (string) ($resolved['lookup'] ?? ''), (string) ($resolved['slug'] ?? ''), '', 'Failed', 'No matching blog post was found.');
				$summary['failed']++;
				continue;
			}
			$slug = (string) ($resolved['slug'] ?? '');
			$lookup_value = (string) ($resolved['lookup'] ?? '');
			$matched_by = (string) ($resolved['matched_by'] ?? '');

			$dedupe_key = ((int) $post->ID) . '|' . ($lang_is_explicit ? $lang : 'any');
			if (isset($seen_targets[$dedupe_key])) {
				$rows[] = self::log_row($row_number, $lookup_value, $slug, '', 'Skipped', 'Duplicate target found in CSV. A previous row already targeted this post for language "' . $lang . '".');
				$summary['skipped_duplicate']++;
				continue;
			}
			$seen_targets[$dedupe_key] = true;
			$post_label = sprintf('#%d - %s', (int) $post->ID, get_the_title($post->ID) ?: '(No title)');

			$payload = [
				'schema' => $schema_info['json'],
				'seo_title' => $seo_title_raw,
				'meta_description' => $meta_desc_raw,
				'meta_robots' => $robots_info['value'],
			];
			$meta_keys = [
				'schema' => self::META_SCHEMA,
				'seo_title' => self::META_SEO_TITLE,
				'meta_description' => self::META_META_DESCRIPTION,
				'meta_robots' => self::META_META_ROBOTS,
			];

			$changes = [];
			$provided_fields = [];
			foreach ($payload as $field => $new_value) {
				$new_value = is_string($new_value) ? trim($new_value) : '';
				if ($new_value === '') {
					continue;
				}
				$provided_fields[] = $field;
				$current = trim((string) get_post_meta((int) $post->ID, $meta_keys[$field], true));
				if ($overwrite_existing || $current === '') {
					if ($current !== $new_value) {
						$changes[$field] = $new_value;
					}
				}
			}

			$categories = self::normalize_terms_list($categories_raw);
			$tags = self::normalize_terms_list($tags_raw);
			$page_type = self::normalize_page_type_value($page_type_raw);
			$post_title = sanitize_text_field($post_title_raw);
			$post_excerpt = sanitize_textarea_field($post_excerpt_raw);
			$target_slug = '';
			if ($indexes['slug'] >= 0 && $slug_lookup_raw !== '') {
				$slug_change_info = self::normalize_lookup_slug($slug_lookup_raw);
				if (!$slug_change_info['ok']) {
					$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Failed', $slug_change_info['message']);
					$summary['failed']++;
					continue;
				}
				$target_slug = (string) $slug_change_info['slug'];
			}
			$has_categories = ($indexes['categories'] >= 0 && $categories_raw !== '');
			$has_tags = ($indexes['tags'] >= 0 && $tags_raw !== '');
			$has_page_type = ($indexes['page_type'] >= 0 && $page_type_raw !== '');
			$has_post_title = ($indexes['post_title'] >= 0 && $post_title_raw !== '');
			$has_post_excerpt = ($indexes['post_excerpt'] >= 0 && $post_excerpt_raw !== '');

			if ($has_page_type && $page_type === '') {
				$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Failed', 'PAGE_TYPE is invalid. Allowed values: glossary, pillar, hub, section.');
				$summary['failed']++;
				continue;
			}
			if ($has_post_title) {
				$provided_fields[] = 'post_title';
				$current_post_title = trim((string) $post->post_title);
				if (($overwrite_existing || $current_post_title === '') && $current_post_title !== $post_title) {
					$changes['post_title'] = $post_title;
				}
			}

			if ($has_post_excerpt) {
				$provided_fields[] = 'post_excerpt';
				$current_post_excerpt = trim((string) $post->post_excerpt);
				if (($overwrite_existing || $current_post_excerpt === '') && $current_post_excerpt !== $post_excerpt) {
					$changes['post_excerpt'] = $post_excerpt;
				}
			}

			if ($target_slug !== '') {
				$provided_fields[] = 'slug';
				$current_post_slug = trim((string) $post->post_name);
				if (($overwrite_existing || $current_post_slug === '') && $current_post_slug !== $target_slug) {
					if ($matched_by !== 'slug') {
						$changes['slug'] = $target_slug;
					}
				}
			}

			if ($has_categories) {
				$provided_fields[] = 'categories';
				$current_categories = wp_get_post_terms((int) $post->ID, 'category', ['fields' => 'ids']);
				$current_categories = is_array($current_categories) ? array_values(array_filter(array_map('intval', $current_categories))) : [];
				if ($overwrite_existing || empty($current_categories)) {
					$cat_ids_info = self::upsert_category_ids($categories);
					if (!$cat_ids_info['ok']) {
						$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Failed', (string) $cat_ids_info['message']);
						$summary['failed']++;
						continue;
					}
					$new_cat_ids = is_array($cat_ids_info['ids']) ? $cat_ids_info['ids'] : [];
					sort($new_cat_ids);
					$compare_current = $current_categories;
					sort($compare_current);
					if ($compare_current !== $new_cat_ids) {
						$changes['categories'] = $new_cat_ids;
					}
				}
			}

			if ($has_tags) {
				$provided_fields[] = 'tags';
				$current_tags = wp_get_post_terms((int) $post->ID, 'post_tag', ['fields' => 'names']);
				$current_tags = is_array($current_tags) ? array_values(array_filter(array_map('strval', $current_tags))) : [];
				$normalized_current_tags = self::normalize_terms_list(implode(',', $current_tags));
				if ($overwrite_existing || empty($normalized_current_tags)) {
					if ($normalized_current_tags !== $tags) {
						$changes['tags'] = $tags;
					}
				}
			}

			if ($has_page_type) {
				$provided_fields[] = 'page_type';
				$current_page_type = trim((string) get_post_meta((int) $post->ID, self::META_PAGE_TYPE, true));
				if ($overwrite_existing || $current_page_type === '') {
					if ($current_page_type !== $page_type) {
						$changes['page_type'] = $page_type;
					}
				}
			}

			$has_featured_image_alt = ($indexes['featured_image_alt'] >= 0 && $featured_image_alt_raw !== '');
			if ($has_featured_image_alt) {
				$provided_fields[] = 'featured_image_alt';
				$current_featured_alt = self::get_featured_image_alt((int) $post->ID);
				$new_featured_alt = sanitize_text_field($featured_image_alt_raw);
				if (($overwrite_existing || $current_featured_alt === '') && $current_featured_alt !== $new_featured_alt) {
					$changes['featured_image_alt'] = $new_featured_alt;
				}
			}

			$has_content_image_alt = ($indexes['content_image_alt'] >= 0 && $content_image_alt_raw !== '');
			if ($has_content_image_alt) {
				$provided_fields[] = 'content_image_alt';
				$current_content_alt = self::content_image_alt_text_for_post($post);
				$new_content_alt = self::normalize_content_image_alt_cell($content_image_alt_raw);
				if (($overwrite_existing || $current_content_alt === '') && $current_content_alt !== $new_content_alt) {
					$changes['content_image_alt'] = $new_content_alt;
				}
			}

			if (empty($provided_fields)) {
				$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Skipped', 'No supported values were provided in this CSV row.');
				$summary['skipped_no_changes']++;
				continue;
			}

			if (empty($changes)) {
				$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Skipped', $overwrite_existing ? 'CSV values match existing post values. No changes made.' : 'Post already has values for provided fields. No changes made.');
				$summary['skipped_no_changes']++;
				continue;
			}

			if ($is_apply) {
				$post_update = ['ID' => (int) $post->ID];
				$has_post_update = false;
				if (isset($changes['post_title'])) {
					$post_update['post_title'] = (string) $changes['post_title'];
					$has_post_update = true;
				}
				if (isset($changes['post_excerpt'])) {
					$post_update['post_excerpt'] = (string) $changes['post_excerpt'];
					$has_post_update = true;
				}
				if (isset($changes['slug'])) {
					$post_update['post_name'] = (string) $changes['slug'];
					$has_post_update = true;
				}
				if ($has_post_update) {
					$update_result = wp_update_post($post_update, true);
					if (is_wp_error($update_result)) {
						$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Failed', 'Could not update post title/excerpt/slug: ' . $update_result->get_error_message());
						$summary['failed']++;
						continue;
					}
				}

				foreach ($changes as $field => $value) {
					if ($field === 'post_title' || $field === 'post_excerpt' || $field === 'slug') {
						continue;
					}
					if ($field === 'categories') {
						wp_set_post_terms((int) $post->ID, is_array($value) ? $value : [], 'category', false);
						continue;
					}
					if ($field === 'tags') {
						wp_set_post_terms((int) $post->ID, is_array($value) ? $value : [], 'post_tag', false);
						continue;
					}
					if ($field === 'page_type') {
						update_post_meta((int) $post->ID, self::META_PAGE_TYPE, (string) $value);
						continue;
					}
					if ($field === 'featured_image_alt') {
						self::update_featured_image_alt((int) $post->ID, (string) $value);
						continue;
					}
					if ($field === 'content_image_alt') {
						self::update_content_image_alt($post, (string) $value);
						continue;
					}
					update_post_meta((int) $post->ID, $meta_keys[$field], $value);
				}
				$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Imported', 'Updated fields: ' . self::human_fields(array_keys($changes)) . '.');
				$summary['imported']++;
			} else {
				$rows[] = self::log_row($row_number, $lookup_value, $slug, $post_label, 'Would Import', 'Would update fields: ' . self::human_fields(array_keys($changes)) . '.');
				$summary['would_import']++;
			}
		}

		fclose($handle);
		$summary['total_rows'] = count($rows);

		return [
			'ok' => true,
			'mode' => $is_apply ? 'apply' : 'dry_run',
			'overwrite_existing' => $overwrite_existing,
			'summary' => $summary,
			'rows' => $rows,
		];
	}

	private static function resolve_header_indexes(array $header): array {
		$index_content_id = -1;
		$index_slug = -1;
		$index_post_link = -1;
		$index_schema = -1;
		$index_seo_title = -1;
		$index_meta_description = -1;
		$index_meta_robots = -1;
		$index_lang = -1;
		$index_post_title = -1;
		$index_post_excerpt = -1;
		$index_categories = -1;
		$index_tags = -1;
		$index_page_type = -1;
		$index_featured_image_url = -1;
		$index_featured_image_size_kb = -1;
		$index_featured_image_type = -1;
		$index_featured_image_alt = -1;
		$index_content_image_urls = -1;
		$index_content_image_sizes_kb = -1;
		$index_content_image_types = -1;
		$index_content_image_alt = -1;

		foreach ($header as $i => $label) {
			$key = strtolower(trim((string) $label));
			$key = preg_replace('~[^a-z0-9]+~', '_', (string) $key);
			$key = trim((string) $key, '_');

			if (in_array($key, ['content_id', 'post_id', 'id'], true) && $index_content_id < 0) {
				$index_content_id = (int) $i;
			}
			if (in_array($key, ['slug', 'lookup_slug'], true) && $index_slug < 0) {
				$index_slug = (int) $i;
			}
			if (in_array($key, ['post_link', 'link', 'url', 'permalink'], true) && $index_post_link < 0) {
				$index_post_link = (int) $i;
			}
			if (in_array($key, ['schema', 'schema_json', 'schema_jsonld', 'json_ld', 'schema_json_ld'], true) && $index_schema < 0) {
				$index_schema = (int) $i;
			}
			if (in_array($key, ['seo_title', 'title_tag', 'meta_title'], true) && $index_seo_title < 0) {
				$index_seo_title = (int) $i;
			}
			if (in_array($key, ['meta_description', 'seo_meta_description', 'seo_description', 'description'], true) && $index_meta_description < 0) {
				$index_meta_description = (int) $i;
			}
			if (in_array($key, ['meta_robots', 'robots'], true) && $index_meta_robots < 0) {
				$index_meta_robots = (int) $i;
			}
			if (in_array($key, ['lang', 'language', 'locale'], true) && $index_lang < 0) {
				$index_lang = (int) $i;
			}
			if (in_array($key, ['title', 'post_title', 'h1'], true) && $index_post_title < 0) {
				$index_post_title = (int) $i;
			}
			if (in_array($key, ['excerpt', 'post_excerpt'], true) && $index_post_excerpt < 0) {
				$index_post_excerpt = (int) $i;
			}
			if (in_array($key, ['categories', 'category'], true) && $index_categories < 0) {
				$index_categories = (int) $i;
			}
			if (in_array($key, ['tags', 'tag'], true) && $index_tags < 0) {
				$index_tags = (int) $i;
			}
			if (in_array($key, ['page_type', 'pagetype'], true) && $index_page_type < 0) {
				$index_page_type = (int) $i;
			}
			if (in_array($key, ['featured_image_url', 'featured_image_link', 'featured_image'], true) && $index_featured_image_url < 0) {
				$index_featured_image_url = (int) $i;
			}
			if (in_array($key, ['featured_image_size_kb', 'featured_image_size'], true) && $index_featured_image_size_kb < 0) {
				$index_featured_image_size_kb = (int) $i;
			}
			if (in_array($key, ['featured_image_type', 'featured_image_mime', 'featured_image_ext'], true) && $index_featured_image_type < 0) {
				$index_featured_image_type = (int) $i;
			}
			if (in_array($key, ['featured_image_alt', 'featured_alt', 'featured_alt_text'], true) && $index_featured_image_alt < 0) {
				$index_featured_image_alt = (int) $i;
			}
			if (in_array($key, ['content_image_urls', 'content_images_urls', 'content_image_links'], true) && $index_content_image_urls < 0) {
				$index_content_image_urls = (int) $i;
			}
			if (in_array($key, ['content_image_sizes_kb', 'content_images_sizes_kb', 'content_image_sizes'], true) && $index_content_image_sizes_kb < 0) {
				$index_content_image_sizes_kb = (int) $i;
			}
			if (in_array($key, ['content_image_types', 'content_images_types', 'content_image_type'], true) && $index_content_image_types < 0) {
				$index_content_image_types = (int) $i;
			}
			if (in_array($key, ['content_image_alt', 'content_images_alt', 'content_alt_text'], true) && $index_content_image_alt < 0) {
				$index_content_image_alt = (int) $i;
			}
		}

		return [
			'content_id' => $index_content_id,
			'slug' => $index_slug,
			'post_link' => $index_post_link,
			'schema' => $index_schema,
			'seo_title' => $index_seo_title,
			'meta_description' => $index_meta_description,
			'meta_robots' => $index_meta_robots,
			'lang' => $index_lang,
			'post_title' => $index_post_title,
			'post_excerpt' => $index_post_excerpt,
			'categories' => $index_categories,
			'tags' => $index_tags,
			'page_type' => $index_page_type,
			'featured_image_url' => $index_featured_image_url,
			'featured_image_size_kb' => $index_featured_image_size_kb,
			'featured_image_type' => $index_featured_image_type,
			'featured_image_alt' => $index_featured_image_alt,
			'content_image_urls' => $index_content_image_urls,
			'content_image_sizes_kb' => $index_content_image_sizes_kb,
			'content_image_types' => $index_content_image_types,
			'content_image_alt' => $index_content_image_alt,
			'has_identifier' => ($index_content_id >= 0 || $index_slug >= 0 || $index_post_link >= 0),
			'has_payload' => ($index_post_title >= 0 || $index_post_excerpt >= 0 || $index_schema >= 0 || $index_seo_title >= 0 || $index_meta_description >= 0 || $index_meta_robots >= 0 || $index_categories >= 0 || $index_tags >= 0 || $index_page_type >= 0 || $index_featured_image_alt >= 0 || $index_content_image_alt >= 0),
		];
	}

	private static function normalize_lookup_slug(string $raw_slug): array {
		$raw_slug = trim($raw_slug);
		$raw_slug = trim($raw_slug, "/ \t\n\r\0\x0B");
		if ($raw_slug === '') {
			return ['ok' => false, 'message' => 'SLUG is empty.', 'slug' => ''];
		}

		if (strpos($raw_slug, '://') !== false) {
			return ['ok' => false, 'message' => 'SLUG must not be a full URL. Use only the slug value (example: sample-post).', 'slug' => ''];
		}

		if (strpos($raw_slug, '/') !== false) {
			return ['ok' => false, 'message' => 'SLUG must be a single slug value, not a path. Example: sample-post', 'slug' => ''];
		}

		$slug = sanitize_title(rawurldecode($raw_slug));
		if ($slug === '') {
			return ['ok' => false, 'message' => 'SLUG is invalid or empty after sanitizing.', 'slug' => ''];
		}

		return ['ok' => true, 'message' => '', 'slug' => $slug];
	}

	private static function normalize_lookup_content_id(string $raw): array {
		$raw = trim($raw);
		if ($raw === '') {
			return ['ok' => false, 'message' => 'CONTENT_ID is empty.', 'id' => 0];
		}
		if (!preg_match('/^\d+$/', $raw)) {
			return ['ok' => false, 'message' => 'CONTENT_ID must be a numeric post ID.', 'id' => 0];
		}
		$id = (int) $raw;
		if ($id <= 0) {
			return ['ok' => false, 'message' => 'CONTENT_ID must be greater than 0.', 'id' => 0];
		}
		return ['ok' => true, 'message' => '', 'id' => $id];
	}

	private static function normalize_lookup_post_link(string $raw): array {
		$raw = trim(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
		if ($raw === '') {
			return ['ok' => false, 'message' => 'POST_LINK is empty.', 'url' => ''];
		}
		if (strpos($raw, '://') === false) {
			if (strpos($raw, '/') === 0) {
				$raw = home_url($raw);
			} else {
				$raw = home_url('/' . ltrim($raw, '/'));
			}
		}
		$raw = trim($raw);
		if (!wp_parse_url($raw, PHP_URL_SCHEME)) {
			return ['ok' => false, 'message' => 'POST_LINK is not a valid URL/path.', 'url' => ''];
		}
		return ['ok' => true, 'message' => '', 'url' => $raw];
	}

	private static function is_post_in_lang(int $post_id, string $lang): bool {
		if (!function_exists('pll_get_post_language')) {
			return true;
		}
		$post_lang = (string) pll_get_post_language($post_id, 'slug');
		return $post_lang === '' || $post_lang === $lang;
	}

	private static function find_post_from_identifiers(string $content_id_raw, string $slug_raw, string $post_link_raw, string $lang, bool $enforce_lang = false): array {
		$content_id_raw = trim($content_id_raw);
		$slug_raw = trim($slug_raw);
		$post_link_raw = trim($post_link_raw);

		if ($content_id_raw === '' && $slug_raw === '' && $post_link_raw === '') {
			return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => '', 'message' => 'Row is missing identifier. Provide CONTENT_ID, SLUG, or POST_LINK.'];
		}

		if ($content_id_raw !== '') {
			$id_info = self::normalize_lookup_content_id($content_id_raw);
			if (!$id_info['ok']) {
				return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $content_id_raw, 'message' => $id_info['message']];
			}
			$post_id = (int) $id_info['id'];
			$post = get_post($post_id);
			if ($post instanceof WP_Post && self::is_supported_import_post($post)) {
				if ($enforce_lang && !self::is_post_in_lang($post_id, $lang)) {
					return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $content_id_raw, 'matched_by' => 'content_id', 'message' => 'CONTENT_ID matches a post, but language does not match LANG "' . $lang . '".'];
				}
				return ['ok' => true, 'post' => $post, 'slug' => (string) $post->post_name, 'lookup' => $content_id_raw, 'matched_by' => 'content_id', 'message' => ''];
			}
			if ($post instanceof WP_Post && !self::is_supported_import_post($post)) {
				return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $content_id_raw, 'matched_by' => 'content_id', 'message' => 'CONTENT_ID ' . $post_id . ' belongs to post type "' . $post->post_type . '". This importer supports only "post".'];
			}
			return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $content_id_raw, 'matched_by' => 'content_id', 'message' => 'No blog post found for CONTENT_ID ' . $post_id . '.'];
		}

		if ($slug_raw !== '') {
			$slug_info = self::normalize_lookup_slug($slug_raw);
			if (!$slug_info['ok']) {
				return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $slug_raw, 'message' => $slug_info['message']];
			}
			$slug = (string) $slug_info['slug'];
			$post = self::find_post_by_slug($slug, $lang);
			if ($post instanceof WP_Post) {
				return ['ok' => true, 'post' => $post, 'slug' => $slug, 'lookup' => $slug_raw, 'matched_by' => 'slug', 'message' => ''];
			}
			return ['ok' => false, 'post' => null, 'slug' => $slug, 'lookup' => $slug_raw, 'matched_by' => 'slug', 'message' => 'No matching blog post was found for this slug in language "' . $lang . '".'];
		}

		$link_info = self::normalize_lookup_post_link($post_link_raw);
		if (!$link_info['ok']) {
			return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => $link_info['message']];
		}
		$link = (string) $link_info['url'];
		$post_id = url_to_postid($link);
		if ($post_id > 0) {
			$post = get_post($post_id);
			if ($post instanceof WP_Post && self::is_supported_import_post($post)) {
				if ($enforce_lang && !self::is_post_in_lang($post_id, $lang)) {
					return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => 'POST_LINK matches a post, but language does not match LANG "' . $lang . '".'];
				}
				return ['ok' => true, 'post' => $post, 'slug' => (string) $post->post_name, 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => ''];
			}
			if ($post instanceof WP_Post && !self::is_supported_import_post($post)) {
				return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => 'POST_LINK resolves to post type "' . $post->post_type . '". This importer supports only "post".'];
			}
		}

		$path = (string) wp_parse_url($link, PHP_URL_PATH);
		$path = trim($path, '/');
		if ($path !== '') {
			$segments = array_values(array_filter(explode('/', $path), static fn($p) => trim((string) $p) !== ''));
			$last = end($segments);
			$fallback_slug = sanitize_title((string) $last);
			if ($fallback_slug !== '') {
				$post = self::find_post_by_slug($fallback_slug, $lang);
				if ($post instanceof WP_Post) {
					return ['ok' => true, 'post' => $post, 'slug' => $fallback_slug, 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => ''];
				}
			}
		}

		return ['ok' => false, 'post' => null, 'slug' => '', 'lookup' => $post_link_raw, 'matched_by' => 'post_link', 'message' => 'No matching blog post was found for this POST_LINK.'];
	}

	private static function is_supported_import_post(WP_Post $post): bool {
		return $post->post_type === 'post';
	}

	private static function normalize_schema_json(string $schema_raw): array {
		$raw = trim($schema_raw);
		if ($raw === '') {
			return ['ok' => true, 'message' => '', 'json' => ''];
		}

		$raw = html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$raw = trim($raw);

		$candidate = $raw;
		if (preg_match('~<script[^>]*application/ld\+json[^>]*>(.*?)</script>~is', $raw, $m)) {
			$candidate = trim((string) ($m[1] ?? ''));
		} elseif (preg_match('~<script[^>]*>(.*?)</script>~is', $raw, $m)) {
			$candidate = trim((string) ($m[1] ?? ''));
		}

		$candidate = self::strip_utf8_bom($candidate);
		$candidate = trim($candidate);
		if ($candidate === '') {
			return ['ok' => false, 'message' => 'SCHEMA content is empty after removing script wrapper.', 'json' => ''];
		}

		// Normalize smart quotes often introduced by spreadsheet/editors.
		$candidate = strtr($candidate, [
			"\xE2\x80\x9C" => '"', // left double smart quote
			"\xE2\x80\x9D" => '"', // right double smart quote
			"\xE2\x80\x98" => "'", // left single smart quote
			"\xE2\x80\x99" => "'", // right single smart quote
		]);

		$decoded = self::decode_schema_candidate($candidate);
		if (!is_array($decoded)) {
			// Fallback: isolate first JSON object from noisy text.
			$first = strpos($candidate, '{');
			$last = strrpos($candidate, '}');
			if ($first !== false && $last !== false && $last > $first) {
				$extracted = substr($candidate, $first, ($last - $first + 1));
				$decoded = self::decode_schema_candidate($extracted);
			}
		}

		if (!is_array($decoded)) {
			return ['ok' => false, 'message' => 'SCHEMA is not valid JSON. Please check brackets, quotes, and commas.', 'json' => ''];
		}

		$normalized = wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if (!is_string($normalized) || trim($normalized) === '') {
			return ['ok' => false, 'message' => 'SCHEMA JSON could not be normalized.', 'json' => ''];
		}

		return ['ok' => true, 'message' => '', 'json' => $normalized];
	}

	/**
	 * Try to decode schema JSON from common CSV/spreadsheet forms:
	 * - plain JSON object/array
	 * - wrapped JSON string containing escaped JSON
	 * - slash-escaped JSON text
	 */
	private static function decode_schema_candidate(string $candidate): ?array {
		$attempts = [];
		$candidate = trim($candidate);
		$attempts[] = $candidate;

		// If field is wrapped as a quoted string, try inner content too.
		if (strlen($candidate) >= 2 && $candidate[0] === '"' && substr($candidate, -1) === '"') {
			$attempts[] = substr($candidate, 1, -1);
		}

		// Try unescaped variants commonly produced by CSV exports.
		$attempts[] = stripslashes($candidate);
		if (strlen($candidate) >= 2 && $candidate[0] === '"' && substr($candidate, -1) === '"') {
			$attempts[] = stripslashes(substr($candidate, 1, -1));
		}

		$attempts = array_values(array_unique(array_filter($attempts, static function ($v): bool {
			return is_string($v) && trim($v) !== '';
		})));

		foreach ($attempts as $attempt) {
			$attempt = self::normalize_text_encoding_utf8($attempt);
			$decoded = json_decode($attempt, true);
			if (is_array($decoded)) {
				return $decoded;
			}

			// Some CSV pipelines produce JSON encoded as a JSON string;
			// decode one more layer if needed.
			if (is_string($decoded)) {
				$decoded_twice = json_decode($decoded, true);
				if (is_array($decoded_twice)) {
					return $decoded_twice;
				}
			}
		}

		return null;
	}

	/**
	 * Normalize common spreadsheet/file encodings (Windows-1252/Latin-1) to UTF-8.
	 * json_decode requires valid UTF-8 and returns null on invalid byte sequences.
	 */
	private static function normalize_text_encoding_utf8(string $text): string {
		$text = trim((string) $text);
		if ($text === '') {
			return '';
		}

		if (function_exists('mb_detect_encoding') && function_exists('mb_convert_encoding')) {
			if (mb_detect_encoding($text, 'UTF-8', true) !== false) {
				return $text;
			}

			foreach (['Windows-1252', 'ISO-8859-1', 'ISO-8859-15'] as $source_encoding) {
				$converted = @mb_convert_encoding($text, 'UTF-8', $source_encoding);
				if (is_string($converted) && $converted !== '' && mb_detect_encoding($converted, 'UTF-8', true) !== false) {
					return $converted;
				}
			}
		}

		if (function_exists('iconv')) {
			foreach (['Windows-1252', 'ISO-8859-1', 'ISO-8859-15'] as $source_encoding) {
				$converted = @iconv($source_encoding, 'UTF-8//IGNORE', $text);
				if (is_string($converted) && $converted !== '') {
					return $converted;
				}
			}
		}

		// Last-resort cleanup for invalid UTF-8 bytes.
		$cleaned = wp_check_invalid_utf8($text, true);
		return is_string($cleaned) && $cleaned !== '' ? $cleaned : $text;
	}

	private static function normalize_meta_robots(string $raw): array {
		$value = strtolower(trim($raw));
		if ($value === '') {
			return ['ok' => true, 'message' => '', 'value' => ''];
		}
		$value = preg_replace('~\s+~', '', (string) $value);
		$allowed = [
			'index,follow',
			'noindex,follow',
			'index,nofollow',
			'noindex,nofollow',
		];
		if (!in_array($value, $allowed, true)) {
			return ['ok' => false, 'message' => 'META_ROBOTS value is invalid. Allowed: index,follow | noindex,follow | index,nofollow | noindex,nofollow.', 'value' => ''];
		}
		return ['ok' => true, 'message' => '', 'value' => $value];
	}

	private static function strip_utf8_bom(string $text): string {
		if (strncmp($text, "\xEF\xBB\xBF", 3) === 0) {
			return substr($text, 3);
		}
		return $text;
	}

	/**
	 * Read CSV rows with backslash escaping disabled.
	 *
	 * Some schema JSON values contain sequences like \"keyword\".
	 * With default fgetcsv escape (backslash), those can be transformed and break JSON.
	 */
	private static function read_csv_row($handle) {
		return fgetcsv($handle, 0, ',', '"', '');
	}

	private static function normalize_lang(string $raw): array {
		$lang = strtolower(trim($raw));

		if (function_exists('pll_languages_list')) {
			$allowed = pll_languages_list(['fields' => 'slug']);
			$allowed = is_array($allowed) ? array_values(array_unique(array_map('strtolower', $allowed))) : [];

			if (!$allowed) {
				return ['ok' => false, 'lang' => '', 'message' => 'Polylang has no configured languages.'];
			}

			if ($lang === '') {
				$default = function_exists('pll_default_language') ? (string) pll_default_language('slug') : '';
				$lang = $default !== '' ? strtolower($default) : (string) $allowed[0];
			}

			if (!in_array($lang, $allowed, true)) {
				return [
					'ok' => false,
					'lang' => '',
					'message' => 'LANG value "' . $lang . '" is not configured in Polylang. Allowed: ' . implode(', ', $allowed) . '.',
				];
			}

			return ['ok' => true, 'lang' => $lang, 'message' => ''];
		}

		// Fallback when Polylang is unavailable.
		if ($lang === '') {
			$lang = 'en';
		}

		return ['ok' => true, 'lang' => $lang, 'message' => ''];
	}

	private static function find_post_by_slug(string $slug, string $lang): ?WP_Post {
		$args = [
			'post_type' => 'post',
			'post_status' => 'any',
			'name' => $slug,
			'numberposts' => 1,
			'suppress_filters' => false, // Allow Polylang language filtering when available.
		];
		if (function_exists('pll_languages_list')) {
			$args['lang'] = $lang;
		}

		$by_slug = get_posts($args);
		if (is_array($by_slug) && !empty($by_slug[0]) && $by_slug[0] instanceof WP_Post) {
			return $by_slug[0];
		}

		return null;
	}

	private static function log_row(int $row, string $url, string $slug, string $post, string $status, string $message): array {
		return [
			'row' => $row,
			'url' => $url,
			'slug' => $slug,
			'post' => $post,
			'status' => $status,
			'message' => $message,
		];
	}

	private static function human_fields(array $fields): string {
		$labels = [
			'post_title' => 'Post Title',
			'post_excerpt' => 'Post Excerpt',
			'slug' => 'Slug',
			'schema' => 'Schema JSON',
			'seo_title' => 'SEO Title',
			'meta_description' => 'Meta Description',
			'meta_robots' => 'Meta Robots',
			'categories' => 'Categories',
			'tags' => 'Tags',
			'page_type' => 'Page Type',
			'featured_image_alt' => 'Featured Image Alt',
			'content_image_alt' => 'Content Image Alt',
		];
		$out = [];
		foreach ($fields as $f) {
			$out[] = $labels[$f] ?? $f;
		}
		return implode(', ', $out);
	}

	private static function normalize_terms_list(string $value): array {
		$value = trim($value);
		if ($value === '') {
			return [];
		}
		$parts = preg_split('~[\n\r,;|]+~', $value) ?: [];
		$out = [];
		foreach ($parts as $part) {
			$term = trim((string) $part);
			if ($term === '') {
				continue;
			}
			$out[] = $term;
		}
		return array_values(array_unique($out));
	}

	private static function normalize_page_type_value(string $value): string {
		$value = strtolower(trim($value));
		$value = str_replace(['_', '-'], ' ', $value);
		$value = preg_replace('~\s+~', ' ', (string) $value);
		$value = trim((string) $value);
		$allowed = [
			'glossary' => 'glossary',
			'pillar' => 'pillar',
			'hub' => 'hub',
			'section' => 'section',
		];
		return $allowed[$value] ?? '';
	}

	private static function upsert_category_ids(array $category_names): array {
		$ids = [];
		foreach ($category_names as $name) {
			$name = trim((string) $name);
			if ($name === '') {
				continue;
			}
			$term = get_term_by('name', $name, 'category');
			if (!$term || is_wp_error($term)) {
				$created = wp_insert_term($name, 'category');
				if (is_wp_error($created)) {
					return ['ok' => false, 'message' => 'Failed to create category "' . $name . '": ' . $created->get_error_message(), 'ids' => []];
				}
				$term_id = (int) ($created['term_id'] ?? 0);
			} else {
				$term_id = (int) $term->term_id;
			}
			if ($term_id > 0) {
				$ids[] = $term_id;
			}
		}
		return ['ok' => true, 'message' => '', 'ids' => array_values(array_unique($ids))];
	}

	private static function normalize_content_image_alt_cell(string $value): string {
		$value = trim($value);
		if ($value === '') {
			return '';
		}
		$parts = preg_split('~[\n\r|]+~', $value) ?: [];
		$out = [];
		foreach ($parts as $part) {
			$out[] = sanitize_text_field((string) $part);
		}
		return implode('|', $out);
	}

	private static function get_featured_image_alt(int $post_id): string {
		$thumb_id = (int) get_post_thumbnail_id($post_id);
		if ($thumb_id <= 0) {
			return '';
		}
		return trim((string) get_post_meta($thumb_id, '_wp_attachment_image_alt', true));
	}

	private static function update_featured_image_alt(int $post_id, string $alt_text): void {
		$thumb_id = (int) get_post_thumbnail_id($post_id);
		if ($thumb_id <= 0) {
			return;
		}
		update_post_meta($thumb_id, '_wp_attachment_image_alt', sanitize_text_field($alt_text));
	}

	private static function attachment_size_kb(int $attachment_id): string {
		if ($attachment_id <= 0) {
			return 'N/A';
		}
		$file = get_attached_file($attachment_id);
		if (!is_string($file) || $file === '' || !file_exists($file)) {
			return 'N/A';
		}
		$bytes = @filesize($file);
		if (!is_int($bytes) || $bytes <= 0) {
			return 'N/A';
		}
		return (string) round($bytes / 1024, 2);
	}

	private static function attachment_type(int $attachment_id, string $url = ''): string {
		if ($attachment_id > 0) {
			$mime = (string) get_post_mime_type($attachment_id);
			if ($mime !== '') {
				$slash = strrpos($mime, '/');
				if ($slash !== false) {
					return strtolower(substr($mime, $slash + 1));
				}
				return strtolower($mime);
			}
			$file = get_attached_file($attachment_id);
			$ext = is_string($file) ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
			if ($ext !== '') {
				return $ext;
			}
		}
		$from_url = strtolower(pathinfo((string) wp_parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
		return $from_url !== '' ? $from_url : 'N/A';
	}

	private static function featured_image_info_for_post(int $post_id): array {
		$thumb_id = (int) get_post_thumbnail_id($post_id);
		if ($thumb_id <= 0) {
			return ['url' => '', 'size_kb' => 'N/A', 'type' => 'N/A', 'alt' => ''];
		}
		$url = (string) wp_get_attachment_url($thumb_id);
		return [
			'url' => $url,
			'size_kb' => self::attachment_size_kb($thumb_id),
			'type' => self::attachment_type($thumb_id, $url),
			'alt' => trim((string) get_post_meta($thumb_id, '_wp_attachment_image_alt', true)),
		];
	}

	private static function content_image_data_from_post(WP_Post $post): array {
		$content = (string) $post->post_content;
		if ($content === '' || !preg_match_all('~<img\b[^>]*>~i', $content, $img_matches)) {
			return ['urls' => [], 'sizes_kb' => [], 'types' => [], 'alts' => []];
		}

		$urls = [];
		$sizes = [];
		$types = [];
		$alts = [];
		foreach ((array) $img_matches[0] as $img_tag) {
			$img_tag = (string) $img_tag;
			if (!preg_match('~\bsrc\s*=\s*["\']([^"\']+)["\']~i', $img_tag, $src_match)) {
				continue;
			}
			$src = trim((string) ($src_match[1] ?? ''));
			if ($src === '') {
				continue;
			}

			$attachment_id = 0;
			if (preg_match('~\bwp-image-(\d+)\b~i', $img_tag, $class_match)) {
				$attachment_id = (int) ($class_match[1] ?? 0);
			}
			if ($attachment_id <= 0) {
				$attachment_id = (int) attachment_url_to_postid($src);
			}

			$alt_attr = '';
			if (preg_match('~\balt\s*=\s*["\']([^"\']*)["\']~i', $img_tag, $alt_match)) {
				$alt_attr = trim((string) ($alt_match[1] ?? ''));
			}
			$alt_meta = $attachment_id > 0 ? trim((string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true)) : '';

			$urls[] = $src;
			$sizes[] = self::attachment_size_kb($attachment_id);
			$types[] = self::attachment_type($attachment_id, $src);
			$alts[] = $alt_meta !== '' ? $alt_meta : $alt_attr;
		}

		return ['urls' => $urls, 'sizes_kb' => $sizes, 'types' => $types, 'alts' => $alts];
	}

	private static function content_image_alt_text_for_post(WP_Post $post): string {
		$data = self::content_image_data_from_post($post);
		$alts = array_map(static fn($v) => sanitize_text_field((string) $v), (array) ($data['alts'] ?? []));
		return implode('|', $alts);
	}

	private static function make_readable_post_link(string $url): string {
		$url = trim($url);
		if ($url === '') {
			return '';
		}

		$parts = wp_parse_url($url);
		if (!is_array($parts) || empty($parts['host'])) {
			return $url;
		}

		$scheme = isset($parts['scheme']) ? (string) $parts['scheme'] . '://' : '';
		$user = isset($parts['user']) ? (string) $parts['user'] : '';
		$pass = isset($parts['pass']) ? ':' . (string) $parts['pass'] : '';
		$auth = $user !== '' ? $user . $pass . '@' : '';
		$host = (string) $parts['host'];
		$port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
		$path = isset($parts['path']) ? rawurldecode((string) $parts['path']) : '';
		$query = isset($parts['query']) ? '?' . (string) $parts['query'] : '';
		$fragment = isset($parts['fragment']) ? '#' . (string) $parts['fragment'] : '';

		return $scheme . $auth . $host . $port . $path . $query . $fragment;
	}

	private static function update_content_image_alt(WP_Post $post, string $alt_cell): void {
		$alts = preg_split('~[\n\r|]+~', trim($alt_cell)) ?: [];
		if (empty($alts)) {
			return;
		}

		$content = (string) $post->post_content;
		if ($content === '' || !preg_match_all('~<img\b[^>]*>~i', $content, $img_matches)) {
			return;
		}

		$index = 0;
		foreach ((array) $img_matches[0] as $img_tag) {
			$alt = array_key_exists($index, $alts) ? sanitize_text_field((string) $alts[$index]) : null;
			$index++;
			if ($alt === null) {
				continue;
			}

			$attachment_id = 0;
			if (preg_match('~\bwp-image-(\d+)\b~i', (string) $img_tag, $class_match)) {
				$attachment_id = (int) ($class_match[1] ?? 0);
			}
			if ($attachment_id <= 0 && preg_match('~\bsrc\s*=\s*["\']([^"\']+)["\']~i', (string) $img_tag, $src_match)) {
				$attachment_id = (int) attachment_url_to_postid((string) ($src_match[1] ?? ''));
			}
			if ($attachment_id > 0) {
				update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
			}
		}
	}

	private static function fatal_result(string $message): array {
		return [
			'ok' => false,
			'message' => $message,
			'summary' => [
				'total_rows' => 0,
				'would_import' => 0,
				'imported' => 0,
				'skipped_no_changes' => 0,
				'skipped_duplicate' => 0,
				'failed' => 0,
			],
			'rows' => [],
		];
	}

	private static function render_result(array $result): void {
		if (empty($result['ok'])) {
			echo '<div class="notice notice-error"><p>' . esc_html((string) ($result['message'] ?? 'An unknown error occurred.')) . '</p></div>';
			return;
		}

		$mode = (string) ($result['mode'] ?? 'dry_run');
		$overwrite_existing = !empty($result['overwrite_existing']);
		$summary = is_array($result['summary'] ?? null) ? $result['summary'] : [];
		$rows = is_array($result['rows'] ?? null) ? $result['rows'] : [];

		echo '<div class="vite-schema-csv-card vite-schema-csv-result-card">';
		echo '<h2 style="margin-top:0;">Result: ' . esc_html($mode === 'apply' ? 'Apply Import' : 'Dry Run') . '</h2>';
		if ($mode === 'dry_run') {
			echo '<p class="description">Dry Run is a safe preview. It checks every row and shows what would happen, but it does not update any post.</p>';
		} else {
			echo '<p class="description">Apply Import writes updates now. Rows marked as Imported were saved to matching posts.</p>';
		}
		echo '<p><strong>Overwrite existing values:</strong> ' . esc_html($overwrite_existing ? 'Yes' : 'No (fill empty fields only)') . '</p>';
		echo '<div class="vite-schema-csv-summary-grid">';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Total processed rows</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['total_rows'] ?? 0)) . '</span></div>';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Would import (dry run)</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['would_import'] ?? 0)) . '</span></div>';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Imported (apply)</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['imported'] ?? 0)) . '</span></div>';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Skipped (no changes)</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['skipped_no_changes'] ?? 0)) . '</span></div>';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Skipped (duplicate in CSV)</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['skipped_duplicate'] ?? 0)) . '</span></div>';
		echo '<div class="vite-schema-csv-summary-item"><span class="vite-schema-csv-summary-item__label">Failed</span><span class="vite-schema-csv-summary-item__value">' . esc_html((string) ($summary['failed'] ?? 0)) . '</span></div>';
		echo '</div>';
		echo '<p class="description" style="margin-top:8px;">Status guide: <strong>Would Import</strong> = ready, <strong>Imported</strong> = saved, <strong>Skipped</strong> = no action needed, <strong>Failed</strong> = fix this CSV row.</p>';
		echo '</div>';

		if (!$rows) {
			return;
		}

		echo '<h3 style="margin-top:20px;">Detailed Log</h3>';
		echo '<table class="widefat striped fixed vite-schema-csv-log-table">';
		echo '<thead><tr>';
		echo '<th style="width:70px;">Row</th>';
		echo '<th style="width:24%;">Lookup Value</th>';
		echo '<th style="width:12%;">Normalized Slug</th>';
		echo '<th style="width:20%;">Matched Post</th>';
		echo '<th style="width:12%;">Status</th>';
		echo '<th>Details</th>';
		echo '</tr></thead><tbody>';

		foreach ($rows as $entry) {
			$status = (string) ($entry['status'] ?? '');
			$pill_class = 'vite-schema-csv-status-pill vite-schema-csv-status-pill--neutral';
			if ($status === 'Imported' || $status === 'Would Import') {
				$pill_class = 'vite-schema-csv-status-pill vite-schema-csv-status-pill--success';
			} elseif ($status === 'Skipped') {
				$pill_class = 'vite-schema-csv-status-pill vite-schema-csv-status-pill--warn';
			} elseif ($status === 'Failed') {
				$pill_class = 'vite-schema-csv-status-pill vite-schema-csv-status-pill--error';
			}

			echo '<tr>';
			echo '<td>' . esc_html((string) ($entry['row'] ?? '')) . '</td>';
			echo '<td><code>' . esc_html((string) ($entry['url'] ?? '')) . '</code></td>';
			echo '<td><code>' . esc_html((string) ($entry['slug'] ?? '')) . '</code></td>';
			echo '<td>' . esc_html((string) ($entry['post'] ?? '')) . '</td>';
			echo '<td><span class="' . esc_attr($pill_class) . '">' . esc_html($status) . '</span></td>';
			echo '<td>' . esc_html((string) ($entry['message'] ?? '')) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	private static function render_docs_modal(): void {
		echo '<div id="vite-schema-csv-guide-modal" class="vite-schema-csv-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="vite-schema-csv-guide-title">';
		echo '<div class="vite-schema-csv-guide__panel">';
		echo '<div class="vite-schema-csv-guide__header">';
		echo '<strong id="vite-schema-csv-guide-title">Schema CSV Importer Guide</strong>';
		echo '<button type="button" class="button" id="vite-schema-csv-close-guide" aria-label="Close guide">Close</button>';
		echo '</div>';
		echo '<div class="vite-schema-csv-guide__body">';
		echo '<p>This tool updates SEO metadata for blog posts in bulk from a CSV file. It is designed for content teams and SEO specialists.</p>';
		echo '<h3>What this plugin can do</h3>';
		echo '<ul>';
		echo '<li>Match rows to blog posts using <code>CONTENT_ID</code>, <code>SLUG</code>, or <code>POST_LINK</code> + optional language. <code>POST_LINK_READABLE</code> is reference-only.</li>';
		echo '<li>Import Schema JSON-LD, SEO Title, Meta Description, Meta Robots, Featured Image Alt, and Content Images Alt.</li>';
		echo '<li>Export image audit columns (URL/size/type) for featured and content images without allowing accidental overwrite from CSV.</li>';
		echo '<li>Run a safe Dry Run preview before writing changes.</li>';
		echo '</ul>';
		echo '<h3>Step-by-step workflow</h3>';
		echo '<ol>';
		echo '<li>Prepare CSV with header row.</li>';
		echo '<li>(Optional) Use <strong>Download Current Posts CSV</strong> to export existing data first.</li>';
		echo '<li>Upload file and choose whether to overwrite existing editable values.</li>';
		echo '<li>Run <strong>Dry Run</strong> first and review the log.</li>';
		echo '<li>Fix any failed rows in CSV.</li>';
		echo '<li>Run <strong>Apply Import</strong> once Dry Run looks good.</li>';
		echo '</ol>';
		$sample_url = wp_nonce_url(
			add_query_arg(['action' => 'vite_schema_csv_download_sample'], admin_url('admin-post.php')),
			'vite_schema_csv_download_sample'
		);
		echo '<h3>CSV format</h3>';
		echo '<p><strong>Required:</strong> at least one identifier column: <code>CONTENT_ID</code>, <code>SLUG</code>, or <code>POST_LINK</code>.</p>';
		echo '<p><strong>Optional columns:</strong> <code>TITLE</code> (post title), <code>EXCERPT</code> (post excerpt), <code>LANG</code>, <code>SCHEMA</code>, <code>SEO_TITLE</code>, <code>META_DESCRIPTION</code>, <code>META_ROBOTS</code>, <code>CATEGORIES</code>, <code>TAGS</code>, <code>PAGE_TYPE</code>, <code>FEATURED_IMAGE_ALT</code>, <code>CONTENT_IMAGE_ALT</code>.</p>';
		echo '<p><strong>Read-only export columns (ignored by import):</strong> <code>POST_LINK_READABLE</code>, <code>FEATURED_IMAGE_URL</code>, <code>FEATURED_IMAGE_SIZE_KB</code>, <code>FEATURED_IMAGE_TYPE</code>, <code>CONTENT_IMAGE_URLS</code>, <code>CONTENT_IMAGE_SIZES_KB</code>, <code>CONTENT_IMAGE_TYPES</code>.</p>';
		echo '<p><strong>Editable image columns:</strong> only <code>FEATURED_IMAGE_ALT</code> and <code>CONTENT_IMAGE_ALT</code>. Use <code>|</code> to separate multiple content image alts in order.</p>';
		echo '<p><strong>Identifier priority per row:</strong> <code>CONTENT_ID</code> first, then <code>SLUG</code>, then <code>POST_LINK</code>. <code>POST_LINK_READABLE</code> does not participate in matching.</p>';
		echo '<p><strong>Important:</strong> <code>SLUG</code> is both lookup and target slug. To rename slug safely, use <code>CONTENT_ID</code> or <code>POST_LINK</code> as the identifier and set the new value in <code>SLUG</code>.</p>';
		echo '<p><strong>LANG behavior:</strong> If <code>LANG</code> is filled, importer enforces language match. If blank, <code>CONTENT_ID</code>/<code>POST_LINK</code> can match any language, while slug lookup uses default language fallback.</p>';
		echo '<p><strong>Empty cell behavior:</strong> empty optional values are ignored and will not erase existing post data.</p>';
		echo '<p><strong>PAGE_TYPE allowed values:</strong> <code>glossary</code>, <code>pillar</code>, <code>hub</code>, <code>section</code>.</p>';
		echo '<p><a class="button button-secondary" href="' . esc_url($sample_url) . '">Download CSV Sample</a></p>';
		echo '<pre>CONTENT_ID,POST_LINK,POST_LINK_READABLE,SLUG,TITLE,EXCERPT,LANG,SEO_TITLE,META_DESCRIPTION,META_ROBOTS,SCHEMA,CATEGORIES,TAGS,PAGE_TYPE,FEATURED_IMAGE_URL,FEATURED_IMAGE_SIZE_KB,FEATURED_IMAGE_TYPE,FEATURED_IMAGE_ALT,CONTENT_IMAGE_URLS,CONTENT_IMAGE_SIZES_KB,CONTENT_IMAGE_TYPES,CONTENT_IMAGE_ALT
123,https://example.com/sample-post/,https://example.com/sample-post/,updated-blog-title,Updated blog title,Updated short summary for this post.,en,My SEO Title,My meta description,"index,follow","{""@context"":""https://schema.org"",""@type"":""BlogPosting""}","SEO","Bangkok|Travel",pillar,https://example.com/wp-content/uploads/2026/03/sample-featured.webp,132.45,webp,Main featured alt,"https://example.com/wp-content/uploads/2026/03/c1.webp|https://example.com/wp-content/uploads/2026/03/c2.webp","88.10|104.33","webp|webp","First content image alt|Second content image alt"</pre>';
		echo '<h3>Status meanings</h3>';
		echo '<ul>';
		echo '<li><strong>Would Import:</strong> Row is valid and ready.</li>';
		echo '<li><strong>Imported:</strong> Row was applied to a post.</li>';
		echo '<li><strong>Skipped:</strong> No update needed or duplicate in CSV.</li>';
		echo '<li><strong>Failed:</strong> Row has an issue and needs correction.</li>';
		echo '</ul>';
		echo '<h3>Export in phases (server-safe)</h3>';
		echo '<p>Use the <strong>Download Current Posts CSV</strong> card to export by batches (up to 150 posts per file). You can also filter export by month or custom date range before downloading phases.</p>';
		echo '</div></div></div>';

		echo '<script>
		(function () {
			document.addEventListener("DOMContentLoaded", function () {
				var openBtn = document.getElementById("vite-schema-csv-open-guide");
				var closeBtn = document.getElementById("vite-schema-csv-close-guide");
				var modal = document.getElementById("vite-schema-csv-guide-modal");
				if (!openBtn || !closeBtn || !modal) return;
				function openGuide() { modal.hidden = false; modal.setAttribute("aria-hidden", "false"); }
				function closeGuide() { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); }
				openBtn.addEventListener("click", openGuide);
				closeBtn.addEventListener("click", closeGuide);
				modal.addEventListener("click", function (event) { if (event.target === modal) closeGuide(); });
				document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !modal.hidden) closeGuide(); });
			});
		})();
		</script>';
	}

	public static function handle_sample_download(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}
		check_admin_referer('vite_schema_csv_download_sample');

		$headers = ['CONTENT_ID', 'POST_LINK', 'POST_LINK_READABLE', 'SLUG', 'TITLE', 'EXCERPT', 'LANG', 'SEO_TITLE', 'META_DESCRIPTION', 'META_ROBOTS', 'SCHEMA', 'CATEGORIES', 'TAGS', 'PAGE_TYPE', 'FEATURED_IMAGE_URL', 'FEATURED_IMAGE_SIZE_KB', 'FEATURED_IMAGE_TYPE', 'FEATURED_IMAGE_ALT', 'CONTENT_IMAGE_URLS', 'CONTENT_IMAGE_SIZES_KB', 'CONTENT_IMAGE_TYPES', 'CONTENT_IMAGE_ALT'];
		$row = [
			'123',
			'https://example.com/sample-post/',
			'https://example.com/sample-post/',
			'updated-blog-title',
			'Updated blog title',
			'Updated short summary for this post.',
			'en',
			'My SEO Title',
			'My meta description',
			'index,follow',
			'{"@context":"https://schema.org","@type":"BlogPosting"}',
			'SEO',
			'Bangkok|Travel',
			'pillar',
			'https://example.com/wp-content/uploads/2026/03/sample-featured.webp',
			'132.45',
			'webp',
			'Main featured alt',
			'https://example.com/wp-content/uploads/2026/03/c1.webp|https://example.com/wp-content/uploads/2026/03/c2.webp',
			'88.10|104.33',
			'webp|webp',
			'First content image alt|Second content image alt',
		];

		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="vite-schema-csv-sample.csv"');
		$out = fopen('php://output', 'w');
		if ($out === false) {
			wp_die('Could not generate CSV sample.');
		}
		fputcsv($out, $headers);
		fputcsv($out, $row);
		fclose($out);
		exit;
	}

	public static function handle_posts_download(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}
		check_admin_referer('vite_schema_csv_download_posts');

		$phase = isset($_GET['phase']) ? max(1, (int) $_GET['phase']) : 1;
		$per_page = isset($_GET['per_page']) ? (int) $_GET['per_page'] : self::EXPORT_BATCH_DEFAULT;
		$per_page = in_array($per_page, [50, 100, 150], true) ? $per_page : self::EXPORT_BATCH_DEFAULT;
		$offset = ($phase - 1) * $per_page;
		$filters = self::get_export_filters_from_request();

		$post_statuses = array_values(array_diff(get_post_stati(['internal' => false]), ['trash', 'auto-draft', 'inherit']));
		if (!$post_statuses) {
			$post_statuses = ['publish', 'draft', 'pending', 'future', 'private'];
		}
		$args = [
			'post_type' => 'post',
			'post_status' => $post_statuses,
			'numberposts' => $per_page,
			'offset' => $offset,
			'orderby' => 'ID',
			'order' => 'ASC',
			'suppress_filters' => false,
		];
		$date_query = self::build_export_date_query($filters['month'], $filters['date_from'], $filters['date_to']);
		if ($date_query) {
			$args['date_query'] = $date_query;
		}
		$posts = get_posts($args);

		$headers = ['CONTENT_ID', 'POST_LINK', 'POST_LINK_READABLE', 'SLUG', 'TITLE', 'EXCERPT', 'LANG', 'SEO_TITLE', 'META_DESCRIPTION', 'META_ROBOTS', 'SCHEMA', 'CATEGORIES', 'TAGS', 'PAGE_TYPE', 'FEATURED_IMAGE_URL', 'FEATURED_IMAGE_SIZE_KB', 'FEATURED_IMAGE_TYPE', 'FEATURED_IMAGE_ALT', 'CONTENT_IMAGE_URLS', 'CONTENT_IMAGE_SIZES_KB', 'CONTENT_IMAGE_TYPES', 'CONTENT_IMAGE_ALT'];
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		$name_parts = ['vite-schema-posts', 'phase-' . $phase, 'size-' . $per_page];
		if ($filters['month'] !== '') {
			$name_parts[] = 'month-' . str_replace('-', '', $filters['month']);
		} elseif ($filters['date_from'] !== '' || $filters['date_to'] !== '') {
			$name_parts[] = 'range';
		}
		header('Content-Disposition: attachment; filename="' . implode('-', $name_parts) . '.csv"');
		$out = fopen('php://output', 'w');
		if ($out === false) {
			wp_die('Could not generate posts CSV.');
		}
		fputcsv($out, $headers);

		foreach ($posts as $post) {
			if (!$post instanceof WP_Post) {
				continue;
			}
			$post_id = (int) $post->ID;
			$categories = wp_get_post_terms($post_id, 'category', ['fields' => 'names']);
			$tags = wp_get_post_terms($post_id, 'post_tag', ['fields' => 'names']);
			$lang = function_exists('pll_get_post_language') ? (string) pll_get_post_language($post_id, 'slug') : '';
			$featured = self::featured_image_info_for_post($post_id);
			$content_images = self::content_image_data_from_post($post);

			$post_link = (string) get_permalink($post_id);
			$row = [
				(string) $post_id,
				$post_link,
				self::make_readable_post_link($post_link),
				(string) $post->post_name,
				(string) $post->post_title,
				(string) $post->post_excerpt,
				(string) $lang,
				(string) get_post_meta($post_id, self::META_SEO_TITLE, true),
				(string) get_post_meta($post_id, self::META_META_DESCRIPTION, true),
				(string) get_post_meta($post_id, self::META_META_ROBOTS, true),
				(string) get_post_meta($post_id, self::META_SCHEMA, true),
				implode('|', is_array($categories) ? array_values(array_filter(array_map('strval', $categories))) : []),
				implode('|', is_array($tags) ? array_values(array_filter(array_map('strval', $tags))) : []),
				(string) get_post_meta($post_id, self::META_PAGE_TYPE, true),
				(string) ($featured['url'] ?? ''),
				(string) ($featured['size_kb'] ?? ''),
				(string) ($featured['type'] ?? ''),
				(string) ($featured['alt'] ?? ''),
				implode('|', (array) ($content_images['urls'] ?? [])),
				implode('|', (array) ($content_images['sizes_kb'] ?? [])),
				implode('|', (array) ($content_images['types'] ?? [])),
				implode('|', (array) ($content_images['alts'] ?? [])),
			];
			fputcsv($out, $row);
		}

		fclose($out);
		exit;
	}

	private static function render_admin_styles(): void {
		echo '<style>
		.vite-schema-csv-page { max-width: none; width: 95%; }
		.vite-schema-csv-page__header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom: 12px; flex-wrap: wrap; }
		.vite-schema-csv-card { background:#fff; border:1px solid #dcdcde; border-radius:10px; box-shadow:0 1px 2px rgba(16,24,40,.04); padding:16px 18px; margin:0 0 14px; }
		.vite-schema-csv-card p { margin:8px 0; line-height:1.55; }
		.vite-schema-csv-guide-btn { background:#ffcc00 !important; border-color:#d6a800 !important; color:#1d2327 !important; }
		.vite-schema-csv-guide-btn:hover,
		.vite-schema-csv-guide-btn:focus { background:#f0bf00 !important; border-color:#bf9600 !important; color:#1d2327 !important; }
		.vite-schema-csv-file-input { width:100%; max-width:560px; background:#fff; border:1px solid #8c8f94; border-radius:7px; padding:8px; }
		.vite-schema-csv-actions { display:flex; gap:10px; align-items:center; margin: 14px 0 8px; flex-wrap: wrap; }
		.vite-schema-csv-export-size { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin:8px 0 12px; }
		.vite-schema-csv-export-phases { display:flex; gap:8px; flex-wrap:wrap; }
		.vite-schema-csv-summary-grid { display:grid; grid-template-columns: repeat(6, minmax(0,1fr)); gap:10px; margin:12px 0 4px; }
		.vite-schema-csv-summary-item { border:1px solid #dcdcde; border-radius:8px; padding:10px; background:#fff; }
		.vite-schema-csv-summary-item__label { display:block; color:#50575e; font-size:12px; margin-bottom:4px; }
		.vite-schema-csv-summary-item__value { display:block; font-size:20px; line-height:1.2; font-weight:600; color:#1d2327; }
		.vite-schema-csv-log-table th { font-weight:600; }
		.vite-schema-csv-status-pill { display:inline-block; border-radius:999px; padding:2px 10px; font-size:12px; font-weight:600; line-height:1.7; }
		.vite-schema-csv-status-pill--success { background:#edfaef; color:#0f6f2e; }
		.vite-schema-csv-status-pill--warn { background:#fff7e6; color:#8a5a00; }
		.vite-schema-csv-status-pill--error { background:#fdecec; color:#9f2626; }
		.vite-schema-csv-status-pill--neutral { background:#f0f0f1; color:#3c434a; }
		#vite-schema-csv-guide-modal[hidden] { display:none !important; }
		.vite-schema-csv-guide-modal { position:fixed; inset:0; z-index:100000; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; padding:20px; }
		.vite-schema-csv-guide__panel { width:min(980px, calc(100vw - 24px)); max-height:86vh; overflow:auto; background:#fff; border-radius:10px; box-shadow:0 16px 38px rgba(0,0,0,.18); }
		.vite-schema-csv-guide__header { position:sticky; top:0; background:#fff; border-bottom:1px solid #dcdcde; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; gap:12px; }
		.vite-schema-csv-guide__body { padding:16px; }
		.vite-schema-csv-guide__body h3 { margin:18px 0 8px; }
		.vite-schema-csv-guide__body p { margin:8px 0; line-height:1.5; }
		.vite-schema-csv-guide__body ul, .vite-schema-csv-guide__body ol { margin:8px 0 10px 18px; }
		.vite-schema-csv-guide__body pre { background:#f6f7f7; border:1px solid #dcdcde; border-radius:6px; padding:10px; white-space:pre-wrap; word-break:break-word; }
		@media (max-width: 1200px) {
			.vite-schema-csv-summary-grid { grid-template-columns: repeat(3, minmax(0,1fr)); }
		}
		@media (max-width: 782px) {
			.vite-schema-csv-summary-grid { grid-template-columns: repeat(2, minmax(0,1fr)); }
			.vite-schema-csv-guide-modal { padding:10px; }
			.vite-schema-csv-guide__header { padding:10px 12px; }
			.vite-schema-csv-guide__body { padding:12px; }
		}
		</style>';
	}
}

Vite_Schema_CSV_Importer::init();

