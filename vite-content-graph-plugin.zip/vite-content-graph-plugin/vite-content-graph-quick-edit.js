(function ($) {
  if (typeof inlineEditPost === "undefined") return;

  const original = inlineEditPost.edit;

  inlineEditPost.edit = function (id) {
    original.apply(this, arguments);

    let postId = 0;
    if (typeof id === "object") postId = parseInt(this.getId(id), 10);
    if (!postId) return;

    const $row = $("#post-" + postId);
    const val =
      $row.find(".column-vite_page_type .vite-page-type").data("vite-page-type") || "";

    $("#edit-" + postId).find("select.vite-quick-page-type").val(val);
  };
})(jQuery);


