<?php
/**
 * Plugin Name: Vite Content Graph (Page Type + Internal Links)
 * Description: Adds Page Type taxonomy-like meta for posts and shows internal outbound/inbound link counts (from content + schema JSON) in admin list tables.
 * Author: Vite SEO
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('vite_render_seo_tools_landing')) {
	function vite_render_seo_tools_landing(): void {
		echo '<div class="wrap"><h1>SEO Tools</h1><p>Use the submenu items to open each SEO tool.</p></div>';
	}
}

if (!function_exists('vite_register_seo_tools_menu')) {
	function vite_register_seo_tools_menu(): void {
		static $added = false;
		if ($added) {
			return;
		}

		add_menu_page(
			'SEO Tools',
			'SEO Tools',
			'edit_posts',
			'vite-seo-tools',
			'vite_render_seo_tools_landing',
			'dashicons-chart-area',
			58
		);

		$added = true;
	}
}

final class Vite_Content_Graph {
	// Page Type meta (posts only)
	const META_PAGE_TYPE = 'vite_page_type';

	// Reuse schema JSON-LD meta (stored by vite-seo-guard)
	const META_SCHEMA = 'vite_schema_jsonld';

	// Link graph meta (internal links only)
	const META_OUT_TARGET_IDS = 'vite_outbound_internal_target_ids'; // array<int>
	const META_OUT_COUNT      = 'vite_outbound_internal_count';      // int
	const META_IN_SOURCE_IDS  = 'vite_inbound_internal_source_ids';  // array<int>
	const META_IN_COUNT       = 'vite_inbound_internal_count';       // int
	const REBUILD_PAGE_SLUG   = 'vite-link-graph-rebuild';
	const REBUILD_BATCH_SIZE  = 25;
	const OPTION_ALLOWED_HOSTS = 'vite_content_graph_allowed_hosts'; // comma-separated hosts treated as internal

	public static function init() {
		add_action('init', [__CLASS__, 'register_meta']);
		add_action('enqueue_block_editor_assets', [__CLASS__, 'enqueue_editor']);

		// Link graph indexing (posts + pages)
		add_action('save_post', [__CLASS__, 'index_internal_links_on_save'], 20, 3);
		add_action('before_delete_post', [__CLASS__, 'remove_internal_links_on_delete'], 10, 1);

		// Admin columns (Posts + Pages list)
		add_filter('manage_post_posts_columns', [__CLASS__, 'add_admin_columns']);
		add_action('manage_post_posts_custom_column', [__CLASS__, 'render_admin_column'], 10, 2);
		add_filter('manage_edit-post_sortable_columns', [__CLASS__, 'add_sortable_columns']);

		add_filter('manage_page_posts_columns', [__CLASS__, 'add_admin_columns']);
		add_action('manage_page_posts_custom_column', [__CLASS__, 'render_admin_column'], 10, 2);
		add_filter('manage_edit-page_sortable_columns', [__CLASS__, 'add_sortable_columns']);

		add_action('pre_get_posts', [__CLASS__, 'handle_admin_sorting']);
		add_action('admin_head-edit.php', [__CLASS__, 'output_admin_styles']);

		// Quick Edit for Page Type (posts screen)
		add_action('quick_edit_custom_box', [__CLASS__, 'render_quick_edit'], 10, 2);
		add_action('bulk_edit_custom_box', [__CLASS__, 'render_bulk_edit'], 10, 2);
		add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_quick_edit_js']);
		add_action('save_post_post', [__CLASS__, 'save_quick_edit_page_type'], 20, 2);

		// Optional report screen
		add_action('admin_menu', [__CLASS__, 'register_link_report_page']);
		add_action('admin_menu', [__CLASS__, 'register_rebuild_page']);
		add_action('admin_init', [__CLASS__, 'handle_rebuild_requests']);
	}

	public static function sanitize_page_type($value): string {
		$value = sanitize_key((string) $value);
		$allowed = ['pillar', 'hub', 'section', 'glossary', ''];
		return in_array($value, $allowed, true) ? $value : '';
	}

	public static function register_meta() {
		$auth = function() { return current_user_can('edit_posts'); };

		register_post_meta('post', self::META_PAGE_TYPE, [
			'type' => 'string',
			'single' => true,
			'show_in_rest' => true,
			'sanitize_callback' => [__CLASS__, 'sanitize_page_type'],
			'auth_callback' => $auth,
		]);
	}

	public static function enqueue_editor() {
		if (!function_exists('get_current_screen')) return;
		$screen = get_current_screen();
		if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'post') return;

		$src = plugin_dir_url(__FILE__) . 'vite-content-graph-editor.js';
		wp_enqueue_script(
			'vite-content-graph-editor',
			$src,
			['wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-i18n'],
			'1.0.0',
			true
		);
	}

	/**
	 * -----------------------------
	 * Link graph (internal-only)
	 * -----------------------------
	 */

	private static function internal_host(): string {
		$host = wp_parse_url(home_url('/'), PHP_URL_HOST);
		return is_string($host) ? strtolower($host) : '';
	}

	private static function allowed_hosts(): array {
		$hosts = [];
		$primary = self::internal_host();
		if ($primary !== '') $hosts[] = $primary;

		$raw = get_option(self::OPTION_ALLOWED_HOSTS, '');
		if (is_string($raw) && trim($raw) !== '') {
			$parts = preg_split('~[,\s]+~', strtolower($raw)) ?: [];
			foreach ($parts as $h) {
				$h = trim((string) $h);
				if ($h === '') continue;
				$hosts[] = $h;
			}
		}

		$hosts = array_values(array_unique($hosts));
		return $hosts;
	}

	private static function host_is_allowed(string $host): bool {
		$host = strtolower(trim($host));
		if ($host === '') return false;
		return in_array($host, self::allowed_hosts(), true);
	}

	private static function normalize_internal_url(string $url) {
		$url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
		if ($url === '' || (isset($url[0]) && $url[0] === '#')) return null;

		$lower = strtolower($url);
		if (strpos($lower, 'mailto:') === 0 || strpos($lower, 'tel:') === 0 || strpos($lower, 'javascript:') === 0) {
			return null;
		}

		// Relative internal
		if (isset($url[0]) && $url[0] === '/') {
			$url = home_url($url);
		} elseif (strpos($url, '//') === 0) {
			$url = set_url_scheme($url);
		} elseif (!preg_match('~^https?://~i', $url)) {
			return null;
		}

		$parts = wp_parse_url($url);
		if (!$parts || empty($parts['host'])) return null;
		if (!self::host_is_allowed((string) $parts['host'])) return null;

		$path = $parts['path'] ?? '/';
		if (!is_string($path) || $path === '') $path = '/';

		// Strip query/fragment for ID resolution
		return home_url($path);
	}

	private static function extract_internal_urls_from_html(string $html): array {
		if ($html === '') return [];
		$urls = [];

		// href="..." | href='...' | href=...
		if (preg_match_all('~href\s*=\s*(?:"([^"]+)"|\'([^\']+)\'|([^\s>]+))~i', $html, $m)) {
			foreach ($m[1] as $i => $_) {
				$candidate = $m[1][$i] ?: ($m[2][$i] ?: ($m[3][$i] ?? ''));
				if (!is_string($candidate) || $candidate === '') continue;
				$norm = self::normalize_internal_url($candidate);
				if ($norm) $urls[] = $norm;
			}
		}

		return array_values(array_unique($urls));
	}

	/**
	 * -----------------------------
	 * Schema JSON-LD (smart extraction)
	 * -----------------------------
	 */

	private static function schema_jsonld_raw_for_post(\WP_Post $post): string {
		$raw = (string) get_post_meta((int) $post->ID, self::META_SCHEMA, true);
		$raw = trim($raw);

		/**
		 * Allow themes to provide runtime schema JSON-LD (e.g. template-driven pages).
		 *
		 * @param string  $raw  Schema JSON string from meta (may be empty).
		 * @param WP_Post $post Source post object.
		 */
		$raw = (string) apply_filters('vite_content_graph_schema_jsonld_raw', $raw, $post);
		return trim($raw);
	}

	private static function schema_should_ignore_key(string $key): bool {
		$key = strtolower($key);

		// Noise / identifiers / media keys that are not "content relationships".
		$deny = [
			'@context', '@graph',
			'@id', 'identifier',
			'publisher', 'logo', 'image', 'thumbnailurl', 'contenturl', 'embedurl',
			'primaryimageofpage', 'thumbnail',
			'potentialaction', 'target', 'query-input', 'queryinput', 'searchaction',
			'brand',
			'datepublished', 'datemodified', 'inlanguage',
		];

		return in_array($key, $deny, true);
	}

	private static function schema_key_is_allowed_url_container(string $key): bool {
		$key = strtolower($key);
		$allow = [
			'url',
			'mainentityofpage',
			'mentions',
			'about',
			'haspart',
			'ispartof',
			'relatedlink',
			'significantlink',
			'citation',
			'sameas',
		];
		return in_array($key, $allow, true);
	}

	private static function schema_string_to_internal_url_candidate(string $s, \WP_Post $post) {
		$s = trim($s);
		if ($s === '') return null;

		// Ignore SearchAction templates or placeholders.
		if (strpos($s, '{') !== false) return null;
		if (stripos($s, 'search_term_string') !== false) return null;

		// IMPORTANT: ignore fragment identifiers entirely for link graph purposes (avoids #website/#organization noise).
		if (strpos($s, '#') !== false) return null;

		$norm = self::normalize_internal_url($s);
		if (!$norm) return null;

		// By default, do NOT allow schema to create edges to the site root (prevents "everyone links to home" inflation).
		$home = home_url('/');
		$allow_home = (bool) apply_filters('vite_content_graph_schema_allow_home_url', false, $post, $norm);
		if (!$allow_home && untrailingslashit($norm) === untrailingslashit($home)) {
			return null;
		}

		return $norm;
	}

	private static function extract_internal_urls_from_schema_node($node, \WP_Post $post, string $parent_key = ''): array {
		$urls = [];

		if (is_string($node)) {
			if ($parent_key !== '' && self::schema_key_is_allowed_url_container($parent_key)) {
				$u = self::schema_string_to_internal_url_candidate($node, $post);
				if ($u) $urls[] = $u;
			}
			return $urls;
		}

		if (!is_array($node)) return $urls;

		// If this is a list, recurse into values.
		$is_list = array_keys($node) === range(0, count($node) - 1);
		if ($is_list) {
			foreach ($node as $v) {
				$urls = array_merge($urls, self::extract_internal_urls_from_schema_node($v, $post, $parent_key));
			}
			return $urls;
		}

		// Assoc object: only recurse into allow-listed relationship keys, and skip noisy keys.
		foreach ($node as $k => $v) {
			$k = (string) $k;
			$k_l = strtolower($k);

			if (self::schema_should_ignore_key($k_l)) {
				continue;
			}

			// Only follow relationship containers; this prevents random strings from being treated as links.
			if ($k_l === 'url') {
				if (is_string($v)) {
					$u = self::schema_string_to_internal_url_candidate($v, $post);
					if ($u) $urls[] = $u;
				} else {
					$urls = array_merge($urls, self::extract_internal_urls_from_schema_node($v, $post, 'url'));
				}
				continue;
			}

			if (self::schema_key_is_allowed_url_container($k_l)) {
				$urls = array_merge($urls, self::extract_internal_urls_from_schema_node($v, $post, $k_l));
			}
		}

		return $urls;
	}

	private static function extract_internal_urls_from_schema_jsonld(string $raw, \WP_Post $post): array {
		$raw = trim($raw);
		if ($raw === '') return [];

		$decoded = json_decode($raw, true);
		if (!is_array($decoded)) return [];

		$urls = self::extract_internal_urls_from_schema_node($decoded, $post, '');
		$urls = array_values(array_unique(array_filter($urls)));
		return $urls;
	}

	private static function extract_internal_urls_from_block_attrs($data, string $parent_key = ''): array {
		$urls = [];

		// Keys that commonly represent navigational links in blocks (including your custom blocks).
		$allow_keys = [
			'url', 'href', 'link',
			'buttonlink', 'button_link', 'buttonurl', 'button_url',
			'ctalink', 'cta_link', 'ctaurl', 'cta_url',
		];

		// Keys that are usually media assets (not navigational relationships).
		$deny_keys = [
			'image', 'imageurl', 'image_url', 'img', 'src',
			'icon', 'iconurl', 'icon_url',
			'logo', 'logourl', 'logo_url',
			'background', 'backgroundurl', 'background_url',
			'video', 'videourl', 'video_url', 'poster', 'posterurl', 'poster_url',
		];

		if (is_string($data)) {
			$key = strtolower($parent_key);
			if ($key !== '' && in_array($key, $allow_keys, true) && !in_array($key, $deny_keys, true)) {
				$norm = self::normalize_internal_url($data);
				if ($norm) $urls[] = $norm;
			}
			return $urls;
		}

		if (is_array($data)) {
			foreach ($data as $k => $v) {
				$k_str = is_string($k) ? $k : '';
				$key = strtolower($k_str);

				// If key is explicitly denied, don't descend into it (avoid counting internal media URLs).
				if ($key !== '' && in_array($key, $deny_keys, true)) {
					continue;
				}

				// Recurse; if this key is allow-listed and value is string, it will be counted.
				$urls = array_merge($urls, self::extract_internal_urls_from_block_attrs($v, $k_str));
			}
			return $urls;
		}

		return $urls;
	}

	private static function extract_internal_urls_from_blocks(array $blocks): array {
		$urls = [];
		foreach ($blocks as $b) {
			if (!is_array($b)) continue;

			if (isset($b['attrs']) && is_array($b['attrs'])) {
				$urls = array_merge($urls, self::extract_internal_urls_from_block_attrs($b['attrs']));
			}

			if (isset($b['innerBlocks']) && is_array($b['innerBlocks']) && $b['innerBlocks']) {
				$urls = array_merge($urls, self::extract_internal_urls_from_blocks($b['innerBlocks']));
			}
		}
		return $urls;
	}

	private static function extract_internal_urls_from_block_markup(string $markup): array {
		$markup = (string) $markup;
		if (trim($markup) === '') return [];
		if (!function_exists('parse_blocks')) return [];

		$blocks = parse_blocks($markup);
		if (!is_array($blocks) || !$blocks) return [];

		$urls = self::extract_internal_urls_from_blocks($blocks);
		$urls = array_values(array_unique(array_filter($urls)));
		return $urls;
	}

	private static function internal_url_to_post_id(string $u): int {
		$id = (int) url_to_postid($u);
		if (!$id) $id = (int) url_to_postid(trailingslashit($u));
		if ($id) return $id;

		$path = wp_parse_url($u, PHP_URL_PATH);
		if (!is_string($path)) return 0;
		$path = trim($path, '/');

		// Homepage
		if ($path === '') {
			return (int) get_option('page_on_front');
		}

		// Pages (and optionally posts by path). This helps in environments where url_to_postid is flaky.
		$p = get_page_by_path($path, OBJECT, ['page', 'post']);
		return $p ? (int) $p->ID : 0;
	}

	private static function collect_internal_urls_for_source(\WP_Post $post): array {
		$urls = [];

		// 1) Rendered HTML anchors
		$urls = array_merge($urls, self::extract_internal_urls_from_html(self::render_content_for_link_extraction($post)));

		// 2) Block markup attribute scanning (editor content)
		$content_raw = (string) $post->post_content;
		$urls = array_merge($urls, self::extract_internal_urls_from_block_markup($content_raw));

		// 3) Template-driven pages: scan the assigned block template markup when editor content is empty
		if ($post->post_type === 'page' && trim($content_raw) === '') {
			$template_raw = self::page_template_raw_markup($post);
			if (trim($template_raw) !== '') {
				$urls = array_merge($urls, self::extract_internal_urls_from_block_markup($template_raw));
				$urls = array_merge($urls, self::extract_internal_urls_from_html(self::render_template_block_markup_for_link_extraction($template_raw)));
			}
		}

		// 4) Schema JSON-LD (smart)
		$raw_schema = self::schema_jsonld_raw_for_post($post);
		if ($raw_schema !== '') {
			$urls = array_merge($urls, self::extract_internal_urls_from_schema_jsonld($raw_schema, $post));
		}

		$urls = array_values(array_unique(array_filter($urls)));
		return $urls;
	}

	private static function render_content_for_link_extraction(\WP_Post $post): string {
		$content = (string) $post->post_content;

		$old_global = $GLOBALS['post'] ?? null;
		$GLOBALS['post'] = $post;

		$html = $content;
		if (function_exists('do_blocks')) {
			$html = do_blocks($html);
		}
		if (function_exists('do_shortcode')) {
			$html = do_shortcode($html);
		}

		if ($old_global instanceof \WP_Post) {
			$GLOBALS['post'] = $old_global;
		} else {
			unset($GLOBALS['post']);
		}

		$html = is_string($html) ? $html : $content;

		// If content is empty (common for template-driven Pages), try extracting from the assigned block template.
		if (trim($html) === '' && $post->post_type === 'page') {
			$template_html = self::render_page_template_for_link_extraction($post);
			if (trim($template_html) !== '') return $template_html;
		}

		return $html;
	}

	private static function page_template_raw_markup(\WP_Post $post): string {
		$theme_child = function_exists('get_stylesheet') ? (string) get_stylesheet() : '';
		$theme_parent = function_exists('get_template') ? (string) get_template() : '';

		$candidates = [];

		$front_id = (int) get_option('page_on_front');
		$blog_id  = (int) get_option('page_for_posts');

		if ($front_id && (int) $post->ID === $front_id) $candidates[] = 'front-page';
		if ($blog_id && (int) $post->ID === $blog_id) $candidates[] = 'home';

		// If the page has a specific template assigned, try that first.
		$assigned = function_exists('get_page_template_slug') ? (string) get_page_template_slug($post) : '';
		$assigned = trim($assigned);
		if ($assigned !== '') {
			$base = basename($assigned);
			$base = preg_replace('~\.html$~i', '', $base);
			$base = preg_replace('~\.php$~i', '', $base);
			if ($base !== '') $candidates[] = $base;
		}

		// Block template hierarchy common cases.
		if (!empty($post->post_name)) $candidates[] = 'page-' . $post->post_name;
		$candidates[] = 'page-' . (int) $post->ID;
		$candidates[] = 'page';
		$candidates[] = 'index';
		$candidates = array_values(array_unique($candidates));

		// Prefer block template APIs if available (covers DB-customized templates too).
		if (function_exists('get_block_template')) {
			foreach ($candidates as $slug) {
				foreach ([$theme_child, $theme_parent] as $theme) {
					if ($theme === '') continue;
					$tmpl = get_block_template($theme . '//' . $slug, 'wp_template');
					if ($tmpl && !empty($tmpl->content) && is_string($tmpl->content)) {
						return $tmpl->content;
					}
				}
			}
		}

		// Fallback: read template HTML from child theme filesystem.
		$theme_dir = function_exists('get_stylesheet_directory') ? (string) get_stylesheet_directory() : '';
		if ($theme_dir === '') return '';

		foreach ($candidates as $slug) {
			$path = rtrim($theme_dir, '/\\') . '/templates/' . $slug . '.html';
			if (!file_exists($path) || !is_readable($path)) continue;
			$raw = file_get_contents($path);
			if (!is_string($raw) || trim($raw) === '') continue;
			return $raw;
		}

		return '';
	}

	private static function render_page_template_for_link_extraction(\WP_Post $post): string {
		$raw = self::page_template_raw_markup($post);
		if (trim($raw) === '') return '';
		return self::render_template_block_markup_for_link_extraction($raw);
	}

	private static function render_template_block_markup_for_link_extraction(string $raw): string {
		$raw = (string) $raw;
		if (trim($raw) === '') return '';

		// Parse template blocks, remove header/footer/navigation blocks, then render.
		if (!function_exists('parse_blocks') || !function_exists('serialize_blocks') || !function_exists('do_blocks')) {
			return $raw;
		}

		$blocks = parse_blocks($raw);
		if (!is_array($blocks)) return $raw;

		$filtered = self::filter_template_blocks_for_link_extraction($blocks);
		$serialized = serialize_blocks($filtered);
		$rendered = do_blocks($serialized);

		return is_string($rendered) ? $rendered : $raw;
	}

	private static function filter_template_blocks_for_link_extraction(array $blocks): array {
		$out = [];
		foreach ($blocks as $b) {
			if (!is_array($b)) continue;
			$name = isset($b['blockName']) ? (string) $b['blockName'] : '';

			// Exclude navigation blocks (menu links would pollute the graph).
			$include_nav = (bool) apply_filters('vite_content_graph_include_navigation_links', false);
			if ($name === 'core/navigation' && !$include_nav) continue;

			// Exclude header/footer template parts, but keep "section" template parts that are part of the page body.
			if ($name === 'core/template-part') {
				$slug = '';
				if (isset($b['attrs']) && is_array($b['attrs']) && isset($b['attrs']['slug'])) {
					$slug = strtolower((string) $b['attrs']['slug']);
				}
				if ($slug !== '' && (strpos($slug, 'header') !== false || strpos($slug, 'footer') !== false || $slug === 'navigation' || $slug === 'nav')) {
					continue;
				}
			}

			if (isset($b['innerBlocks']) && is_array($b['innerBlocks']) && $b['innerBlocks']) {
				$b['innerBlocks'] = self::filter_template_blocks_for_link_extraction($b['innerBlocks']);
			}

			$out[] = $b;
		}
		return $out;
	}

	private static function resolve_internal_targets_for_source(int $source_id): array {
		$post = get_post($source_id);
		if (!$post) return [];
		if (!in_array($post->post_type, ['post', 'page'], true)) return [];

		// Only count links from published sources
		if ($post->post_status !== 'publish') return [];

		$urls = self::collect_internal_urls_for_source($post);
		$target_ids = [];

		foreach ($urls as $u) {
			$id = self::internal_url_to_post_id($u);
			if (!$id || $id === $source_id) continue;

			$target = get_post($id);
			if (!$target) continue;
			if (!in_array($target->post_type, ['post', 'page'], true)) continue;
			if ($target->post_status !== 'publish') continue;

			$target_ids[] = $id;
		}

		$target_ids = array_values(array_unique(array_map('intval', $target_ids)));
		sort($target_ids);
		return $target_ids;
	}

	private static function get_meta_int_array(int $post_id, string $key): array {
		$val = get_post_meta($post_id, $key, true);
		if (!is_array($val)) return [];
		$out = [];
		foreach ($val as $v) {
			$i = (int) $v;
			if ($i > 0) $out[] = $i;
		}
		$out = array_values(array_unique($out));
		sort($out);
		return $out;
	}

	private static function add_inbound_source(int $target_id, int $source_id) {
		$sources = self::get_meta_int_array($target_id, self::META_IN_SOURCE_IDS);
		if (in_array($source_id, $sources, true)) return;
		$sources[] = $source_id;
		$sources = array_values(array_unique($sources));
		sort($sources);
		update_post_meta($target_id, self::META_IN_SOURCE_IDS, $sources);
		update_post_meta($target_id, self::META_IN_COUNT, count($sources));
	}

	private static function remove_inbound_source(int $target_id, int $source_id) {
		$sources = self::get_meta_int_array($target_id, self::META_IN_SOURCE_IDS);
		if (!$sources) {
			update_post_meta($target_id, self::META_IN_COUNT, 0);
			return;
		}
		$new = array_values(array_diff($sources, [$source_id]));
		sort($new);
		update_post_meta($target_id, self::META_IN_SOURCE_IDS, $new);
		update_post_meta($target_id, self::META_IN_COUNT, count($new));
	}

	public static function index_internal_links_on_save(int $post_id, \WP_Post $post, bool $update) {
		if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
		if (!in_array($post->post_type, ['post', 'page'], true)) return;

		$new_targets = self::resolve_internal_targets_for_source($post_id);
		$old_targets = self::get_meta_int_array($post_id, self::META_OUT_TARGET_IDS);

		if ($new_targets === $old_targets) {
			update_post_meta($post_id, self::META_OUT_COUNT, count($new_targets));
			return;
		}

		$removed = array_values(array_diff($old_targets, $new_targets));
		$added   = array_values(array_diff($new_targets, $old_targets));

		foreach ($removed as $tid) self::remove_inbound_source((int) $tid, $post_id);
		foreach ($added as $tid) self::add_inbound_source((int) $tid, $post_id);

		update_post_meta($post_id, self::META_OUT_TARGET_IDS, $new_targets);
		update_post_meta($post_id, self::META_OUT_COUNT, count($new_targets));
	}

	public static function remove_internal_links_on_delete(int $post_id) {
		$post = get_post($post_id);
		if (!$post) return;
		if (!in_array($post->post_type, ['post', 'page'], true)) return;

		$old_targets = self::get_meta_int_array($post_id, self::META_OUT_TARGET_IDS);
		foreach ($old_targets as $tid) self::remove_inbound_source((int) $tid, (int) $post_id);
		delete_post_meta($post_id, self::META_OUT_TARGET_IDS);
		delete_post_meta($post_id, self::META_OUT_COUNT);
	}

	/**
	 * -----------------------------
	 * Admin columns + sorting
	 * -----------------------------
	 */

	private static function svg_icon(string $name): string {
		// Simple, dependency-free icons using inline SVG.
		$common = 'width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"';

		if ($name === 'out') {
			// link + arrow out
			return '<svg ' . $common . '><path d="M10.5 13.5l3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M7.5 16.5a4.5 4.5 0 010-9h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13.5 7.5h3a4.5 4.5 0 010 9h-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M14 4h6v6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 4l-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
		}

		if ($name === 'in') {
			// link + arrow in
			return '<svg ' . $common . '><path d="M10.5 13.5l3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M7.5 16.5a4.5 4.5 0 010-9h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13.5 7.5h3a4.5 4.5 0 010 9h-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M10 20H4v-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 20l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
		}

		return '<svg ' . $common . '><path d="M10.5 13.5l3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M7.5 16.5a4.5 4.5 0 010-9h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13.5 7.5h3a4.5 4.5 0 010 9h-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
	}

	public static function add_admin_columns(array $columns): array {
		$new = [];
		foreach ($columns as $key => $label) {
			if ($key === 'comments') {
				$new['vite_page_type'] = 'Page Type';
				$new['vite_out_links'] = '<span class="vite-col-icon" title="Outbound internal links">' . self::svg_icon('out') . '</span>';
				$new['vite_in_links']  = '<span class="vite-col-icon" title="Inbound internal links">' . self::svg_icon('in') . '</span>';
			}
			$new[$key] = $label;
		}

		if (!isset($columns['comments'])) {
			$new['vite_page_type'] = 'Page Type';
			$new['vite_out_links'] = '<span class="vite-col-icon" title="Outbound internal links">' . self::svg_icon('out') . '</span>';
			$new['vite_in_links']  = '<span class="vite-col-icon" title="Inbound internal links">' . self::svg_icon('in') . '</span>';
		}

		return $new;
	}

	private static function page_type_label(string $value): string {
		switch ($value) {
			case 'pillar': return 'Pillar';
			case 'hub': return 'Hub';
			case 'section': return 'Section';
			case 'glossary': return 'Glossary';
			default: return '—';
		}
	}

	public static function render_admin_column(string $column, int $post_id) {
		if ($column === 'vite_page_type') {
			$post = get_post($post_id);
			if ($post && $post->post_type === 'post') {
				$val = (string) get_post_meta($post_id, self::META_PAGE_TYPE, true);
				$val = self::sanitize_page_type($val);
				$label = self::page_type_label($val);
				echo '<span class="vite-page-type" data-vite-page-type="' . esc_attr($val) . '">' . esc_html($label) . '</span>';
			} else {
				echo '—';
			}
			return;
		}

		if ($column === 'vite_out_links') {
			$count = (int) get_post_meta($post_id, self::META_OUT_COUNT, true);
			$url = add_query_arg([
				'page' => 'vite-link-report',
				'post_id' => $post_id,
				'dir' => 'out',
			], admin_url('admin.php'));
			echo '<a href="' . esc_url($url) . '" class="vite-link-count" title="Outbound internal targets: ' . esc_attr((string) $count) . '">'
				. '<span class="vite-link-count__icon">' . self::svg_icon('out') . '</span>'
				. '<span class="screen-reader-text">Outbound internal links: ' . esc_html((string) $count) . '</span>'
				. '<span class="vite-link-count__badge">' . esc_html((string) $count) . '</span>'
				. '</a>';
			return;
		}

		if ($column === 'vite_in_links') {
			$count = (int) get_post_meta($post_id, self::META_IN_COUNT, true);
			$url = add_query_arg([
				'page' => 'vite-link-report',
				'post_id' => $post_id,
				'dir' => 'in',
			], admin_url('admin.php'));
			echo '<a href="' . esc_url($url) . '" class="vite-link-count" title="Inbound internal sources: ' . esc_attr((string) $count) . '">'
				. '<span class="vite-link-count__icon">' . self::svg_icon('in') . '</span>'
				. '<span class="screen-reader-text">Inbound internal links: ' . esc_html((string) $count) . '</span>'
				. '<span class="vite-link-count__badge">' . esc_html((string) $count) . '</span>'
				. '</a>';
			return;
		}
	}

	public static function add_sortable_columns(array $columns): array {
		$columns['vite_out_links'] = 'vite_out_links';
		$columns['vite_in_links']  = 'vite_in_links';
		$columns['vite_page_type'] = 'vite_page_type';
		return $columns;
	}

	public static function handle_admin_sorting(\WP_Query $q) {
		if (!is_admin() || !$q->is_main_query()) return;
		$orderby = (string) $q->get('orderby');

		if ($orderby === 'vite_out_links') {
			$q->set('meta_key', self::META_OUT_COUNT);
			$q->set('orderby', 'meta_value_num');
		} elseif ($orderby === 'vite_in_links') {
			$q->set('meta_key', self::META_IN_COUNT);
			$q->set('orderby', 'meta_value_num');
		} elseif ($orderby === 'vite_page_type') {
			$q->set('meta_key', self::META_PAGE_TYPE);
			$q->set('orderby', 'meta_value');
		}
	}

	public static function output_admin_styles() {
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if (!$screen || $screen->base !== 'edit') return;
		if (!in_array($screen->post_type, ['post', 'page'], true)) return;

		echo '<style>
			.column-vite_out_links, .column-vite_in_links { width: 78px; text-align: center; }
			.column-vite_page_type { width: 110px; }
			.vite-col-icon svg { color: #1d2327; vertical-align: middle; }
			.vite-link-count { display: inline-flex; align-items: center; gap: 6px; text-decoration: none; }
			.vite-link-count__icon svg { width: 16px; height: 16px; vertical-align: middle; }
			.vite-link-count__badge {
				display: inline-flex;
				align-items: center;
				justify-content: center;
				min-width: 18px;
				height: 18px;
				padding: 0 5px;
				border-radius: 999px;
				background: #1d2327;
				color: #fff;
				font-size: 11px;
				line-height: 18px;
			}
		</style>';
	}

	/**
	 * -----------------------------
	 * Quick Edit: Page Type
	 * -----------------------------
	 */

	public static function render_quick_edit(string $column_name, string $post_type) {
		if ($post_type !== 'post') return;
		if ($column_name !== 'vite_page_type') return;

		wp_nonce_field('vite_page_type_quick_edit', 'vite_page_type_nonce');

		echo '<fieldset class="inline-edit-col-right"><div class="inline-edit-col">';
		echo '<label class="alignleft"><span class="title">Page Type</span>';
		echo '<select name="' . esc_attr(self::META_PAGE_TYPE) . '" class="vite-quick-page-type">';
		echo '<option value="">—</option>';
		echo '<option value="pillar">Pillar</option>';
		echo '<option value="hub">Hub</option>';
		echo '<option value="section">Section</option>';
		echo '<option value="glossary">Glossary</option>';
		echo '</select></label>';
		echo '</div></fieldset>';
	}

	public static function render_bulk_edit(string $column_name, string $post_type) {
		if ($post_type !== 'post') return;
		if ($column_name !== 'vite_page_type') return;

		echo '<fieldset class="inline-edit-col-right"><div class="inline-edit-col">';
		echo '<label class="alignleft"><span class="title">Page Type</span>';
		echo '<select name="' . esc_attr(self::META_PAGE_TYPE) . '" class="vite-bulk-page-type">';
		echo '<option value="__no_change__">- No Change -</option>';
		echo '<option value="pillar">Pillar</option>';
		echo '<option value="hub">Hub</option>';
		echo '<option value="section">Section</option>';
		echo '<option value="glossary">Glossary</option>';
		echo '<option value="__clear__">- Clear -</option>';
		echo '</select></label>';
		echo '</div></fieldset>';
	}

	public static function enqueue_quick_edit_js(string $hook) {
		if ($hook !== 'edit.php') return;
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if (!$screen || $screen->post_type !== 'post') return;

		$src = plugin_dir_url(__FILE__) . 'vite-content-graph-quick-edit.js';
		wp_enqueue_script(
			'vite-content-graph-quick-edit',
			$src,
			['jquery', 'inline-edit-post'],
			'1.0.0',
			true
		);
	}

	public static function save_quick_edit_page_type(int $post_id, \WP_Post $post) {
		if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
		if ($post->post_type !== 'post') return;
		if (!current_user_can('edit_post', $post_id)) return;

		$has_quick_nonce = isset($_POST['vite_page_type_nonce']);
		$is_bulk_edit = isset($_REQUEST['bulk_edit']) || isset($_REQUEST['bulk_edit_posts']);

		// Only handle quick edit or bulk edit submissions.
		if (!$has_quick_nonce && !$is_bulk_edit) {
			return;
		}

		$source = null;

		if ($has_quick_nonce) {
			if (!wp_verify_nonce((string) $_POST['vite_page_type_nonce'], 'vite_page_type_quick_edit')) return;
			$source = $_POST;
		} else {
			$bulk_nonce_ok = false;
			if (isset($_REQUEST['_wpnonce']) && wp_verify_nonce((string) $_REQUEST['_wpnonce'], 'bulk-posts')) {
				$bulk_nonce_ok = true;
			}
			if (!$bulk_nonce_ok && isset($_REQUEST['_inline_edit']) && wp_verify_nonce((string) $_REQUEST['_inline_edit'], 'inlineeditnonce')) {
				$bulk_nonce_ok = true;
			}
			if (!$bulk_nonce_ok) return;
			$source = $_REQUEST;
		}

		if (!isset($source[self::META_PAGE_TYPE])) return;
		$raw = (string) wp_unslash($source[self::META_PAGE_TYPE]);

		if ($is_bulk_edit && $raw === '__no_change__') return;
		if ($is_bulk_edit && $raw === '__clear__') $raw = '';

		$val = self::sanitize_page_type($raw);
		update_post_meta($post_id, self::META_PAGE_TYPE, $val);
	}

	/**
	 * -----------------------------
	 * Tools > Link report
	 * -----------------------------
	 */

	public static function register_link_report_page() {
		vite_register_seo_tools_menu();
		add_submenu_page(
			'vite-seo-tools',
			'Link Report',
			'Link Report',
			'edit_posts',
			'vite-link-report',
			[__CLASS__, 'render_link_report_page']
		);
	}

	/**
	 * -----------------------------
	 * Tools > Link Graph Rebuild
	 * -----------------------------
	 */

	public static function register_rebuild_page() {
		vite_register_seo_tools_menu();
		add_submenu_page(
			'vite-seo-tools',
			'Link Graph Rebuild',
			'Link Graph Rebuild',
			'manage_options',
			self::REBUILD_PAGE_SLUG,
			[__CLASS__, 'render_rebuild_page']
		);
	}

	private static function rebuild_query(int $paged): \WP_Query {
		return new \WP_Query([
			'post_type' => ['post', 'page'],
			'post_status' => 'publish',
			'posts_per_page' => self::REBUILD_BATCH_SIZE,
			'paged' => max(1, $paged),
			'fields' => 'ids',
			'orderby' => 'ID',
			'order' => 'ASC',
			'no_found_rows' => false,
		]);
	}

	private static function rebuild_clear_batch(array $ids) {
		foreach ($ids as $id) {
			$id = (int) $id;
			if ($id <= 0) continue;
			delete_post_meta($id, self::META_OUT_TARGET_IDS);
			delete_post_meta($id, self::META_OUT_COUNT);
			delete_post_meta($id, self::META_IN_SOURCE_IDS);
			delete_post_meta($id, self::META_IN_COUNT);
		}
	}

	private static function rebuild_index_batch(array $ids) {
		foreach ($ids as $id) {
			$id = (int) $id;
			if ($id <= 0) continue;
			$post = get_post($id);
			if (!$post || $post->post_status !== 'publish') continue;
			self::index_internal_links_on_save($id, $post, true);
		}
	}

	public static function handle_rebuild_requests() {
		if (!is_admin()) return;
		if (!current_user_can('manage_options')) return;
		if (!isset($_GET['page']) || (string) $_GET['page'] !== self::REBUILD_PAGE_SLUG) return;
		if (isset($_POST['vite_content_graph_action']) && (string) $_POST['vite_content_graph_action'] === 'save_hosts') {
			check_admin_referer('vite_content_graph_save_hosts');
			$raw = isset($_POST['vite_content_graph_hosts']) ? (string) wp_unslash($_POST['vite_content_graph_hosts']) : '';
			$raw = preg_replace('~[^a-zA-Z0-9\.\-\s,]~', '', $raw);
			update_option(self::OPTION_ALLOWED_HOSTS, trim((string) $raw), false);
			wp_safe_redirect(add_query_arg(['page' => self::REBUILD_PAGE_SLUG, 'saved' => 1], admin_url('admin.php')));
			exit;
		}
		if (!isset($_GET['run']) || (string) $_GET['run'] !== '1') return;

		check_admin_referer('vite_link_graph_rebuild');

		$stage = isset($_GET['stage']) ? sanitize_key((string) $_GET['stage']) : 'clear';
		$paged = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;

		if (!in_array($stage, ['clear', 'index'], true)) $stage = 'clear';

		$q = self::rebuild_query($paged);
		$ids = is_array($q->posts) ? $q->posts : [];

		if ($ids) {
			if ($stage === 'clear') self::rebuild_clear_batch($ids);
			else self::rebuild_index_batch($ids);
		}

		$total_pages = (int) ($q->max_num_pages ?? 0);

		// Next step
		$next_stage = $stage;
		$next_paged = $paged + 1;

		if ($total_pages > 0 && $paged >= $total_pages) {
			if ($stage === 'clear') {
				$next_stage = 'index';
				$next_paged = 1;
			} else {
				// Done
				$done_url = add_query_arg([
					'page' => self::REBUILD_PAGE_SLUG,
					'done' => 1,
				], admin_url('admin.php'));
				wp_safe_redirect($done_url);
				exit;
			}
		}

		$next_url = wp_nonce_url(add_query_arg([
			'page' => self::REBUILD_PAGE_SLUG,
			'run' => 1,
			'stage' => $next_stage,
			'paged' => $next_paged,
		], admin_url('admin.php')), 'vite_link_graph_rebuild');

		wp_safe_redirect($next_url);
		exit;
	}

	public static function render_rebuild_page() {
		if (!current_user_can('manage_options')) wp_die('Forbidden');
		self::render_admin_styles();

		$done = isset($_GET['done']) ? (int) $_GET['done'] : 0;
		$saved = isset($_GET['saved']) ? (int) $_GET['saved'] : 0;

		echo '<div class="wrap vite-cg-page">';
		echo '<div class="vite-cg-page__header">';
		echo '<h1 style="margin:0;">Link Graph Rebuild</h1>';
		echo '</div>';
		self::render_docs_modal('rebuild');

		if ($done) {
			echo '<div class="notice notice-success"><p><strong>Done.</strong> Outbound/inbound counts were rebuilt for published posts + pages.</p></div>';
		}
		if ($saved) {
			echo '<div class="notice notice-success"><p><strong>Saved.</strong> Allowed hosts updated.</p></div>';
		}

		echo '<div class="vite-cg-card">';
		echo '<p>Use this page to safely rebuild internal link relationships for your published Posts and Pages.</p>';
		echo '<p>The rebuild runs in small batches to prevent timeouts. Keep this page open until complete.</p>';
		echo '</div>';

		echo '<div class="vite-cg-card">';
		echo '<h2 style="margin-top:0;">Internal Host Settings</h2>';
		echo '<p><strong>Primary host:</strong> <code>' . esc_html(self::internal_host()) . '</code></p>';
		echo '<p>If your content/schema links use a different domain (for example production domain while testing locally), add it here (example: <code>viteseo.ph</code>).</p>';
		echo '<p><strong>Most users on production should leave this unchanged.</strong> Only update this field when your site uses multiple hostnames.</p>';
		echo '<form method="post" class="vite-cg-inline-form">';
		wp_nonce_field('vite_content_graph_save_hosts');
		echo '<input type="hidden" name="vite_content_graph_action" value="save_hosts" />';
		echo '<label><strong>Additional allowed hosts (comma or space separated)</strong><br />';
		echo '<input class="vite-cg-text-input" type="text" name="vite_content_graph_hosts" value="' . esc_attr((string) get_option(self::OPTION_ALLOWED_HOSTS, '')) . '" placeholder="viteseo.ph www.viteseo.ph" />';
		echo '</label>';
		echo '<p class="description">Only links whose host is in this list will be treated as internal. Posts/Pages are still counted only if the URL resolves to a real WP Post/Page.</p>';
		echo '<p><button class="button button-secondary" type="submit">Save Hosts</button></p>';
		echo '</form>';
		echo '</div>';

		echo '<div class="vite-cg-card">';
		echo '<h2 style="margin-top:0;">Run Rebuild</h2>';
		echo '<p>This will rebuild internal link counts for <strong>published</strong> <code>Posts</code> + <code>Pages</code> only. It clears old data first, then re-indexes (content + Schema JSON-LD).</p>';
		echo '<p><strong>Note:</strong> If you have many posts/pages, this runs in small batches to avoid timeouts. Keep this page open until it finishes.</p>';

		$start_url = wp_nonce_url(add_query_arg([
			'page' => self::REBUILD_PAGE_SLUG,
			'run' => 1,
			'stage' => 'clear',
			'paged' => 1,
		], admin_url('admin.php')), 'vite_link_graph_rebuild');

		echo '<p class="vite-cg-primary-actions">';
		echo '<a class="button button-primary" href="' . esc_url($start_url) . '">Rebuild Link Graph Now</a> ';
		echo '<button type="button" class="button vite-cg-guide-btn" id="vite-cg-open-guide-rebuild" aria-haspopup="dialog" aria-controls="vite-cg-guide-modal-rebuild">Open Guide</button>';
		echo '</p>';
		echo '</div>';
		echo '<hr />';
		echo '<p><a href="' . esc_url(admin_url('edit.php?post_type=post')) . '">Back to Posts</a></p>';
		echo '</div>';
	}

	public static function render_link_report_page() {
		if (!current_user_can('edit_posts')) wp_die('Forbidden');
		self::render_admin_styles();

		$post_id = isset($_GET['post_id']) ? (int) $_GET['post_id'] : 0;
		$dir = isset($_GET['dir']) ? sanitize_key((string) $_GET['dir']) : 'out';
		$post = $post_id ? get_post($post_id) : null;

		echo '<div class="wrap vite-cg-page">';
		echo '<div class="vite-cg-page__header vite-cg-page__header--inline">';
		echo '<h1 style="margin:0;">Link Report</h1>';
		echo '<button type="button" class="button button-secondary vite-cg-guide-btn" id="vite-cg-open-guide-report" aria-haspopup="dialog" aria-controls="vite-cg-guide-modal-report">Open Guide</button>';
		echo '</div>';
		self::render_docs_modal('report');

		if (!$post) {
			echo '<div class="vite-cg-card"><p>Select a post from the Posts or Pages list to view inbound/outbound link details.</p></div>';
			echo '</div>';
			return;
		}

		$title = get_the_title($post_id);
		echo '<div class="vite-cg-card">';
		echo '<p><strong>Item:</strong> ' . esc_html($title ?: ('#' . $post_id)) . ' <code>(' . esc_html($post->post_type) . ')</code></p>';
		echo '<p class="description">Use this report to understand how this content connects to other content on your site.</p>';
		echo '</div>';

		if ($dir === 'in') {
			$sources = self::get_meta_int_array($post_id, self::META_IN_SOURCE_IDS);
			echo '<div class="vite-cg-card">';
			echo '<h2 style="margin-top:0;">Inbound sources (' . esc_html((string) count($sources)) . ')</h2>';
			if (!$sources) {
				echo '<p>No inbound links found for this item yet.</p>';
			} else {
				echo '<table class="widefat striped vite-cg-table"><thead><tr><th>Title</th><th>Type</th><th>Actions</th></tr></thead><tbody>';
				foreach ($sources as $sid) {
					$sp = get_post($sid);
					if (!$sp) continue;
					$edit = get_edit_post_link($sid, 'raw');
					$view = get_permalink($sid);
					echo '<tr>';
					echo '<td>' . esc_html(get_the_title($sid) ?: ('#' . $sid)) . '</td>';
					echo '<td><code>' . esc_html($sp->post_type) . '</code></td>';
					echo '<td>'
						. ($edit ? '<a href="' . esc_url($edit) . '">Edit</a>' : '')
						. ($edit && $view ? ' | ' : '')
						. ($view ? '<a href="' . esc_url($view) . '" target="_blank" rel="noopener noreferrer">View</a>' : '')
						. '</td>';
					echo '</tr>';
				}
				echo '</tbody></table>';
			}
			echo '</div>';
		} else {
			$targets = self::get_meta_int_array($post_id, self::META_OUT_TARGET_IDS);
			echo '<div class="vite-cg-card">';
			echo '<h2 style="margin-top:0;">Outbound targets (' . esc_html((string) count($targets)) . ')</h2>';
			if (!$targets) {
				echo '<p>No outbound links found for this item yet.</p>';
			} else {
				echo '<table class="widefat striped vite-cg-table"><thead><tr><th>Title</th><th>Type</th><th>Actions</th></tr></thead><tbody>';
				foreach ($targets as $tid) {
					$tp = get_post($tid);
					if (!$tp) continue;
					$edit = get_edit_post_link($tid, 'raw');
					$view = get_permalink($tid);
					echo '<tr>';
					echo '<td>' . esc_html(get_the_title($tid) ?: ('#' . $tid)) . '</td>';
					echo '<td><code>' . esc_html($tp->post_type) . '</code></td>';
					echo '<td>'
						. ($edit ? '<a href="' . esc_url($edit) . '">Edit</a>' : '')
						. ($edit && $view ? ' | ' : '')
						. ($view ? '<a href="' . esc_url($view) . '" target="_blank" rel="noopener noreferrer">View</a>' : '')
						. '</td>';
					echo '</tr>';
				}
				echo '</tbody></table>';
			}
			echo '</div>';
		}

		echo '<hr />';
		echo '<p><a href="' . esc_url(admin_url('edit.php?post_type=post')) . '">Back to Posts</a></p>';
		echo '</div>';
	}

	private static function render_admin_styles() {
		echo '<style>
		.vite-cg-page { max-width: none; width: 95%; }
		.vite-cg-page__header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom: 12px; flex-wrap: wrap; }
		.vite-cg-page__header--inline { justify-content:flex-start; }
		.vite-cg-card { background:#fff; border:1px solid #dcdcde; border-radius:10px; box-shadow:0 1px 2px rgba(16,24,40,.04); padding:16px 18px; margin:0 0 14px; }
		.vite-cg-card p { margin: 8px 0; line-height: 1.55; }
		.vite-cg-guide-btn { border-color:#dba617; background:#ffe082 !important; color:#5f4500 !important; font-weight:600; }
		.vite-cg-guide-btn:hover, .vite-cg-guide-btn:focus { border-color:#c79312; background:#ffd45a !important; color:#4f3900; }
		.vite-cg-primary-actions { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
		.vite-cg-inline-form { margin: 12px 0 0; }
		.vite-cg-text-input { width:100%; max-width:680px; border:1px solid #8c8f94; border-radius:7px; padding:8px; }
		.vite-cg-table th { font-weight:600; }
		.vite-cg-table td { vertical-align: top; }
		#vite-cg-guide-modal-rebuild[hidden], #vite-cg-guide-modal-report[hidden] { display: none !important; }
		.vite-cg-guide-modal { position: fixed; inset: 0; z-index: 100000; background: rgba(0,0,0,.45); display: flex; align-items: center; justify-content: center; padding: 20px; }
		.vite-cg-guide__panel { width: min(980px, calc(100vw - 24px)); max-height: 86vh; overflow: auto; background: #fff; border-radius: 10px; box-shadow: 0 16px 38px rgba(0,0,0,.18); }
		.vite-cg-guide__header { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #dcdcde; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
		.vite-cg-guide__body { padding: 16px; }
		.vite-cg-guide__body h3 { margin: 18px 0 8px; }
		.vite-cg-guide__body p { margin: 8px 0; line-height: 1.5; }
		.vite-cg-guide__body ul, .vite-cg-guide__body ol { margin: 8px 0 10px 18px; }
		.vite-cg-guide__body pre { background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 6px; padding: 10px; white-space: pre-wrap; word-break: break-word; }
		@media (max-width: 782px) {
			.vite-cg-guide-modal { padding: 10px; }
			.vite-cg-guide__header { padding: 10px 12px; }
			.vite-cg-guide__body { padding: 12px; }
		}
		</style>';
	}

	private static function render_docs_modal(string $context) {
		$is_rebuild = $context === 'rebuild';
		$modal_id = $is_rebuild ? 'vite-cg-guide-modal-rebuild' : 'vite-cg-guide-modal-report';
		$title_id = $is_rebuild ? 'vite-cg-guide-title-rebuild' : 'vite-cg-guide-title-report';
		$open_id = $is_rebuild ? 'vite-cg-open-guide-rebuild' : 'vite-cg-open-guide-report';
		$close_id = $is_rebuild ? 'vite-cg-close-guide-rebuild' : 'vite-cg-close-guide-report';

		echo '<div id="' . esc_attr($modal_id) . '" class="vite-cg-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="' . esc_attr($title_id) . '">';
		echo '<div class="vite-cg-guide__panel">';
		echo '<div class="vite-cg-guide__header">';
		echo '<strong id="' . esc_attr($title_id) . '">Content Graph Guide</strong>';
		echo '<button type="button" class="button" id="' . esc_attr($close_id) . '" aria-label="Close guide">Close</button>';
		echo '</div>';
		echo '<div class="vite-cg-guide__body">';
		echo '<p>This plugin tracks internal content links between your Posts and Pages so your team can improve interlinking and site structure.</p>';
		echo '<h3>What this plugin can do</h3>';
		echo '<ul>';
		echo '<li>Calculates outbound links (where a post links out to).</li>';
		echo '<li>Calculates inbound links (which posts/pages link into a post).</li>';
		echo '<li>Supports link extraction from content and JSON-LD schema links.</li>';
		echo '<li>Adds report pages for simple auditing.</li>';
		echo '</ul>';

		if ($is_rebuild) {
			echo '<h3>Step-by-step: Rebuild Link Graph</h3>';
			echo '<ol>';
			echo '<li>Open <strong>SEO Tools &gt; Link Graph Rebuild</strong>.</li>';
			echo '<li>Review Internal Host Settings (usually no changes needed on production).</li>';
			echo '<li>Click <strong>Rebuild Link Graph Now</strong>.</li>';
			echo '<li>Wait for completion notice.</li>';
			echo '<li>Open Link Report from a post to inspect details.</li>';
			echo '</ol>';
			echo '<h3>Internal Host Settings (important)</h3>';
			echo '<p>Leave this field unchanged unless your content/schema uses another hostname. Example use case: local domain during testing but production links in JSON-LD.</p>';
			echo '<h3>When should I run rebuild?</h3>';
			echo '<ul>';
			echo '<li>After large content imports/migrations.</li>';
			echo '<li>After changing domains or hostnames.</li>';
			echo '<li>If link counts look outdated.</li>';
			echo '</ul>';
		} else {
			echo '<h3>Step-by-step: Use Link Report</h3>';
			echo '<ol>';
			echo '<li>Open a Post/Page list in admin.</li>';
			echo '<li>Open Link Report for an item.</li>';
			echo '<li>Choose inbound or outbound view.</li>';
			echo '<li>Review titles and jump to Edit/View links.</li>';
			echo '<li>Use findings to improve internal linking.</li>';
			echo '</ol>';
			echo '<h3>How to read report results</h3>';
			echo '<ul>';
			echo '<li><strong>Inbound:</strong> pages that point to this item.</li>';
			echo '<li><strong>Outbound:</strong> pages this item points to.</li>';
			echo '<li><strong>No results:</strong> no tracked internal links yet.</li>';
			echo '</ul>';
		}

		echo '</div>';
		echo '</div>';
		echo '</div>';

		echo '<script>
		(function () {
			function initGuideModal() {
				var openBtn = document.getElementById("' . esc_js($open_id) . '");
				var closeBtn = document.getElementById("' . esc_js($close_id) . '");
				var modal = document.getElementById("' . esc_js($modal_id) . '");
				if (!openBtn || !closeBtn || !modal) return;
				function openGuide() { modal.hidden = false; modal.setAttribute("aria-hidden", "false"); }
				function closeGuide() { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); }
				openBtn.addEventListener("click", openGuide);
				closeBtn.addEventListener("click", closeGuide);
				modal.addEventListener("click", function (event) { if (event.target === modal) closeGuide(); });
				document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !modal.hidden) closeGuide(); });
			}
			if (document.readyState === "loading") {
				document.addEventListener("DOMContentLoaded", initGuideModal);
			} else {
				initGuideModal();
			}
		})();
		</script>';
	}
}

Vite_Content_Graph::init();


