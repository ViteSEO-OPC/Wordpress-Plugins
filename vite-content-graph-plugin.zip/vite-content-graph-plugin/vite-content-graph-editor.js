(function (wp) {
  const { registerPlugin } = wp.plugins;
  const { PluginDocumentSettingPanel } = wp.editPost;
  const { SelectControl, Notice } = wp.components;
  const { useSelect, useDispatch } = wp.data;
  const { useMemo } = wp.element;

  const META_PAGE_TYPE = "vite_page_type";

  function safeTrim(v) {
    return (v || "").toString().trim();
  }

  function PageTypePanel() {
    const postType = useSelect((select) => select("core/editor").getCurrentPostType(), []);
    const meta = useSelect((select) => select("core/editor").getEditedPostAttribute("meta") || {}, []);
    const { editPost } = useDispatch("core/editor");

    const pageType = safeTrim(meta[META_PAGE_TYPE]);

    const help = useMemo(() => {
      if (!pageType) return "Choose a page type label for internal planning (does not change URL automatically).";
      if (pageType === "pillar") return "Pillar Page - broad/top-level topic.";
      if (pageType === "hub") return "Hub Page - under a pillar; clusters related topics.";
      if (pageType === "section") return "Section Page - under a hub; targets a narrower inquiry.";
      if (pageType === "glossary") return "Glossary Page - intended to appear under your Glossary section.";
      return "";
    }, [pageType]);

    if (postType !== "post") return null;

    return wp.element.createElement(
      PluginDocumentSettingPanel,
      { name: "vite-content-graph", title: "Content Graph", className: "vite-content-graph" },
      wp.element.createElement(Notice, { status: "info", isDismissible: false }, "Page Type is used for your internal structure (Pillar/Hub/Section/Glossary)."),
      wp.element.createElement(SelectControl, {
        label: "Page Type",
        value: pageType,
        options: [
          { label: "—", value: "" },
          { label: "Pillar Page", value: "pillar" },
          { label: "Hub Page", value: "hub" },
          { label: "Section Page", value: "section" },
          { label: "Glossary Page", value: "glossary" },
        ],
        onChange: (v) => editPost({ meta: { [META_PAGE_TYPE]: v } }),
        help,
      })
    );
  }

  registerPlugin("vite-content-graph", { render: PageTypePanel });
})(window.wp);


