<?php
/**
 * Plugin Name: SEO Diagnostic Tool (MU)
 * Description: Admin SEO diagnostics with module-based scans and export reports.
 * Version: 1.0.0
 * Author: Viteseo
 */

namespace SDT;

use SDT\Analyzers\BrokenInternalLinksAnalyzer;
use SDT\Analyzers\ContentAuditAnalyzer;
use SDT\Analyzers\DuplicateContentAnalyzer;
use SDT\Analyzers\HeadingStructureAnalyzer;
use SDT\Analyzers\ImageOptimizeAnalyzer;
use SDT\Analyzers\IndexabilityAnalyzer;
use SDT\Analyzers\MissingMetaAnalyzer;

if (!defined('SDT_VERSION')) {
	define('SDT_VERSION', '1.0.0');
}

class ScanService
{
	public static function run(string $module, array $rules): array
	{
		$module = sanitize_key($module);
		$rules = self::sanitizeRules($rules);
		$posts = self::loadPosts($rules);
		$totalScanned = count($posts);
		$duplicatesOnly = ($module === 'content_audit') && !empty($rules['duplicates_only']);

 		switch ($module) {
			case 'content_audit':
				$rows = ContentAuditAnalyzer::analyze($posts, $rules);
				break;
			case 'image_optimize':
				$rows = ImageOptimizeAnalyzer::analyze($posts, $rules);
				break;
			case 'missing_meta':
				$rows = MissingMetaAnalyzer::analyze($posts, $rules);
				break;
			case 'heading_structure':
				$rows = HeadingStructureAnalyzer::analyze($posts, $rules);
				break;
			case 'broken_internal_links':
				$rows = BrokenInternalLinksAnalyzer::analyze($posts, $rules);
				break;
			case 'indexability_checks':
				$rows = IndexabilityAnalyzer::analyze($posts, $rules);
				break;
			default:
				$rows = [];
		}

		if ($duplicatesOnly) {
			$rows = self::filterDuplicateRows($rows, $rules['fields'] ?? []);
		}

		if ($module === 'content_audit' && !$duplicatesOnly) {
			$issueCount = 0;
			$passRate = 100.0;
		} else {
			$issueCount = count($rows);
			$passRate = ($totalScanned > 0)
				? round((($totalScanned - min($issueCount, $totalScanned)) / $totalScanned) * 100, 2)
				: 100.0;
		}

		return [
			'module' => $module,
			'total_scanned' => $totalScanned,
			'issue_count' => $issueCount,
			'pass_rate' => $passRate,
			'columns' => ($module === 'content_audit')
				? (($duplicatesOnly
						? array_values(array_unique(array_merge(['post_link'], $rules['fields'] ?? [], ['duplicate_reason'])))
						: (isset($rules['fields']) && is_array($rules['fields']) && !empty($rules['fields'])
							? array_values(array_unique(array_merge(['post_link'], $rules['fields'])))
							: ['post_link'])))
				: [],
			'rows' => array_values($rows),
		];
	}

	private static function filterDuplicateRows(array $rows, array $fields): array
	{
		if (empty($rows)) {
			return [];
		}

		$targetFields = array_values(array_filter(array_unique(array_map('sanitize_key', $fields)), static function ($field): bool {
			return $field !== '' && $field !== 'post_link';
		}));
		if (empty($targetFields)) {
			return [];
		}

		$valueToMeta = [];
		foreach ($rows as $row) {
			if (!is_array($row)) {
				continue;
			}
			$contentId = isset($row['content_id']) ? (int) $row['content_id'] : 0;
			if ($contentId <= 0) {
				continue;
			}
			foreach ($targetFields as $field) {
				$displayValue = trim((string) ($row[$field] ?? ''));
				// Heading count "0" means missing structure and should not be treated as duplicate content.
				if (in_array($field, ['h1', 'h2', 'h3', 'h4'], true) && $displayValue === '0') {
					continue;
				}
				$normalized = self::normalizeDuplicateValue($displayValue);
				if ($normalized === '') {
					continue;
				}
				$key = $field . '||' . $normalized;
				if (!isset($valueToMeta[$key])) {
					$valueToMeta[$key] = [
						'field' => $field,
						'value' => $displayValue,
						'ids' => [],
					];
				}
				$valueToMeta[$key]['ids'][$contentId] = true;
			}
		}

		$duplicateIds = [];
		$duplicateFieldsById = [];
		$duplicateReasonsById = [];
		foreach ($valueToMeta as $meta) {
			$idsMap = isset($meta['ids']) && is_array($meta['ids']) ? $meta['ids'] : [];
			if (count($idsMap) < 2) {
				continue;
			}
			$field = isset($meta['field']) ? (string) $meta['field'] : '';
			$ids = array_map('intval', array_keys($idsMap));
			sort($ids, SORT_NUMERIC);
			$idsText = implode(', ', $ids);
			$valueText = trim((string) ($meta['value'] ?? ''));
			$valueText = preg_replace('/\s+/u', ' ', $valueText);
			if (mb_strlen((string) $valueText) > 80) {
				$valueText = mb_substr((string) $valueText, 0, 80) . '...';
			}
			$reason = sprintf(
				'%s has same value in posts: %s%s',
				self::prettyDuplicateFieldLabel($field),
				$idsText,
				($valueText !== '' ? ' (value: "' . $valueText . '")' : '')
			);
			foreach ($ids as $id) {
				$id = (int) $id;
				$duplicateIds[$id] = true;
				if (!isset($duplicateFieldsById[$id])) {
					$duplicateFieldsById[$id] = [];
				}
				$duplicateFieldsById[$id][$field] = true;
				if (!isset($duplicateReasonsById[$id])) {
					$duplicateReasonsById[$id] = [];
				}
				$duplicateReasonsById[$id][] = $reason;
			}
		}

		if (empty($duplicateIds)) {
			return [];
		}

		$out = [];
		foreach ($rows as $row) {
			if (!is_array($row)) {
				continue;
			}
			$contentId = isset($row['content_id']) ? (int) $row['content_id'] : 0;
			if ($contentId <= 0 || !isset($duplicateIds[$contentId])) {
				continue;
			}
			$fieldsForRow = isset($duplicateFieldsById[$contentId]) ? array_keys($duplicateFieldsById[$contentId]) : [];
			if (!empty($fieldsForRow)) {
				$row['issue_type'] = 'Duplicate in: ' . implode(', ', $fieldsForRow);
			}
			$reasons = isset($duplicateReasonsById[$contentId]) ? array_values(array_unique($duplicateReasonsById[$contentId])) : [];
			$row['duplicate_reason'] = implode("\n", $reasons);
			$out[] = $row;
		}

		return $out;
	}

	private static function normalizeDuplicateValue($value): string
	{
		if (is_array($value)) {
			$value = implode("\n", array_map(static fn($item) => (string) $item, $value));
		}
		$text = trim((string) $value);
		if ($text === '') {
			return '';
		}
		$text = preg_replace('/\s+/u', ' ', $text);
		$lower = function_exists('mb_strtolower') ? mb_strtolower((string) $text, 'UTF-8') : strtolower((string) $text);
		$placeholderValues = [
			'', '-', '--', 'n/a', 'na', 'none', 'null', '(empty)', 'empty', 'not set', 'no data', 'n\\a', '{}', '[]',
		];
		if (in_array($lower, $placeholderValues, true)) {
			return '';
		}
		return $lower;
	}

	private static function prettyDuplicateFieldLabel(string $field): string
	{
		$map = [
			'seo_title' => 'SEO Title',
			'seo_meta_description' => 'SEO Meta Description',
			'h1' => 'H1',
			'h2' => 'H2',
			'h3' => 'H3',
			'h4' => 'H4',
			'slug' => 'Slug',
			'excerpt' => 'Excerpt',
			'categories' => 'Categories',
			'tags' => 'Tags',
			'page_type' => 'Page Type',
			'featured_image' => 'Featured Image',
			'featured_image_size_kb' => 'Featured Image Size (KB)',
			'featured_alt' => 'Featured Alt',
			'image_content_urls' => 'Image Content URL(s)',
			'image_content_sizes_kb' => 'Image Content Size(s) (KB)',
			'image_content_alt' => 'Image Content Alt',
			'inbound' => 'Inbound',
			'outbound' => 'Outbound',
			'schema_json_ld' => 'Schema JSON-LD',
			'robots' => 'Robots',
		];
		return $map[$field] ?? $field;
	}

	public static function baseStatuses(): array
	{
		$statuses = get_post_stati([], 'names');
		$excluded = ['auto-draft', 'trash', 'inherit'];
		$clean = array_values(array_diff($statuses, $excluded));
		if (empty($clean)) {
			$clean = ['publish', 'draft', 'pending', 'future', 'private'];
		}
		return $clean;
	}

	/**
	 * @return \WP_Post[]
	 */
	private static function loadPosts(array $rules): array
	{
		$scope = isset($rules['content_scope']) ? (string) $rules['content_scope'] : 'all';
		$postType = ['post', 'page'];
		if ($scope === 'post') {
			$postType = ['post'];
		} elseif ($scope === 'page') {
			$postType = ['page'];
		}

		$args = [
			'post_type' => $postType,
			'post_status' => self::baseStatuses(),
			'orderby' => 'date',
			'order' => 'DESC',
			'ignore_sticky_posts' => true,
		];
		$yearMonth = isset($rules['year_month']) ? (string) $rules['year_month'] : '';
		if (preg_match('/^(\d{4})-(\d{2})$/', $yearMonth, $m)) {
			$year = (int) $m[1];
			$month = (int) $m[2];
			if ($year > 0 && $month >= 1 && $month <= 12) {
				$args['date_query'] = [[
					'year' => $year,
					'monthnum' => $month,
				]];
			}
		}

		$scanMode = isset($rules['scan_mode']) ? (string) $rules['scan_mode'] : 'all';
		if ($scanMode === 'phase') {
			$phaseSize = max(1, min(1000, (int) ($rules['phase_size'] ?? 100)));
			$phaseNumber = max(1, (int) ($rules['phase_number'] ?? 1));
			$args['posts_per_page'] = $phaseSize;
			$args['offset'] = ($phaseNumber - 1) * $phaseSize;
			$args['no_found_rows'] = true;
		} else {
			$args['posts_per_page'] = -1;
			$args['no_found_rows'] = true;
		}

		$query = new \WP_Query($args);

		return is_array($query->posts) ? $query->posts : [];
	}

	private static function sanitizeRules(array $rules): array
	{
		$out = [];
		$out['scan_limit'] = isset($rules['scan_limit']) ? (int) $rules['scan_limit'] : 200;
		$scope = isset($rules['content_scope']) ? sanitize_key((string) $rules['content_scope']) : 'all';
		$out['content_scope'] = in_array($scope, ['all', 'post', 'page'], true) ? $scope : 'all';
		$scanMode = isset($rules['scan_mode']) ? sanitize_key((string) $rules['scan_mode']) : 'all';
		$out['scan_mode'] = in_array($scanMode, ['all', 'phase'], true) ? $scanMode : 'all';
		$out['phase_size'] = isset($rules['phase_size']) ? (int) $rules['phase_size'] : 100;
		$out['phase_number'] = isset($rules['phase_number']) ? (int) $rules['phase_number'] : 1;
		$out['max_image_kb'] = isset($rules['max_image_kb']) ? (int) $rules['max_image_kb'] : 150;
		$out['allowed_types'] = isset($rules['allowed_types']) && is_array($rules['allowed_types']) ? array_map('sanitize_key', $rules['allowed_types']) : ['webp'];
		$out['require_alt'] = !empty($rules['require_alt']);
		$out['check_featured'] = !empty($rules['check_featured']);
		$out['check_content_images'] = !array_key_exists('check_content_images', $rules) || !empty($rules['check_content_images']);
		$out['meta_desc_min'] = isset($rules['meta_desc_min']) ? (int) $rules['meta_desc_min'] : 50;
		$out['meta_desc_max'] = isset($rules['meta_desc_max']) ? (int) $rules['meta_desc_max'] : 160;
		$out['title_min'] = isset($rules['title_min']) ? (int) $rules['title_min'] : 20;
		$out['title_max'] = isset($rules['title_max']) ? (int) $rules['title_max'] : 60;
		$out['year_month'] = isset($rules['year_month']) ? sanitize_text_field((string) $rules['year_month']) : '';
		$out['duplicates_only'] = !empty($rules['duplicates_only']);
		$out['fields'] = isset($rules['fields']) && is_array($rules['fields']) ? array_values(array_filter(array_map('sanitize_key', $rules['fields']))) : [];
		if (!in_array('post_link', $out['fields'], true)) {
			array_unshift($out['fields'], 'post_link');
		}
		return $out;
	}
}

class ExportService
{
	private const HEADER_LABELS = [
		'content_id' => 'Content ID',
		'content_type' => 'Type',
		'status' => 'Status',
		'post_link' => 'Post Link',
		'seo_title' => 'SEO Title',
		'seo_meta_description' => 'SEO Meta Description',
		'h1' => 'H1',
		'h2' => 'H2',
		'h3' => 'H3',
		'h4' => 'H4',
		'slug' => 'Slug',
		'excerpt' => 'Excerpt',
		'categories' => 'Categories',
		'tags' => 'Tags',
		'page_type' => 'Page Type',
		'featured_image' => 'Featured Image',
		'featured_image_size_kb' => 'Featured Image Size (KB)',
		'featured_alt' => 'Featured Alt',
		'image_content_urls' => 'Image Content URL(s)',
		'image_content_sizes_kb' => 'Image Content Size(s) (KB)',
		'image_content_alt' => 'Image Content Alt',
		'inbound' => 'Inbound',
		'outbound' => 'Outbound',
		'schema_json_ld' => 'Schema JSON-LD',
		'robots' => 'Robots',
		'issue_type' => 'Issue',
		'actual_value' => 'Actual',
		'expected_value' => 'Expected',
		'post_link' => 'Post Link',
		'asset_link' => 'Asset Link',
	];

	public static function download(string $format, string $module, array $rows): void
	{
		$format = sanitize_key($format);
		$filenameBase = 'seo-diagnostic-' . sanitize_key($module) . '-' . gmdate('Ymd-His');

		if ($format === 'xlsx') {
			self::downloadXlsx($filenameBase . '.xlsx', $rows);
			return;
		}
		if ($format === 'docx') {
			self::downloadDocx($filenameBase . '.docx', $rows);
			return;
		}
		self::downloadCsv($filenameBase . '.csv', $rows);
	}

	private static function headersFromRows(array $rows): array
	{
		if (!$rows) {
			return ['content_id'];
		}
		$first = reset($rows);
		if (!is_array($first)) {
			return ['content_id'];
		}
		$headers = array_keys($first);
		$headers = array_values(array_filter($headers, static fn($k) => $k !== '' && $k !== null));
		if (!in_array('content_id', $headers, true)) {
			array_unshift($headers, 'content_id');
		}
		return $headers;
	}

	private static function normalizeRows(array $rows, array $headers): array
	{
		$out = [];
		foreach ($rows as $r) {
			$line = [];
			foreach ($headers as $k) {
				$line[$k] = isset($r[$k]) ? (string) $r[$k] : '';
			}
			$out[] = $line;
		}
		return $out;
	}

	private static function headerLabel(string $key): string
	{
		return self::HEADER_LABELS[$key] ?? ucwords(str_replace('_', ' ', $key));
	}

	private static function downloadCsv(string $filename, array $rows): void
	{
		$headers = self::headersFromRows($rows);
		$rows = self::normalizeRows($rows, $headers);
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		$fp = fopen('php://output', 'w');
		if ($fp === false) {
			wp_die('Unable to generate CSV.');
		}
		fputcsv($fp, array_map([self::class, 'headerLabel'], $headers));
		foreach ($rows as $r) {
			fputcsv($fp, array_values($r));
		}
		fclose($fp);
		exit;
	}

	private static function downloadXlsx(string $filename, array $rows): void
	{
		if (!class_exists('\ZipArchive')) {
			wp_die('ZipArchive is required for XLSX export.');
		}
		$headers = self::headersFromRows($rows);
		$rows = self::normalizeRows($rows, $headers);
		$tmp = wp_tempnam($filename);
		$zip = new \ZipArchive();
		if ($zip->open($tmp, \ZipArchive::OVERWRITE) !== true) {
			wp_die('Failed creating XLSX package.');
		}

		$sheetRows = [];
		$sheetRows[] = array_map([self::class, 'headerLabel'], $headers);
		foreach ($rows as $r) {
			$sheetRows[] = array_values($r);
		}

		$xmlRows = '';
		foreach ($sheetRows as $ri => $cols) {
			$rowIndex = $ri + 1;
			$xmlRows .= '<row r="' . $rowIndex . '">';
			foreach ($cols as $ci => $value) {
				$cellRef = self::xlsxCellRef($ci + 1, $rowIndex);
				$xmlRows .= '<c r="' . $cellRef . '" t="inlineStr"><is><t>' . esc_html($value) . '</t></is></c>';
			}
			$xmlRows .= '</row>';
		}

		$sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<sheetData>' . $xmlRows . '</sheetData>'
			. '</worksheet>';

		$zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
			. '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
			. '</Types>');

		$zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
			. '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
			. '</Relationships>');

		$zip->addFromString('docProps/app.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
			. '<Application>SEO Diagnostic Tool</Application></Properties>');
		$zip->addFromString('docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">'
			. '<dc:title>SEO Diagnostic Export</dc:title></cp:coreProperties>');

		$zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="Results" sheetId="1" r:id="rId1"/></sheets>'
			. '</workbook>');
		$zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '</Relationships>');
		$zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);

		$zip->close();

		nocache_headers();
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		readfile($tmp);
		@unlink($tmp);
		exit;
	}

	private static function xlsxCellRef(int $column, int $row): string
	{
		$letters = '';
		while ($column > 0) {
			$mod = ($column - 1) % 26;
			$letters = chr(65 + $mod) . $letters;
			$column = intdiv($column - 1, 26);
		}
		return $letters . $row;
	}

	private static function downloadDocx(string $filename, array $rows): void
	{
		if (!class_exists('\ZipArchive')) {
			wp_die('ZipArchive is required for DOCX export.');
		}
		$headers = self::headersFromRows($rows);
		$rows = self::normalizeRows($rows, $headers);
		$tmp = wp_tempnam($filename);
		$zip = new \ZipArchive();
		if ($zip->open($tmp, \ZipArchive::OVERWRITE) !== true) {
			wp_die('Failed creating DOCX package.');
		}

		$tableRows = '';
		$allRows = [array_map([self::class, 'headerLabel'], $headers)];
		foreach ($rows as $r) {
			$allRows[] = array_values($r);
		}
		foreach ($allRows as $row) {
			$tableRows .= '<w:tr>';
			foreach ($row as $cell) {
				$tableRows .= '<w:tc><w:p><w:r><w:t>' . esc_html($cell) . '</w:t></w:r></w:p></w:tc>';
			}
			$tableRows .= '</w:tr>';
		}

		$documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
			. '<w:body><w:p><w:r><w:t>SEO Diagnostic Export</w:t></w:r></w:p>'
			. '<w:tbl>' . $tableRows . '</w:tbl>'
			. '</w:body></w:document>';

		$zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
			. '</Types>');
		$zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
			. '</Relationships>');
		$zip->addFromString('word/document.xml', $documentXml);
		$zip->close();

		nocache_headers();
		header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		readfile($tmp);
		@unlink($tmp);
		exit;
	}
}

class AdminPage
{
	private const MENU_SLUG = 'seo-diagnostic-tool';
	private const NONCE_ACTION = 'sdt_admin_nonce_action';
	private const NONCE_NAME = 'sdt_nonce';

	public static function boot(): void
	{
		add_action('admin_menu', [self::class, 'registerMenu']);
		add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
		add_action('wp_ajax_sdt_run_scan', [self::class, 'ajaxRunScan']);
		add_action('wp_ajax_sdt_quick_edit_get', [self::class, 'ajaxQuickEditGet']);
		add_action('wp_ajax_sdt_quick_edit_save', [self::class, 'ajaxQuickEditSave']);
		add_action('wp_ajax_sdt_bulk_quick_get', [self::class, 'ajaxBulkQuickGet']);
		add_action('wp_ajax_sdt_bulk_quick_save', [self::class, 'ajaxBulkQuickSave']);
		add_action('admin_post_sdt_export', [self::class, 'handleExport']);
	}

	public static function registerMenu(): void
	{
		add_menu_page(
			'SEO Diagnostic Tool',
			'SEO Diagnostic Tool',
			'manage_options',
			self::MENU_SLUG,
			[self::class, 'renderPage'],
			'dashicons-chart-area',
			58
		);
	}

	public static function enqueueAssets(string $hook): void
	{
		if ($hook !== 'toplevel_page_' . self::MENU_SLUG) {
			return;
		}
		wp_enqueue_media();

		wp_register_style('sdt-admin', false, [], SDT_VERSION);
		wp_enqueue_style('sdt-admin');
		wp_add_inline_style('sdt-admin', self::adminCss());

		wp_register_script('sdt-admin', false, [], SDT_VERSION, true);
		wp_enqueue_script('sdt-admin');
		wp_localize_script('sdt-admin', 'SDT_DATA', [
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'adminRoot' => trailingslashit(admin_url()),
			'quickEditNonce' => wp_create_nonce('sdt_quick_edit'),
			'runScanNonce' => wp_create_nonce('sdt_run_scan'),
			'exportAction' => 'sdt_export',
			'nonceAction' => self::NONCE_ACTION,
			'nonceName' => self::NONCE_NAME,
			'labels' => self::moduleLabels(),
			'scanCounts' => self::scanCounts(),
			'monthOptions' => self::scanMonthOptions(),
			'monthCounts' => self::scanMonthCounts(),
		]);
		wp_add_inline_script('sdt-admin', self::adminJs());
	}

	public static function renderPage(): void
	{
		if (!current_user_can('manage_options')) {
			wp_die('Not allowed.');
		}
		?>
		<div class="wrap sdt-wrap">
			<div class="sdt-page-head">
				<h1>SEO Diagnostic Tool</h1>
			</div>

			<div class="sdt-doc-modal" id="sdt-doc-modal" hidden>
				<div class="sdt-doc-backdrop" id="sdt-doc-backdrop"></div>
				<section class="sdt-card sdt-doc-panel" id="sdt-doc-panel" role="dialog" aria-modal="true" aria-labelledby="sdt-doc-title">
					<div class="sdt-doc-head">
						<h2 id="sdt-doc-title">SEO Diagnostic Tool Guide</h2>
						<button type="button" class="button-link" id="sdt-doc-close">Close</button>
					</div>
					<p>
						This tool is a single-page <strong>Content Audit</strong> workspace for SEO specialists and editors.
						You choose exactly which fields to show, run the scan, edit selected rows quickly, and export only the rows you need.
					</p>
					<p>
						<strong>Good for:</strong> SEO QA checks, monthly reviews, duplicate-content checks, and preparing client-ready reports without technical setup.
					</p>

					<h3>What this tool can do</h3>
					<ul>
						<li><strong>Flexible scan scope:</strong> Posts only, Pages only, or both.</li>
						<li><strong>Large-site friendly:</strong> Scan all content or use phase mode (items per phase + phase number).</li>
						<li><strong>Month filter:</strong> Scan only content created in a selected month (YYYY-MM).</li>
						<li><strong>Custom table headers:</strong> Show only the fields you checked (SEO Title, Meta Description, H1-H4, Slug, Excerpt, Categories, Tags, Page Type, image/link/schema/robots fields, etc.).</li>
						<li><strong>Find Duplicates:</strong> Checks only selected headers and returns rows with duplicate values. Empty/missing values are ignored.</li>
						<li><strong>Quick actions:</strong> Quick Edit, Bulk Quick Edit Selected, and selected-row export to CSV/XLSX/DOCX.</li>
						<li><strong>Image maintenance in Quick Edit:</strong> Replace/remove Featured Image, replace/remove specific Content Images by position, and update Featured/Content image alt text.</li>
					</ul>

					<h3>Step-by-step</h3>
					<ol>
						<li>Open <strong>Function Details</strong> and choose <strong>Content Type</strong>, <strong>Scan Mode</strong>, and optional <strong>Created Month</strong>.</li>
						<li>If using <strong>By phase</strong>, set <strong>Items per phase</strong> and choose the <strong>Phase</strong>.</li>
						<li>In <strong>Headers</strong>, check only the fields you want in the results table. <strong>Post Link</strong> is always included.</li>
						<li>Use <strong>Check all fields</strong> if you want a full report.</li>
						<li>Click <strong>Run Diagnostic</strong> for a general audit view, or <strong>Find Duplicates</strong> to focus only on duplicate values in selected headers.</li>
						<li>Review <strong>Results</strong>:
							<ul>
								<li><strong>Quick Edit</strong> updates one row quickly.</li>
								<li>When image headers are selected, Quick Edit includes image controls (Featured Image picker + per-content-image Replace/Remove/Reset).</li>
								<li><strong>Bulk Quick Edit Selected</strong> updates multiple selected rows in one modal.</li>
								<li><strong>Edit</strong> opens the full WordPress editor in a new tab.</li>
							</ul>
						</li>
						<li>Select the rows you want to export, choose format (CSV/XLSX/DOCX), then click <strong>Download</strong>.</li>
						<li>After updates, run the scan again to confirm your fixes.</li>
					</ol>

					<h3>How duplicate results are explained</h3>
					<ul>
						<li>The table includes <strong>Duplicate Details</strong> when you use <strong>Find Duplicates</strong>.</li>
						<li>It tells you which header matched and which post IDs share the same value.</li>
						<li>Blank values are not treated as duplicates.</li>
					</ul>
				</section>
			</div>

			<div class="sdt-doc-modal" id="sdt-quick-modal" hidden>
				<div class="sdt-doc-backdrop" id="sdt-quick-backdrop"></div>
				<section class="sdt-card sdt-doc-panel sdt-quick-panel" role="dialog" aria-modal="true" aria-labelledby="sdt-quick-title">
					<div class="sdt-doc-head">
						<h2 id="sdt-quick-title">Quick Edit</h2>
						<button type="button" class="button-link" id="sdt-quick-close">Close</button>
					</div>
					<div id="sdt-quick-status" class="sdt-quick-status" aria-live="polite"></div>
					<form id="sdt-quick-form">
						<input type="hidden" id="sdt-quick-post-id" />
						<input type="hidden" id="sdt-quick-update-title" value="1" />
						<input type="hidden" id="sdt-quick-update-seo-title" value="0" />
						<input type="hidden" id="sdt-quick-update-meta" value="1" />
						<input type="hidden" id="sdt-quick-update-status" value="0" />
						<input type="hidden" id="sdt-quick-update-schema" value="0" />
						<input type="hidden" id="sdt-quick-update-robots" value="0" />
						<input type="hidden" id="sdt-quick-update-slug" value="0" />
						<input type="hidden" id="sdt-quick-update-excerpt" value="0" />
						<input type="hidden" id="sdt-quick-update-categories" value="0" />
						<input type="hidden" id="sdt-quick-update-tags" value="0" />
						<input type="hidden" id="sdt-quick-update-page-type" value="0" />
						<input type="hidden" id="sdt-quick-update-featured-image" value="0" />
						<input type="hidden" id="sdt-quick-update-content-images" value="0" />
						<input type="hidden" id="sdt-quick-update-featured-alt" value="0" />
						<input type="hidden" id="sdt-quick-update-image-content-alt" value="0" />
						<input type="hidden" id="sdt-quick-update-h1" value="0" />
						<input type="hidden" id="sdt-quick-update-h2" value="0" />
						<input type="hidden" id="sdt-quick-update-h3" value="0" />
						<input type="hidden" id="sdt-quick-update-h4" value="0" />
						<p id="sdt-quick-field-status" class="sdt-quick-field" hidden><label for="sdt-quick-post-status"><strong>Post Status</strong></label><br />
						<select id="sdt-quick-post-status">
							<option value="publish">publish</option>
							<option value="draft">draft</option>
							<option value="pending">pending</option>
							<option value="future">future</option>
							<option value="private">private</option>
						</select>
						<span class="description" id="sdt-quick-status-hint"></span></p>
						<p id="sdt-quick-field-title" class="sdt-quick-field"><label for="sdt-quick-post-title"><strong>Content Title</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-post-title" />
						<span class="description" id="sdt-quick-title-hint"></span></p>
						<p id="sdt-quick-field-robots" class="sdt-quick-field" hidden><label for="sdt-quick-robots"><strong>Robots</strong></label><br />
						<select id="sdt-quick-robots">
							<option value="">Default (empty)</option>
							<option value="index,follow">index,follow</option>
							<option value="noindex,follow">noindex,follow</option>
							<option value="index,nofollow">index,nofollow</option>
							<option value="noindex,nofollow">noindex,nofollow</option>
						</select>
						<span class="description" id="sdt-quick-robots-hint"></span></p>
						<p id="sdt-quick-field-meta" class="sdt-quick-field"><label for="sdt-quick-meta-desc"><strong>Meta Description</strong></label><br />
						<textarea class="large-text" rows="3" id="sdt-quick-meta-desc"></textarea>
						<span class="description" id="sdt-quick-meta-hint"></span></p>
						<p id="sdt-quick-field-schema" class="sdt-quick-field" hidden><label for="sdt-quick-schema"><strong>Schema JSON-LD</strong></label><br />
						<textarea class="large-text code" rows="7" id="sdt-quick-schema"></textarea>
						<span class="description" id="sdt-quick-schema-hint"></span></p>
						<p id="sdt-quick-field-slug" class="sdt-quick-field" hidden><label for="sdt-quick-slug"><strong>Slug</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-slug" />
						<span class="description" id="sdt-quick-slug-hint"></span></p>
						<p id="sdt-quick-field-excerpt" class="sdt-quick-field" hidden><label for="sdt-quick-excerpt"><strong>Excerpt</strong></label><br />
						<textarea class="large-text" rows="3" id="sdt-quick-excerpt"></textarea>
						<span class="description" id="sdt-quick-excerpt-hint"></span></p>
						<p id="sdt-quick-field-categories" class="sdt-quick-field" hidden><label for="sdt-quick-categories"><strong>Categories</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-categories" placeholder="Category A, Category B" />
						<span class="description" id="sdt-quick-categories-hint"></span></p>
						<p id="sdt-quick-field-tags" class="sdt-quick-field" hidden><label for="sdt-quick-tags"><strong>Tags</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-tags" placeholder="tag-one, tag-two" />
						<span class="description" id="sdt-quick-tags-hint"></span></p>
						<p id="sdt-quick-field-page-type" class="sdt-quick-field" hidden><label for="sdt-quick-page-type"><strong>Page Type</strong></label><br />
						<select id="sdt-quick-page-type">
							<option value="">Default (empty)</option>
							<option value="Glossary">Glossary</option>
							<option value="Pillar">Pillar</option>
							<option value="Hub">Hub</option>
							<option value="Section">Section</option>
						</select>
						<span class="description" id="sdt-quick-page-type-hint"></span></p>
						<p id="sdt-quick-field-featured-image" class="sdt-quick-field" hidden><label for="sdt-quick-featured-image-url"><strong>Featured Image</strong></label><br />
						<input type="hidden" id="sdt-quick-featured-image-id" value="0" />
						<input type="text" class="regular-text" id="sdt-quick-featured-image-url" readonly />
						<button type="button" class="button" id="sdt-quick-featured-image-pick">Select / Upload Featured Image</button>
						<button type="button" class="button" id="sdt-quick-featured-image-clear">Remove</button>
						<span class="description" id="sdt-quick-featured-image-hint"></span></p>
						<p id="sdt-quick-field-image-content-urls" class="sdt-quick-field" hidden><label><strong>Image Content URL(s)</strong></label><br />
						<input type="hidden" id="sdt-quick-content-images-json" value="[]" />
						<div id="sdt-quick-content-images-list" class="sdt-image-edit-list"></div>
						<span class="description" id="sdt-quick-content-images-hint"></span></p>
						<p id="sdt-quick-field-featured-alt" class="sdt-quick-field" hidden><label for="sdt-quick-featured-alt"><strong>Featured Image Alt Text</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-featured-alt" placeholder="Add featured image alt text" />
						<span class="description" id="sdt-quick-featured-alt-hint"></span></p>
						<p id="sdt-quick-field-image-content-alt" class="sdt-quick-field" hidden><label for="sdt-quick-image-content-alt"><strong>Image Content Alt (CSV)</strong></label><br />
						<input type="text" class="regular-text" id="sdt-quick-image-content-alt" placeholder='Example: yes,"Beach sunset",yes,"City skyline"' />
						<span class="description" id="sdt-quick-image-content-alt-hint"></span></p>
						<p id="sdt-quick-field-h1" class="sdt-quick-field" hidden><label><strong>H1 (showing all H1 in this blog/page)</strong></label><br />
						<div id="sdt-quick-h1-view" class="sdt-heading-preview"></div>
						<span class="description" id="sdt-quick-h1-hint"></span></p>
						<p id="sdt-quick-field-h2" class="sdt-quick-field" hidden><label for="sdt-quick-h2"><strong>H2 (one per line)</strong></label><br />
						<textarea class="large-text" rows="4" id="sdt-quick-h2"></textarea>
						<span class="description" id="sdt-quick-h2-hint"></span></p>
						<p id="sdt-quick-field-h3" class="sdt-quick-field" hidden><label for="sdt-quick-h3"><strong>H3 (one per line)</strong></label><br />
						<textarea class="large-text" rows="4" id="sdt-quick-h3"></textarea>
						<span class="description" id="sdt-quick-h3-hint"></span></p>
						<p id="sdt-quick-field-h4" class="sdt-quick-field" hidden><label for="sdt-quick-h4"><strong>H4 (one per line)</strong></label><br />
						<textarea class="large-text" rows="4" id="sdt-quick-h4"></textarea>
						<span class="description" id="sdt-quick-h4-hint"></span></p>
						<p class="sdt-quick-actions">
							<button type="submit" class="button button-primary" id="sdt-quick-save">Save</button>
							<button type="button" class="button" id="sdt-quick-cancel">Cancel</button>
						</p>
					</form>
				</section>
			</div>

			<div class="sdt-doc-modal" id="sdt-bulk-quick-modal" hidden>
				<div class="sdt-doc-backdrop" id="sdt-bulk-quick-backdrop"></div>
				<section class="sdt-card sdt-doc-panel sdt-quick-panel" role="dialog" aria-modal="true" aria-labelledby="sdt-bulk-quick-title">
					<div class="sdt-doc-head">
						<h2 id="sdt-bulk-quick-title">Bulk Quick Edit</h2>
						<button type="button" class="button-link" id="sdt-bulk-quick-close">Close</button>
					</div>
					<div id="sdt-bulk-quick-status" class="sdt-quick-status" aria-live="polite"></div>
					<p class="description" id="sdt-bulk-quick-summary">Select rows, then edit available fields per content item.</p>
					<form id="sdt-bulk-quick-form">
						<div id="sdt-bulk-quick-list"></div>
						<p class="sdt-quick-actions">
							<button type="submit" class="button button-primary" id="sdt-bulk-quick-save">Save All</button>
							<button type="button" class="button" id="sdt-bulk-quick-cancel">Cancel</button>
						</p>
					</form>
				</section>
			</div>

			<section class="sdt-card sdt-details" style="margin:16px 0;">
				<div class="sdt-functions-head">
					<h2>Function Details</h2>
					<button type="button" class="button sdt-guide-btn" id="sdt-doc-toggle" aria-expanded="false" aria-controls="sdt-doc-panel">Open Guide</button>
				</div>
				<form id="sdt-rule-form" class="sdt-rule-form">
					<input type="hidden" name="module" id="sdt-module" value="content_audit" />
					<div id="sdt-rule-panels"></div>
					<div class="sdt-actions">
						<button type="submit" class="button button-primary">Run Diagnostic</button>
						<button type="submit" class="button button-secondary" id="sdt-find-duplicates">Find Duplicates</button>
					</div>
				</form>
			</section>

			<section class="sdt-card sdt-results">
				<div class="sdt-results-head">
					<div>
						<h2>Results</h2>
						<p id="sdt-summary" class="sdt-summary">Run a diagnostic to see results.</p>
					</div>
					<form id="sdt-export-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
						<?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
						<input type="hidden" name="action" value="sdt_export" />
						<input type="hidden" name="module" id="sdt-export-module" value="" />
						<input type="hidden" name="rules_json" id="sdt-export-rules" value="" />
						<input type="hidden" name="selected_ids" id="sdt-export-selected-ids" value="" />
						<button type="button" class="button button-primary" id="sdt-bulk-quick-open">Bulk Quick Edit Selected</button>
						<select name="format" id="sdt-export-format">
							<option value="csv">CSV</option>
							<option value="xlsx">XLSX</option>
							<option value="docx">DOCX</option>
						</select>
						<button type="submit" class="button">Download</button>
					</form>
				</div>
				<div id="sdt-column-search" class="sdt-column-search" hidden>
					<strong id="sdt-column-search-label">Search in selected column</strong>
					<input type="search" id="sdt-column-search-input" placeholder="Type to filter this column..." />
					<button type="button" class="button button-small" id="sdt-column-search-clear">Clear</button>
				</div>
				<div class="sdt-table-wrap">
					<table class="widefat striped" id="sdt-result-table">
						<thead>
							<tr id="sdt-result-head-row"></tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
				<div class="sdt-pagination" id="sdt-pagination"></div>
			</section>
		</div>
		<?php
	}

	public static function ajaxRunScan(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		check_ajax_referer('sdt_run_scan', 'nonce');

		$module = isset($_POST['module']) ? sanitize_key((string) wp_unslash($_POST['module'])) : '';
		$rules = [];
		if (!empty($_POST['rules'])) {
			$raw = wp_unslash($_POST['rules']);
			$decoded = json_decode((string) $raw, true);
			if (is_array($decoded)) {
				$rules = $decoded;
			}
		}

		$result = ScanService::run($module, $rules);
		wp_send_json_success($result);
	}

	public static function ajaxQuickEditGet(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}
		check_ajax_referer('sdt_quick_edit', 'nonce');

		$postId = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
		$post = $postId > 0 ? get_post($postId) : null;
		if (!$post instanceof \WP_Post) {
			wp_send_json_error(['message' => 'Post not found.'], 404);
		}
		if (!current_user_can('edit_post', $postId)) {
			wp_send_json_error(['message' => 'You do not have permission to edit this post.'], 403);
		}

		$metaDesc = trim((string) get_post_meta($postId, 'vite_meta_description', true));

		wp_send_json_success([
			'post_title' => (string) $post->post_title,
			'seo_title' => trim((string) get_post_meta($postId, 'vite_seo_title', true)),
			'meta_description' => $metaDesc,
			'post_status' => (string) $post->post_status,
			'schema_json' => trim((string) get_post_meta($postId, 'vite_schema_jsonld', true)),
			'robots' => trim((string) get_post_meta($postId, 'vite_meta_robots', true)),
			'slug' => (string) $post->post_name,
			'excerpt' => (string) $post->post_excerpt,
			'categories' => self::terms_to_csv($postId, 'category'),
			'tags' => self::terms_to_csv($postId, 'post_tag'),
			'page_type' => trim((string) get_post_meta($postId, 'vite_page_type', true)),
			'featured_image' => self::featured_image_payload($postId),
			'content_images' => self::content_images_payload($post),
			'featured_alt_text' => self::featured_image_alt_text($postId),
			'image_content_alt_text' => self::content_image_alt_quick_string($post),
			'h1_lines' => self::heading_editor_payload($post, 1),
			'h2_lines' => self::heading_editor_payload($post, 2),
			'h3_lines' => self::heading_editor_payload($post, 3),
			'h4_lines' => self::heading_editor_payload($post, 4),
		]);
	}

	public static function ajaxQuickEditSave(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}
		check_ajax_referer('sdt_quick_edit', 'nonce');

		$postId = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
		$post = $postId > 0 ? get_post($postId) : null;
		if (!$post instanceof \WP_Post) {
			wp_send_json_error(['message' => 'Post not found.'], 404);
		}
		if (!current_user_can('edit_post', $postId)) {
			wp_send_json_error(['message' => 'You do not have permission to edit this post.'], 403);
		}

		$updateTitle = !empty($_POST['update_title']);
		$updateSeoTitle = !empty($_POST['update_seo_title']);
		$updateMeta = !empty($_POST['update_meta_description']);
		$updateStatus = !empty($_POST['update_status']);
		$updateSchema = !empty($_POST['update_schema']);
		$updateRobots = !empty($_POST['update_robots']);
		$updateSlug = !empty($_POST['update_slug']);
		$updateExcerpt = !empty($_POST['update_excerpt']);
		$updateCategories = !empty($_POST['update_categories']);
		$updateTags = !empty($_POST['update_tags']);
		$updatePageType = !empty($_POST['update_page_type']);
		$updateFeaturedImage = !empty($_POST['update_featured_image']);
		$updateContentImages = !empty($_POST['update_content_images']);
		$updateFeaturedAlt = !empty($_POST['update_featured_alt']);
		$updateImageContentAlt = !empty($_POST['update_image_content_alt']);
		$updateH1 = !empty($_POST['update_h1']);
		$updateH2 = !empty($_POST['update_h2']);
		$updateH3 = !empty($_POST['update_h3']);
		$updateH4 = !empty($_POST['update_h4']);
		$newTitle = isset($_POST['post_title']) ? sanitize_text_field((string) wp_unslash($_POST['post_title'])) : '';
		$newSeoTitle = isset($_POST['seo_title']) ? sanitize_text_field((string) wp_unslash($_POST['seo_title'])) : $newTitle;
		$newMeta = isset($_POST['meta_description']) ? sanitize_textarea_field((string) wp_unslash($_POST['meta_description'])) : '';
		$newStatus = isset($_POST['post_status']) ? sanitize_key((string) wp_unslash($_POST['post_status'])) : '';
		$newSchema = isset($_POST['schema_json']) ? trim((string) wp_unslash($_POST['schema_json'])) : '';
		$newRobots = isset($_POST['robots']) ? sanitize_text_field((string) wp_unslash($_POST['robots'])) : '';
		$newSlug = isset($_POST['slug']) ? sanitize_title((string) wp_unslash($_POST['slug'])) : '';
		$newExcerpt = isset($_POST['excerpt']) ? sanitize_textarea_field((string) wp_unslash($_POST['excerpt'])) : '';
		$newCategories = isset($_POST['categories']) ? self::parse_term_list((string) wp_unslash($_POST['categories'])) : [];
		$newTags = isset($_POST['tags']) ? self::parse_term_list((string) wp_unslash($_POST['tags'])) : [];
		$newPageType = isset($_POST['page_type']) ? sanitize_text_field((string) wp_unslash($_POST['page_type'])) : '';
		$newFeaturedImageId = isset($_POST['featured_image_id']) ? (int) $_POST['featured_image_id'] : 0;
		$newContentImagesJson = isset($_POST['content_images_json']) ? (string) wp_unslash($_POST['content_images_json']) : '';
		$newContentImageReplacements = self::parse_content_image_replacements($newContentImagesJson);
		$newFeaturedAlt = isset($_POST['featured_alt_text']) ? sanitize_text_field((string) wp_unslash($_POST['featured_alt_text'])) : '';
		$newImageContentAlt = isset($_POST['image_content_alt_text']) ? (string) wp_unslash($_POST['image_content_alt_text']) : '';
		$newH1Lines = isset($_POST['h1_lines']) ? self::parse_heading_lines((string) wp_unslash($_POST['h1_lines'])) : [];
		$newH2Lines = isset($_POST['h2_lines']) ? self::parse_heading_lines((string) wp_unslash($_POST['h2_lines'])) : [];
		$newH3Lines = isset($_POST['h3_lines']) ? self::parse_heading_lines((string) wp_unslash($_POST['h3_lines'])) : [];
		$newH4Lines = isset($_POST['h4_lines']) ? self::parse_heading_lines((string) wp_unslash($_POST['h4_lines'])) : [];

		if ($updateTitle) {
			$postUpdate = [
				'ID' => $postId,
				'post_title' => $newTitle,
			];
			$result = wp_update_post($postUpdate, true);
			if (is_wp_error($result)) {
				wp_send_json_error(['message' => 'Could not update title: ' . $result->get_error_message()], 500);
			}
		}

		if ($updateSeoTitle) {
			if ($newSeoTitle === '') {
				delete_post_meta($postId, 'vite_seo_title');
			} else {
				update_post_meta($postId, 'vite_seo_title', $newSeoTitle);
			}
		}

		if ($updateMeta) {
			if ($newMeta === '') {
				delete_post_meta($postId, 'vite_meta_description');
			} else {
				update_post_meta($postId, 'vite_meta_description', $newMeta);
			}
		}

		if ($updateStatus) {
			$allowedStatuses = ScanService::baseStatuses();
			if (!in_array($newStatus, $allowedStatuses, true)) {
				wp_send_json_error(['message' => 'Invalid status value.'], 400);
			}
			$result = wp_update_post([
				'ID' => $postId,
				'post_status' => $newStatus,
			], true);
			if (is_wp_error($result)) {
				wp_send_json_error(['message' => 'Could not update status: ' . $result->get_error_message()], 500);
			}
		}

		if ($updateSchema) {
			if ($newSchema === '') {
				delete_post_meta($postId, 'vite_schema_jsonld');
			} else {
				$decoded = json_decode($newSchema, true);
				if (!is_array($decoded)) {
					wp_send_json_error(['message' => 'Schema JSON is invalid. Please check quotes, commas, and brackets.'], 400);
				}
				update_post_meta($postId, 'vite_schema_jsonld', wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
			}
		}

		if ($updateRobots) {
			$allowed = ['index,follow', 'noindex,follow', 'index,nofollow', 'noindex,nofollow', ''];
			if (!in_array($newRobots, $allowed, true)) {
				wp_send_json_error(['message' => 'Invalid robots value.'], 400);
			}
			if ($newRobots === '') {
				delete_post_meta($postId, 'vite_meta_robots');
			} else {
				update_post_meta($postId, 'vite_meta_robots', $newRobots);
			}
		}

		if ($updateSlug) {
			$result = wp_update_post([
				'ID' => $postId,
				'post_name' => $newSlug,
			], true);
			if (is_wp_error($result)) {
				wp_send_json_error(['message' => 'Could not update slug: ' . $result->get_error_message()], 500);
			}
		}

		if ($updateExcerpt) {
			$result = wp_update_post([
				'ID' => $postId,
				'post_excerpt' => $newExcerpt,
			], true);
			if (is_wp_error($result)) {
				wp_send_json_error(['message' => 'Could not update excerpt: ' . $result->get_error_message()], 500);
			}
		}

		if ($updateCategories) {
			$catIds = self::upsert_category_ids($newCategories);
			wp_set_post_terms($postId, $catIds, 'category', false);
		}

		if ($updateTags) {
			wp_set_post_terms($postId, $newTags, 'post_tag', false);
		}

		if ($updatePageType) {
			if ($newPageType === '') {
				delete_post_meta($postId, 'vite_page_type');
			} else {
				update_post_meta($postId, 'vite_page_type', $newPageType);
			}
		}
		if ($updateFeaturedImage) {
			self::update_featured_image_attachment($postId, $newFeaturedImageId);
		}
		if ($updateContentImages) {
			self::update_content_image_sources($postId, $post, $newContentImageReplacements);
		}

		if ($updateFeaturedAlt) {
			self::update_featured_image_alt_text($postId, $newFeaturedAlt);
		}

		if ($updateImageContentAlt) {
			self::update_content_image_alt_text($post, $newImageContentAlt);
		}

		if ($updateH1 || $updateH2 || $updateH3 || $updateH4) {
			self::apply_heading_updates($postId, $post, [
				'h1' => $updateH1 ? $newH1Lines : null,
				'h2' => $updateH2 ? $newH2Lines : null,
				'h3' => $updateH3 ? $newH3Lines : null,
				'h4' => $updateH4 ? $newH4Lines : null,
			]);
		}

		wp_send_json_success(['message' => 'Saved successfully.']);
	}

	public static function ajaxBulkQuickGet(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}
		check_ajax_referer('sdt_quick_edit', 'nonce');

		$rawIds = isset($_POST['post_ids']) ? (string) wp_unslash($_POST['post_ids']) : '';
		$postIds = array_values(array_unique(array_filter(array_map('intval', explode(',', $rawIds)))));
		if (!$postIds) {
			wp_send_json_error(['message' => 'No posts selected.'], 400);
		}

		$rows = [];
		foreach ($postIds as $postId) {
			$post = get_post($postId);
			if (!$post instanceof \WP_Post) {
				continue;
			}
			if (!current_user_can('edit_post', $postId)) {
				continue;
			}

			$metaDesc = trim((string) get_post_meta($postId, 'vite_meta_description', true));

			$rows[] = [
				'post_id' => $postId,
				'post_title' => (string) $post->post_title,
				'seo_title' => trim((string) get_post_meta($postId, 'vite_seo_title', true)),
				'meta_description' => $metaDesc,
				'post_status' => (string) $post->post_status,
				'schema_json' => trim((string) get_post_meta($postId, 'vite_schema_jsonld', true)),
				'robots' => trim((string) get_post_meta($postId, 'vite_meta_robots', true)),
				'slug' => (string) $post->post_name,
				'excerpt' => (string) $post->post_excerpt,
				'categories' => self::terms_to_csv($postId, 'category'),
				'tags' => self::terms_to_csv($postId, 'post_tag'),
				'page_type' => trim((string) get_post_meta($postId, 'vite_page_type', true)),
				'featured_alt_text' => self::featured_image_alt_text($postId),
				'image_content_alt_text' => self::content_image_alt_quick_string($post),
				'h1_lines' => self::heading_editor_payload($post, 1),
				'h2_lines' => self::heading_editor_payload($post, 2),
				'h3_lines' => self::heading_editor_payload($post, 3),
				'h4_lines' => self::heading_editor_payload($post, 4),
			];
		}

		if (!$rows) {
			wp_send_json_error(['message' => 'No editable posts found in selection.'], 400);
		}

		wp_send_json_success(['rows' => $rows]);
	}

	public static function ajaxBulkQuickSave(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}
		check_ajax_referer('sdt_quick_edit', 'nonce');

		$rowsJson = isset($_POST['rows_json']) ? (string) wp_unslash($_POST['rows_json']) : '';
		if ($rowsJson === '') {
			wp_send_json_error(['message' => 'No rows submitted.'], 400);
		}
		$rows = json_decode($rowsJson, true);
		if (!is_array($rows) || !$rows) {
			wp_send_json_error(['message' => 'Invalid bulk payload.'], 400);
		}

		$allowedStatuses = ScanService::baseStatuses();
		$updated = 0;
		foreach ($rows as $row) {
			if (!is_array($row)) {
				continue;
			}
			$postId = isset($row['post_id']) ? (int) $row['post_id'] : 0;
			$post = $postId > 0 ? get_post($postId) : null;
			if (!$post instanceof \WP_Post) {
				continue;
			}
			if (!current_user_can('edit_post', $postId)) {
				continue;
			}

			$updateTitle = !empty($row['update_title']);
			$updateSeoTitle = !empty($row['update_seo_title']);
			$updateMeta = !empty($row['update_meta_description']);
			$updateStatus = !empty($row['update_status']);
			$updateSchema = !empty($row['update_schema']);
			$updateRobots = !empty($row['update_robots']);
			$updateSlug = !empty($row['update_slug']);
			$updateExcerpt = !empty($row['update_excerpt']);
			$updateCategories = !empty($row['update_categories']);
			$updateTags = !empty($row['update_tags']);
			$updatePageType = !empty($row['update_page_type']);
			$updateFeaturedAlt = !empty($row['update_featured_alt']);
			$updateImageContentAlt = !empty($row['update_image_content_alt']);
			$updateH1 = !empty($row['update_h1']);
			$updateH2 = !empty($row['update_h2']);
			$updateH3 = !empty($row['update_h3']);
			$updateH4 = !empty($row['update_h4']);
			$newTitle = isset($row['post_title']) ? sanitize_text_field((string) $row['post_title']) : '';
			$newSeoTitle = isset($row['seo_title']) ? sanitize_text_field((string) $row['seo_title']) : '';
			$newMeta = isset($row['meta_description']) ? sanitize_textarea_field((string) $row['meta_description']) : '';
			$newStatus = isset($row['post_status']) ? sanitize_key((string) $row['post_status']) : '';
			$newSchema = isset($row['schema_json']) ? trim((string) $row['schema_json']) : '';
			$newRobots = isset($row['robots']) ? sanitize_text_field((string) $row['robots']) : '';
			$newSlug = isset($row['slug']) ? sanitize_title((string) $row['slug']) : '';
			$newExcerpt = isset($row['excerpt']) ? sanitize_textarea_field((string) $row['excerpt']) : '';
			$newCategories = isset($row['categories']) ? self::parse_term_list((string) $row['categories']) : [];
			$newTags = isset($row['tags']) ? self::parse_term_list((string) $row['tags']) : [];
			$newPageType = isset($row['page_type']) ? sanitize_text_field((string) $row['page_type']) : '';
			$newFeaturedAlt = isset($row['featured_alt_text']) ? sanitize_text_field((string) $row['featured_alt_text']) : '';
			$newImageContentAlt = isset($row['image_content_alt_text']) ? (string) $row['image_content_alt_text'] : '';
			$newH1Lines = isset($row['h1_lines']) ? self::parse_heading_lines((string) $row['h1_lines']) : [];
			$newH2Lines = isset($row['h2_lines']) ? self::parse_heading_lines((string) $row['h2_lines']) : [];
			$newH3Lines = isset($row['h3_lines']) ? self::parse_heading_lines((string) $row['h3_lines']) : [];
			$newH4Lines = isset($row['h4_lines']) ? self::parse_heading_lines((string) $row['h4_lines']) : [];

			if ($updateTitle) {
				$result = wp_update_post([
					'ID' => $postId,
					'post_title' => $newTitle,
				], true);
				if (is_wp_error($result)) {
					continue;
				}
			}

			if ($updateMeta) {
				if ($newMeta === '') {
					delete_post_meta($postId, 'vite_meta_description');
				} else {
					update_post_meta($postId, 'vite_meta_description', $newMeta);
				}
			}

			if ($updateSeoTitle) {
				if ($newSeoTitle === '') {
					delete_post_meta($postId, 'vite_seo_title');
				} else {
					update_post_meta($postId, 'vite_seo_title', $newSeoTitle);
				}
			}

			if ($updateStatus) {
				if (!in_array($newStatus, $allowedStatuses, true)) {
					continue;
				}
				$result = wp_update_post([
					'ID' => $postId,
					'post_status' => $newStatus,
				], true);
				if (is_wp_error($result)) {
					continue;
				}
			}

			if ($updateSchema) {
				if ($newSchema === '') {
					delete_post_meta($postId, 'vite_schema_jsonld');
				} else {
					$decoded = json_decode($newSchema, true);
					if (!is_array($decoded)) {
						continue;
					}
					update_post_meta($postId, 'vite_schema_jsonld', wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
				}
			}

			if ($updateRobots) {
				$allowedRobots = ['index,follow', 'noindex,follow', 'index,nofollow', 'noindex,nofollow', ''];
				if (!in_array($newRobots, $allowedRobots, true)) {
					continue;
				}
				if ($newRobots === '') {
					delete_post_meta($postId, 'vite_meta_robots');
				} else {
					update_post_meta($postId, 'vite_meta_robots', $newRobots);
				}
			}

			if ($updateSlug) {
				$result = wp_update_post([
					'ID' => $postId,
					'post_name' => $newSlug,
				], true);
				if (is_wp_error($result)) {
					continue;
				}
			}

			if ($updateExcerpt) {
				$result = wp_update_post([
					'ID' => $postId,
					'post_excerpt' => $newExcerpt,
				], true);
				if (is_wp_error($result)) {
					continue;
				}
			}

			if ($updateCategories) {
				$catIds = self::upsert_category_ids($newCategories);
				wp_set_post_terms($postId, $catIds, 'category', false);
			}

			if ($updateTags) {
				wp_set_post_terms($postId, $newTags, 'post_tag', false);
			}

			if ($updatePageType) {
				if ($newPageType === '') {
					delete_post_meta($postId, 'vite_page_type');
				} else {
					update_post_meta($postId, 'vite_page_type', $newPageType);
				}
			}

			if ($updateFeaturedAlt) {
				self::update_featured_image_alt_text($postId, $newFeaturedAlt);
			}

			if ($updateImageContentAlt) {
				self::update_content_image_alt_text($post, $newImageContentAlt);
			}

			if ($updateH1 || $updateH2 || $updateH3 || $updateH4) {
				self::apply_heading_updates($postId, $post, [
					'h1' => $updateH1 ? $newH1Lines : null,
					'h2' => $updateH2 ? $newH2Lines : null,
					'h3' => $updateH3 ? $newH3Lines : null,
					'h4' => $updateH4 ? $newH4Lines : null,
				]);
			}

			$updated++;
		}

		if ($updated < 1) {
			wp_send_json_error(['message' => 'No rows were saved. Please check your selected module fields.'], 400);
		}
		wp_send_json_success(['message' => 'Saved successfully.', 'updated_count' => $updated]);
	}

	private static function parse_term_list(string $raw): array
	{
		if ($raw === '') {
			return [];
		}
		$parts = preg_split('/[,;\n\r]+/', $raw);
		if (!is_array($parts)) {
			return [];
		}
		$terms = [];
		foreach ($parts as $part) {
			$clean = trim(sanitize_text_field((string) $part));
			if ($clean !== '') {
				$terms[] = $clean;
			}
		}
		return array_values(array_unique($terms));
	}

	private static function parse_heading_lines(string $raw): array
	{
		$parts = preg_split('/\r\n|\r|\n/', $raw);
		if (!is_array($parts)) {
			return [];
		}
		$out = [];
		foreach ($parts as $line) {
			$line = trim(sanitize_text_field((string) $line));
			if ($line !== '') {
				$out[] = $line;
			}
		}
		return array_values($out);
	}

	private static function upsert_category_ids(array $names): array
	{
		$ids = [];
		foreach ($names as $name) {
			$name = trim((string) $name);
			if ($name === '') {
				continue;
			}
			$existing = term_exists($name, 'category');
			if (is_array($existing) && isset($existing['term_id'])) {
				$ids[] = (int) $existing['term_id'];
				continue;
			}
			if (is_int($existing)) {
				$ids[] = (int) $existing;
				continue;
			}
			$created = wp_insert_term($name, 'category');
			if (!is_wp_error($created) && is_array($created) && isset($created['term_id'])) {
				$ids[] = (int) $created['term_id'];
			}
		}
		return array_values(array_unique(array_filter($ids)));
	}

	private static function terms_to_csv(int $postId, string $taxonomy): string
	{
		$names = wp_get_post_terms($postId, $taxonomy, ['fields' => 'names']);
		if (is_wp_error($names) || !is_array($names) || !$names) {
			return '';
		}
		return implode(', ', array_map('strval', $names));
	}

	private static function heading_editor_payload(\WP_Post $post, int $level): string
	{
		$content = (string) $post->post_content;
		$items = [];
		if ($level === 1 && trim((string) $post->post_title) !== '') {
			$items[] = (string) $post->post_title;
		}
		if (preg_match_all('/<h' . $level . '\b[^>]*>(.*?)<\/h' . $level . '>/is', $content, $m)) {
			foreach ((array) $m[1] as $raw) {
				$text = trim(wp_strip_all_tags((string) html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
				if ($text !== '') {
					$items[] = $text;
				}
			}
		}
		return implode("\n", $items);
	}

	private static function apply_heading_updates(int $postId, \WP_Post $post, array $updates): void
	{
		$content = (string) $post->post_content;
		$newTitle = null;
		$oldTitle = trim((string) $post->post_title);
		$oldContentH1 = self::extract_heading_lines_from_content($content, 1);

		$h1Lines = $updates['h1'] ?? null;
		if (is_array($h1Lines)) {
			if (!empty($h1Lines)) {
				$candidateTitle = (string) $h1Lines[0];
				$candidateContent = array_slice($h1Lines, 1);
				$removedTitleMode = false;
				// If the first line now matches old first content H1, user likely removed title line.
				if (
					$oldTitle !== ''
					&& !empty($oldContentH1)
					&& self::heading_lines_match([$candidateTitle], [(string) $oldContentH1[0]])
					&& self::heading_lines_match($candidateContent, array_slice($oldContentH1, 1))
				) {
					$removedTitleMode = true;
				}
				if ($removedTitleMode) {
					$newTitle = '';
					$contentH1 = $h1Lines;
				} else {
					$newTitle = $candidateTitle;
					$contentH1 = $candidateContent;
				}
			} else {
				$newTitle = '';
				$contentH1 = [];
			}
			$content = self::replace_heading_tags($content, 1, $contentH1);
		}

		foreach ([2, 3, 4] as $level) {
			$key = 'h' . $level;
			$lines = $updates[$key] ?? null;
			if (is_array($lines)) {
				$content = self::replace_heading_tags($content, $level, $lines);
			}
		}

		$postUpdate = ['ID' => $postId];
		$shouldUpdate = false;
		if ($newTitle !== null) {
			$postUpdate['post_title'] = $newTitle;
			$shouldUpdate = true;
		}
		if ($content !== (string) $post->post_content) {
			$postUpdate['post_content'] = $content;
			$shouldUpdate = true;
		}
		if ($shouldUpdate) {
			wp_update_post($postUpdate);
		}
	}

	private static function replace_heading_tags(string $content, int $level, array $values): string
	{
		if ($content === '') {
			return $content;
		}
		$pattern = '/<h' . $level . '\b[^>]*>.*?<\/h' . $level . '>/is';
		$existingTexts = [];
		if (preg_match_all('/<h' . $level . '\b[^>]*>(.*?)<\/h' . $level . '>/is', $content, $existingMatches)) {
			foreach ((array) ($existingMatches[1] ?? []) as $raw) {
				$existingTexts[] = trim(wp_strip_all_tags((string) html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
			}
		}
		$values = array_map(static fn($v) => trim((string) $v), array_values($values));
		$oldCount = count($existingTexts);
		$newCount = count($values);
		// If user removed first heading(s), keep the remaining headings in their original lower positions.
		if ($newCount > 0 && $oldCount > $newCount) {
			$oldTail = array_slice($existingTexts, -$newCount);
			if (self::heading_lines_match($values, $oldTail)) {
				$values = array_merge(array_fill(0, $oldCount - $newCount, ''), $values);
			}
		}
		$idx = 0;
		$total = count($values);
		$updated = preg_replace_callback($pattern, static function (array $match) use (&$idx, $values, $level, $total) {
			if ($idx >= $total) {
				// Remove leftover heading tags when user cleared lines.
				return '';
			}
			$text = trim((string) $values[$idx]);
			$idx++;
			if ($text === '') {
				return '';
			}
			return '<h' . $level . '>' . esc_html($text) . '</h' . $level . '>';
		}, $content);
		if (!is_string($updated)) {
			$updated = $content;
		}
		if ($idx < $total) {
			$append = [];
			for ($i = $idx; $i < $total; $i++) {
				$text = trim((string) $values[$i]);
				if ($text === '') {
					continue;
				}
				$append[] = '<h' . $level . '>' . esc_html($text) . '</h' . $level . '>';
			}
			if (!empty($append)) {
				$updated .= "\n\n" . implode("\n", $append);
			}
		}
		return $updated;
	}

	private static function extract_heading_lines_from_content(string $content, int $level): array
	{
		$out = [];
		if ($content === '') {
			return $out;
		}
		if (preg_match_all('/<h' . $level . '\b[^>]*>(.*?)<\/h' . $level . '>/is', $content, $m)) {
			foreach ((array) ($m[1] ?? []) as $raw) {
				$text = trim(wp_strip_all_tags((string) html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
				if ($text !== '') {
					$out[] = $text;
				}
			}
		}
		return $out;
	}

	private static function heading_lines_match(array $a, array $b): bool
	{
		if (count($a) !== count($b)) {
			return false;
		}
		$total = count($a);
		for ($i = 0; $i < $total; $i++) {
			$left = preg_replace('/\s+/u', ' ', trim((string) $a[$i]));
			$right = preg_replace('/\s+/u', ' ', trim((string) $b[$i]));
			$left = function_exists('mb_strtolower') ? mb_strtolower((string) $left, 'UTF-8') : strtolower((string) $left);
			$right = function_exists('mb_strtolower') ? mb_strtolower((string) $right, 'UTF-8') : strtolower((string) $right);
			if ($left !== $right) {
				return false;
			}
		}
		return true;
	}

	private static function featured_image_alt_text(int $postId): string
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return '';
		}
		return trim((string) get_post_meta($thumbId, '_wp_attachment_image_alt', true));
	}

	private static function update_featured_image_alt_text(int $postId, string $alt): void
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return;
		}
		$alt = trim($alt);
		if ($alt === '') {
			delete_post_meta($thumbId, '_wp_attachment_image_alt');
			return;
		}
		update_post_meta($thumbId, '_wp_attachment_image_alt', $alt);
	}

	private static function featured_image_payload(int $postId): array
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return [
				'id' => 0,
				'url' => '',
			];
		}
		$url = wp_get_attachment_url($thumbId);
		return [
			'id' => $thumbId,
			'url' => $url ? (string) $url : '',
		];
	}

	private static function content_images_payload(\WP_Post $post): array
	{
		$items = [];
		$images = self::extract_content_images($post);
		foreach ($images as $idx => $image) {
			$id = isset($image['id']) ? (int) $image['id'] : 0;
			$src = isset($image['src']) ? trim((string) $image['src']) : '';
			if ($src === '' && $id > 0) {
				$url = wp_get_attachment_url($id);
				$src = $url ? (string) $url : '';
			}
			$items[] = [
				'index' => (int) $idx,
				'id' => $id,
				'url' => $src,
			];
		}
		return $items;
	}

	private static function update_featured_image_attachment(int $postId, int $attachmentId): void
	{
		if ($attachmentId < 1) {
			delete_post_thumbnail($postId);
			return;
		}
		$attachment = get_post($attachmentId);
		if (!$attachment instanceof \WP_Post || $attachment->post_type !== 'attachment') {
			return;
		}
		set_post_thumbnail($postId, $attachmentId);
	}

	private static function parse_content_image_replacements(string $rawJson): array
	{
		$rawJson = trim($rawJson);
		if ($rawJson === '') {
			return [];
		}
		$decoded = json_decode($rawJson, true);
		if (!is_array($decoded)) {
			return [];
		}
		$out = [];
		foreach ($decoded as $entry) {
			if (!is_array($entry)) {
				continue;
			}
			$index = isset($entry['index']) ? (int) $entry['index'] : -1;
			if ($index < 0) {
				continue;
			}
			$remove = !empty($entry['remove']);
			if ($remove) {
				$out[$index] = [
					'remove' => true,
					'id' => 0,
					'url' => '',
				];
				continue;
			}
			$id = isset($entry['id']) ? (int) $entry['id'] : 0;
			$url = isset($entry['url']) ? esc_url_raw((string) $entry['url']) : '';
			if ($url === '' && $id > 0) {
				$attachmentUrl = wp_get_attachment_url($id);
				$url = $attachmentUrl ? esc_url_raw((string) $attachmentUrl) : '';
			}
			if ($url === '') {
				continue;
			}
			$out[$index] = [
				'remove' => false,
				'id' => $id > 0 ? $id : 0,
				'url' => $url,
			];
		}
		return $out;
	}

	private static function update_content_image_sources(int $postId, \WP_Post $post, array $replacements): void
	{
		if (!$replacements) {
			return;
		}
		$content = (string) $post->post_content;
		if ($content === '') {
			return;
		}
		$idx = -1;
		$updated = preg_replace_callback('/<img\b[^>]*>/i', static function (array $m) use (&$idx, $replacements): string {
			$idx++;
			if (!isset($replacements[$idx])) {
				return (string) ($m[0] ?? '');
			}
			$entry = $replacements[$idx];
			$remove = !empty($entry['remove']);
			if ($remove) {
				return '';
			}
			$url = isset($entry['url']) ? trim((string) $entry['url']) : '';
			if ($url === '') {
				return (string) ($m[0] ?? '');
			}
			$id = isset($entry['id']) ? (int) $entry['id'] : 0;
			return self::replace_img_tag_source_and_class((string) ($m[0] ?? ''), $url, $id);
		}, $content);
		if (!is_string($updated) || $updated === $content) {
			return;
		}
		$result = wp_update_post([
			'ID' => $postId,
			'post_content' => $updated,
		], true);
		if (is_wp_error($result)) {
			return;
		}
	}

	private static function replace_img_tag_source_and_class(string $imgTag, string $url, int $attachmentId): string
	{
		$url = esc_url_raw($url);
		if ($url === '') {
			return $imgTag;
		}
		$quote = '"';
		if (preg_match('/\ssrc=(["\'])(.*?)\1/i', $imgTag, $srcMatch)) {
			$quote = (string) ($srcMatch[1] ?? '"');
			$imgTag = preg_replace('/\ssrc=(["\'])(.*?)\1/i', ' src=' . $quote . esc_attr($url) . $quote, $imgTag, 1) ?: $imgTag;
		} else {
			$imgTag = preg_replace('/\s*\/?>\s*$/', ' src="' . esc_attr($url) . '"$0', $imgTag, 1) ?: $imgTag;
		}
		if ($attachmentId > 0) {
			if (preg_match('/\sclass=(["\'])(.*?)\1/i', $imgTag, $classMatch)) {
				$classQuote = (string) ($classMatch[1] ?? '"');
				$classValue = (string) ($classMatch[2] ?? '');
				$classValue = preg_replace('/\bwp-image-\d+\b/', '', $classValue);
				$classValue = trim(preg_replace('/\s+/', ' ', (string) $classValue));
				$classValue = trim($classValue . ' wp-image-' . $attachmentId);
				$imgTag = preg_replace('/\sclass=(["\'])(.*?)\1/i', ' class=' . $classQuote . esc_attr($classValue) . $classQuote, $imgTag, 1) ?: $imgTag;
			} else {
				$imgTag = preg_replace('/\s*\/?>\s*$/', ' class="wp-image-' . $attachmentId . '"$0', $imgTag, 1) ?: $imgTag;
			}
		}
		return $imgTag;
	}

	private static function content_image_alt_quick_string(\WP_Post $post): string
	{
		$images = self::extract_content_images($post);
		if (!$images) {
			return '';
		}
		$tokens = [];
		foreach ($images as $image) {
			$tokens[] = !empty($image['has_alt']) ? 'yes' : '';
		}
		$escaped = [];
		foreach ($tokens as $token) {
			$token = (string) $token;
			if ($token === '') {
				$escaped[] = '""';
				continue;
			}
			if (strpos($token, ',') !== false || strpos($token, '"') !== false) {
				$escaped[] = '"' . str_replace('"', '""', $token) . '"';
				continue;
			}
			$escaped[] = $token;
		}
		return implode(',', $escaped);
	}

	private static function update_content_image_alt_text(\WP_Post $post, string $rawCsv): void
	{
		$images = self::extract_content_images($post);
		if (!$images) {
			return;
		}
		if (trim($rawCsv) === '') {
			foreach ($images as $image) {
				$attachmentId = isset($image['id']) ? (int) $image['id'] : 0;
				if ($attachmentId > 0) {
					delete_post_meta($attachmentId, '_wp_attachment_image_alt');
				}
			}
			return;
		}
		$tokens = str_getcsv((string) $rawCsv, ',', '"', '\\');
		if (!is_array($tokens) || !$tokens) {
			return;
		}
		foreach ($images as $index => $image) {
			$attachmentId = isset($image['id']) ? (int) $image['id'] : 0;
			if ($attachmentId < 1) {
				continue;
			}
			if (!array_key_exists($index, $tokens)) {
				continue;
			}
			$token = trim((string) $tokens[$index]);
			$tokenLower = function_exists('mb_strtolower') ? mb_strtolower($token, 'UTF-8') : strtolower($token);
			if ($token === '' || in_array($tokenLower, ['yes', 'no', 'n/a'], true)) {
				if ($token === '') {
					delete_post_meta($attachmentId, '_wp_attachment_image_alt');
				}
				continue;
			}
			update_post_meta($attachmentId, '_wp_attachment_image_alt', sanitize_text_field($token));
		}
	}

	private static function extract_content_images(\WP_Post $post): array
	{
		$content = (string) $post->post_content;
		if ($content === '') {
			return [];
		}
		$images = [];
		if (!preg_match_all('/<img\b[^>]*>/i', $content, $tags) || empty($tags[0])) {
			return [];
		}
		foreach ((array) $tags[0] as $tag) {
			$attachmentId = 0;
			$tagAlt = '';
			$src = '';
			if (preg_match('/\ssrc=(["\'])(.*?)\1/i', $tag, $srcMatch)) {
				$src = trim((string) $srcMatch[2]);
			}
			if (preg_match('/\sclass=(["\'])(.*?)\1/i', $tag, $classMatch)) {
				if (preg_match('/wp-image-([0-9]+)/', (string) $classMatch[2], $idMatch)) {
					$attachmentId = (int) $idMatch[1];
				}
			}
			if ($attachmentId < 1 && $src !== '') {
				if ($src !== '') {
					$attachmentId = (int) attachment_url_to_postid($src);
				}
			}
			if (preg_match('/\salt=(["\'])(.*?)\1/i', $tag, $altMatch)) {
				$tagAlt = trim((string) $altMatch[2]);
			}
			$metaAlt = '';
			if ($attachmentId > 0) {
				$metaAlt = trim((string) get_post_meta($attachmentId, '_wp_attachment_image_alt', true));
			}
			$hasAlt = ($tagAlt !== '' || $metaAlt !== '');
			if ($src === '' && $attachmentId > 0) {
				$attachmentUrl = wp_get_attachment_url($attachmentId);
				$src = $attachmentUrl ? (string) $attachmentUrl : '';
			}
			$images[] = [
				'id' => $attachmentId,
				'src' => $src,
				'has_alt' => $hasAlt,
			];
		}
		return $images;
	}

	public static function handleExport(): void
	{
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden');
		}

		check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

		$module = isset($_POST['module']) ? sanitize_key((string) wp_unslash($_POST['module'])) : '';
		$format = isset($_POST['format']) ? sanitize_key((string) wp_unslash($_POST['format'])) : 'csv';
		$selectedIdsRaw = isset($_POST['selected_ids']) ? (string) wp_unslash($_POST['selected_ids']) : '';
		$rules = [];
		if (!empty($_POST['rules_json'])) {
			$decoded = json_decode((string) wp_unslash($_POST['rules_json']), true);
			if (is_array($decoded)) {
				$rules = $decoded;
			}
		}

		$result = ScanService::run($module, $rules);
		$rows = isset($result['rows']) && is_array($result['rows']) ? $result['rows'] : [];
		$selectedIds = array_values(array_unique(array_filter(array_map('intval', explode(',', $selectedIdsRaw)))));
		if (!$selectedIds) {
			wp_die('Please select at least one content row from the results table before downloading.');
		}
		$selectedMap = array_fill_keys(array_map('strval', $selectedIds), true);
		$rows = array_values(array_filter($rows, static function ($row) use ($selectedMap): bool {
			$contentId = isset($row['content_id']) ? (int) $row['content_id'] : 0;
			if ($contentId <= 0) {
				return false;
			}
			return isset($selectedMap[(string) $contentId]);
		}));
		if (!$rows) {
			wp_die('No matching selected rows were found for export. Please run the diagnostic again and select rows.');
		}

		ExportService::download($format, $module, $rows);
	}

	private static function moduleLabels(): array
	{
		return [
			'content_audit' => 'Content Audit',
		];
	}

	private static function scanMonthOptions(): array
	{
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT DISTINCT DATE_FORMAT(post_date, '%Y-%m') AS ym
			 FROM {$wpdb->posts}
			 WHERE post_type IN ('post','page')
			 AND post_status NOT IN ('auto-draft','trash','inherit')
			 ORDER BY ym DESC
			 LIMIT 60",
			ARRAY_A
		);
		$out = [];
		if (is_array($rows)) {
			foreach ($rows as $row) {
				$ym = isset($row['ym']) ? (string) $row['ym'] : '';
				if ($ym !== '' && preg_match('/^\d{4}-\d{2}$/', $ym)) {
					$out[] = $ym;
				}
			}
		}
		return $out;
	}

	private static function scanCounts(): array
	{
		$post = new \WP_Query([
			'post_type' => 'post',
			'post_status' => ScanService::baseStatuses(),
			'posts_per_page' => 1,
			'fields' => 'ids',
			'no_found_rows' => false,
			'ignore_sticky_posts' => true,
		]);
		$page = new \WP_Query([
			'post_type' => 'page',
			'post_status' => ScanService::baseStatuses(),
			'posts_per_page' => 1,
			'fields' => 'ids',
			'no_found_rows' => false,
			'ignore_sticky_posts' => true,
		]);

		return [
			'post' => max(0, (int) $post->found_posts),
			'page' => max(0, (int) $page->found_posts),
		];
	}

	private static function scanMonthCounts(): array
	{
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT DATE_FORMAT(post_date, '%Y-%m') AS ym, post_type, COUNT(*) AS total
			 FROM {$wpdb->posts}
			 WHERE post_type IN ('post','page')
			 AND post_status NOT IN ('auto-draft','trash','inherit')
			 GROUP BY ym, post_type",
			ARRAY_A
		);
		$out = [];
		if (!is_array($rows)) {
			return $out;
		}
		foreach ($rows as $row) {
			$ym = isset($row['ym']) ? (string) $row['ym'] : '';
			$type = isset($row['post_type']) ? (string) $row['post_type'] : '';
			$total = isset($row['total']) ? (int) $row['total'] : 0;
			if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
				continue;
			}
			if (!in_array($type, ['post', 'page'], true)) {
				continue;
			}
			if (!isset($out[$ym])) {
				$out[$ym] = ['post' => 0, 'page' => 0];
			}
			$out[$ym][$type] = max(0, $total);
		}
		return $out;
	}

	private static function adminCss(): string
	{
		return <<<'CSS'
.sdt-wrap {
  max-width: 100%;
}
.sdt-wrap, .sdt-wrap * { box-sizing: border-box; }
.sdt-page-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 6px; }
.sdt-page-head h1 { margin-bottom: 0; }
.sdt-functions-head { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom: 10px; }
.sdt-functions-head h2 { margin: 0; }
.sdt-guide-btn { background: #ffcc00 !important; border-color: #d6a800 !important; color: #1d2327 !important; }
.sdt-guide-btn:hover,
.sdt-guide-btn:focus { background: #f0bf00 !important; border-color: #bf9600 !important; color: #1d2327 !important; }
.sdt-doc-modal { position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; padding: 20px; }
.sdt-doc-modal[hidden] { display: none !important; }
.sdt-doc-backdrop { position: absolute; inset: 0; background: rgba(15, 23, 42, 0.55); }
.sdt-doc-panel { position: relative; width: min(900px, calc(100vw - 40px)); max-height: calc(100vh - 60px); overflow: auto; margin: 0; z-index: 1; border: 1px solid #d4dcec; box-shadow: 0 20px 50px rgba(15, 23, 42, 0.25); }
.sdt-doc-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; position: sticky; top: 0; background: #fff; padding-bottom: 10px; border-bottom: 1px solid #e5eaf3; }
.sdt-quick-panel { width: min(980px, calc(100vw - 40px)); }
.sdt-quick-actions { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
.sdt-bulk-list { display:grid; grid-template-columns:1fr; gap:10px; margin:8px 0 12px; }
.sdt-bulk-item { border:1px solid #dbe3f2; border-radius:8px; background:#fff; padding:10px; }
.sdt-bulk-item h3 { margin:0 0 8px; font-size:14px; line-height:1.4; color:#0f3f77; }
.sdt-quick-field[hidden] { display: none !important; }
.sdt-quick-field .description { margin: 4px 0 0; color: #4b5563; }
.sdt-image-edit-list { display: grid; grid-template-columns: 1fr; gap: 8px; margin-top: 8px; }
.sdt-image-edit-row { border: 1px solid #dbe3f2; border-radius: 8px; background: #fff; padding: 8px; }
.sdt-image-edit-row__label { font-weight: 600; margin-bottom: 6px; color: #0f3f77; }
.sdt-image-edit-row__actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-top: 6px; }
.sdt-image-edit-row input.regular-text { width: min(100%, 640px); }
.sdt-input-valid { border-color: #16a34a !important; box-shadow: 0 0 0 1px #16a34a !important; }
.sdt-input-invalid { border-color: #dc2626 !important; box-shadow: 0 0 0 1px #dc2626 !important; }
.sdt-quick-status { margin: 0 0 10px; padding: 8px 10px; border-radius: 6px; background: #f6f7f7; color: #1d2327; display: none; }
.sdt-quick-status.is-info,
.sdt-quick-status.is-success,
.sdt-quick-status.is-error { display: block; }
.sdt-quick-status.is-info { background: #eef4ff; color: #1e3a8a; }
.sdt-quick-status.is-success { background: #edfaef; color: #0f6f2e; }
.sdt-quick-status.is-error { background: #fdecec; color: #9f2626; }
.sdt-grid-top { display: grid; grid-template-columns: 1fr; gap: 16px; margin: 16px 0; }
.sdt-card { background: linear-gradient(180deg, #ffffff 0%, #fbfcff 100%); border: 1px solid #d9e1f2; border-radius: 12px; padding: 16px; box-shadow: 0 8px 20px rgba(15, 23, 42, 0.06); }
.sdt-module-list { margin: 0; padding: 0; list-style: none; }
.sdt-module-item { padding: 10px 12px; border: 1px solid #d9e1f2; border-radius: 8px; margin-bottom: 8px; cursor: pointer; transition: all 0.18s ease; }
.sdt-module-item.is-active { border-color: #2b67c6; background: #eef4ff; font-weight: 600; color: #0f3f77; }
.sdt-field { margin-bottom: 12px; padding: 10px; border: 1px dashed #e0e6f2; border-radius: 8px; background: #fff; }
.sdt-field label { display: block; margin-bottom: 4px; font-weight: 600; color: #23324f; }
.sdt-field input[type="number"] { width: 240px; }
.sdt-checkbox-group { display: flex; gap: 12px; flex-wrap: wrap; }
.sdt-inline-label { display: inline-flex !important; gap: 4px; align-items: center; font-weight: 400 !important; }
.sdt-results-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 12px; margin-bottom: 10px; }
.sdt-summary { margin: 4px 0 0; color: #334155; font-weight: 500; }
.sdt-column-search { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin:0 0 10px; padding:8px 10px; border:1px dashed #c7d2fe; border-radius:8px; background:#eef4ff; }
.sdt-column-search input[type="search"] { min-width:280px; }
.sdt-table-wrap { overflow-x: auto; border: 1px solid #dbe3f2; border-radius: 10px; background: #fff; }
#sdt-result-table th { background: #0f3f77; color: #fff; }
#sdt-result-table th.sdt-col-head-searchable { cursor: pointer; user-select: none; }
#sdt-result-table th.sdt-col-head-searchable.is-active { background: #1d4f91; box-shadow: inset 0 -3px 0 rgba(255,255,255,0.32); }
#sdt-result-table .sdt-expandable { display:inline-flex; align-items:center; gap:6px; max-width: 100%; cursor: pointer; }
#sdt-result-table .sdt-expandable__value { display:inline-block; max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; vertical-align: bottom; }
#sdt-result-table .sdt-expandable.is-expanded .sdt-expandable__value { max-width: 720px; }
#sdt-result-table .sdt-code-block {
  margin: 0;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre;
  overflow-x: auto;
  overflow-y: hidden;
  word-break: normal;
  overflow-wrap: normal;
  background: #f6f8fc;
  border: 1px solid #dbe3f2;
  border-radius: 6px;
  padding: 8px;
}
#sdt-result-table[data-active-field="schema_json_ld"] th[data-search-field="schema_json_ld"],
#sdt-result-table[data-active-field="schema_json_ld"] td[data-field="schema_json_ld"] {
  min-width: 560px;
  vertical-align: top;
}
#sdt-result-table tr:nth-child(even) td { background: #f8fbff; }
#sdt-result-table tr.sdt-row-critical td:first-child { border-left: 4px solid #dc2626; }
#sdt-result-table tr.sdt-row-warning td:first-child { border-left: 4px solid #f59e0b; }
#sdt-result-table tr.sdt-row-info td:first-child { border-left: 4px solid #2563eb; }
.sdt-link-na { color: #6b7280; font-size: 12px; }
.sdt-heading-preview {
  border: 1px solid #dbe3f2;
  background: #f8fbff;
  border-radius: 6px;
  padding: 8px;
  max-height: 180px;
  overflow: auto;
  font-size: 12px;
  line-height: 1.45;
}
.sdt-heading-preview__line { display: block; padding: 2px 0; color: #1f2937; }
.sdt-heading-preview__line.is-dup { color: #b91c1c; font-weight: 600; }
.sdt-pagination { margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
@media (max-width: 980px) { .sdt-grid-top { grid-template-columns: 1fr; } }
CSS;
	}

	private static function adminJs(): string
	{
		return <<<'JS'
(function () {
  var scanCounts = (typeof SDT_DATA !== "undefined" && SDT_DATA.scanCounts) ? SDT_DATA.scanCounts : { post: 0, page: 0 };
  var monthCounts = (typeof SDT_DATA !== "undefined" && SDT_DATA.monthCounts) ? SDT_DATA.monthCounts : {};
  function monthOptions() {
    var options = [{ value: "", label: "All months" }];
    (SDT_DATA.monthOptions || []).forEach(function (ym) {
      options.push({ value: ym, label: ym });
    });
    return options;
  }
  function selectedFieldDefaults() {
    return [];
  }
  function commonScanFields() {
    return [
      { key: "content_scope", type: "radio_group", label: "Content Type", options: [{ value: "all", label: "Posts + Pages" }, { value: "post", label: "Posts only" }, { value: "page", label: "Pages only" }], value: "all" },
      { key: "scan_mode", type: "radio_group", label: "Scan Mode", options: [{ value: "all", label: "All content" }, { value: "phase", label: "By phase" }], value: "all" },
      { key: "phase_size", type: "number", label: "Items per phase", value: 100, min: 1, max: 1000, phaseOnly: true },
      { key: "phase_number", type: "select", label: "Phase", options: [{ value: "1", label: "Phase 1" }], value: "1", phaseOnly: true },
      { key: "year_month", type: "select", label: "Created Month", options: monthOptions(), value: "" },
    ];
  }
  var moduleConfig = {
    content_audit: { label: "Content Audit", fields: commonScanFields().concat([
      { key: "_select_all_fields", type: "button", label: "Fields to show in table", text: "Check all fields" },
      { key: "fields", type: "checkbox_group", label: "Headers", options: [
        "seo_title","seo_meta_description","h1","h2","h3","h4","slug","excerpt",
        "categories","tags","page_type","featured_image","featured_image_size_kb","featured_alt",
        "image_content_urls","image_content_sizes_kb","image_content_alt","inbound","outbound","schema_json_ld","robots"
      ], value: selectedFieldDefaults() }
    ]) },
  };
  var currentModule = "content_audit", currentRules = {}, currentRows = [], currentColumns = [], pageSize = 50, currentPage = 1;
  var activeColumnSearchField = "", activeColumnSearchTerm = "";
  var selectedContentIds = new Set();
  var expandedColumns = {};
  function esc(text) { return String(text || "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;"); }
  function severityClass(issue) { var value = String(issue || "").toLowerCase(); if (!value) return "sdt-row-info"; if (value.indexOf("broken") !== -1 || value.indexOf("missing") !== -1 || value.indexOf("noindex") !== -1 || value.indexOf("duplicate") !== -1) return "sdt-row-critical"; if (value.indexOf("length") !== -1 || value.indexOf("jump") !== -1 || value.indexOf("disallowed") !== -1 || value.indexOf("too large") !== -1) return "sdt-row-warning"; return "sdt-row-info"; }
  function actionLink(url) { if (!url) return ""; return '<a class="sdt-link-btn" href="' + esc(url) + '" target="_blank" rel="noopener">Open</a>'; }
  function contentIdNumber(row) { var n = parseInt((row && row.content_id) || 0, 10); return (isFinite(n) && n > 0) ? n : 0; }
  function contentTypeKey(row) { return String((row && row.content_type) || "").toLowerCase(); }
  function quickEditLink(row) {
    var id = contentIdNumber(row);
    if (!id || contentTypeKey(row) !== "post") return '<span class="sdt-link-na">N/A</span>';
    return '<button type="button" class="button-link sdt-quick-edit-btn" data-post-id="' + id + '" data-issue="' + esc(row.issue_type) + '" data-module="' + esc(currentModule) + '">Quick Edit</button>';
  }
  function moduleFieldFlags(moduleKey) {
    var module = String(moduleKey || "").toLowerCase();
    if (module === "content_audit") {
      var selected = Array.isArray(currentColumns) && currentColumns.length ? currentColumns : columnsFromRules();
      var has = function (key) { return selected.indexOf(key) !== -1; };
      return {
        title: has("seo_title"),
        meta: has("seo_meta_description"),
        h1: has("h1"),
        h2: has("h2"),
        h3: has("h3"),
        h4: has("h4"),
        status: false,
        schema: has("schema_json_ld"),
        robots: has("robots"),
        slug: has("slug"),
        excerpt: has("excerpt"),
        categories: has("categories"),
        tags: has("tags"),
        pageType: has("page_type"),
        featuredImage: has("featured_image") || has("featured_image_size_kb") || has("featured_alt"),
        imageContentUrls: has("image_content_urls") || has("image_content_sizes_kb") || has("image_content_alt"),
        featuredAlt: has("featured_alt"),
        imageContentAlt: has("image_content_alt")
      };
    }
    if (module === "heading_structure") return { title: true, meta: false, h1: true, h2: true, h3: true, h4: true, status: false, schema: false, robots: false, slug: false, excerpt: false, categories: false, tags: false, pageType: false, featuredImage: false, imageContentUrls: false, featuredAlt: false, imageContentAlt: false };
    if (module === "indexability_checks") return { title: false, meta: false, h1: false, h2: false, h3: false, h4: false, status: true, schema: false, robots: false, slug: false, excerpt: false, categories: false, tags: false, pageType: false, featuredImage: false, imageContentUrls: false, featuredAlt: false, imageContentAlt: false };
    return { title: false, meta: false, h1: false, h2: false, h3: false, h4: false, status: false, schema: false, robots: false, slug: false, excerpt: false, categories: false, tags: false, pageType: false, featuredImage: false, imageContentUrls: false, featuredAlt: false, imageContentAlt: false };
  }
  function fullEditLink(row) {
    var id = contentIdNumber(row);
    if (!id) return actionLink(row.post_link);
    var url = (SDT_DATA.adminRoot || "/wp-admin/") + "post.php?post=" + id + "&action=edit";
    return '<a class="sdt-link-btn" href="' + esc(url) + '" target="_blank" rel="noopener">Edit</a>';
  }
  function viewLink(row) {
    var url = String((row && row.post_link) || "");
    if (!url) return '<span class="sdt-link-na">N/A</span>';
    return '<a class="sdt-link-btn" href="' + esc(url) + '" target="_blank" rel="noopener">View</a>';
  }
  function renderModuleList() {
    var list = document.getElementById("sdt-module-list");
    if (!list) return;
    list.innerHTML = "";
    Object.keys(moduleConfig).forEach(function (key) {
      var li = document.createElement("li");
      li.className = "sdt-module-item" + (key === currentModule ? " is-active" : "");
      li.setAttribute("data-module", key);
      li.textContent = moduleConfig[key].label;
      li.addEventListener("click", function () { currentModule = key; document.getElementById("sdt-module").value = key; renderModuleList(); renderRuleFields(); });
      list.appendChild(li);
    });
  }
  function renderRuleFields() {
    var panel = document.getElementById("sdt-rule-panels"), config = moduleConfig[currentModule];
    panel.innerHTML = "";
    function prettyFieldLabel(value) {
      var map = {
        post_link: "Post Link",
        seo_title: "SEO Title",
        seo_meta_description: "SEO Meta Description",
        h1: "H1",
        h2: "H2",
        h3: "H3",
        h4: "H4",
        slug: "Slug",
        excerpt: "Excerpt",
        categories: "Categories",
        tags: "Tags",
        page_type: "Page Type",
        featured_image: "Featured Image",
        featured_image_size_kb: "Featured Image Size (KB)",
        featured_alt: "Featured Alt",
        image_content_urls: "Image Content URL(s)",
        image_content_sizes_kb: "Image Content Size(s) (KB)",
        image_content_alt: "Image Content Alt",
        inbound: "Inbound",
        outbound: "Outbound",
        schema_json_ld: "Schema JSON-LD",
        robots: "Robots",
        duplicate_reason: "Duplicate Details"
      };
      return map[value] || String(value || "");
    }
    config.fields.forEach(function (field) {
      var row = document.createElement("div"); row.className = "sdt-field";
      var label = document.createElement("label"); label.textContent = field.label; row.appendChild(label);
      if (field.type === "number") { var input = document.createElement("input"); input.type = "number"; input.name = field.key; input.value = field.value; if (field.min !== undefined) input.min = field.min; if (field.max !== undefined) input.max = field.max; row.appendChild(input); }
      else if (field.type === "select") { var select = document.createElement("select"); select.name = field.key; (field.options || []).forEach(function (opt) { var option = document.createElement("option"); if (typeof opt === "string") { option.value = opt; option.textContent = opt; } else { option.value = opt.value; option.textContent = opt.label; } if (String(option.value) === String(field.value)) option.selected = true; select.appendChild(option); }); row.appendChild(select); }
      else if (field.type === "checkbox") { var checkbox = document.createElement("input"); checkbox.type = "checkbox"; checkbox.name = field.key; checkbox.checked = !!field.value; row.appendChild(checkbox); }
      else if (field.type === "checkbox_group") { var wrap = document.createElement("div"); wrap.className = "sdt-checkbox-group"; field.options.forEach(function (opt) { var holder = document.createElement("label"); holder.className = "sdt-inline-label"; var cb = document.createElement("input"); cb.type = "checkbox"; cb.name = field.key + "[]"; cb.value = opt; cb.checked = (field.value || []).indexOf(opt) !== -1; holder.appendChild(cb); holder.appendChild(document.createTextNode(" " + prettyFieldLabel(opt))); wrap.appendChild(holder); }); row.appendChild(wrap); }
      else if (field.type === "radio_group") { var radioWrap = document.createElement("div"); radioWrap.className = "sdt-checkbox-group"; (field.options || []).forEach(function (opt) { var value = (typeof opt === "string") ? opt : opt.value; var text = (typeof opt === "string") ? opt : opt.label; var radioLabel = document.createElement("label"); radioLabel.className = "sdt-inline-label"; var radio = document.createElement("input"); radio.type = "radio"; radio.name = field.key; radio.value = value; radio.checked = String(field.value) === String(value); radioLabel.appendChild(radio); radioLabel.appendChild(document.createTextNode(" " + text)); radioWrap.appendChild(radioLabel); }); row.appendChild(radioWrap); }
      else if (field.type === "button") { var action = document.createElement("button"); action.type = "button"; action.className = "button button-secondary"; action.textContent = field.text || "Action"; action.addEventListener("click", function () { panel.querySelectorAll('input[name="fields[]"]').forEach(function (cb) { cb.checked = true; }); }); row.appendChild(action); }
      else if (field.type === "required_info") { var req = document.createElement("p"); req.className = "description"; req.textContent = field.text || "Required"; row.appendChild(req); }
      if (field.phaseOnly) row.setAttribute("data-phase-only", "1");
      panel.appendChild(row);
    });
    bindRulesDynamic();
    updatePhaseControls();
  }
  function getScopeTotal(scope, yearMonth) {
    var source = scanCounts;
    if (yearMonth && monthCounts && monthCounts[yearMonth]) {
      source = monthCounts[yearMonth];
    }
    if (scope === "post") return parseInt(source.post || 0, 10) || 0;
    if (scope === "page") return parseInt(source.page || 0, 10) || 0;
    return (parseInt(source.post || 0, 10) || 0) + (parseInt(source.page || 0, 10) || 0);
  }
  function updatePhaseControls() {
    var form = document.getElementById("sdt-rule-form");
    if (!form) return;
    var modeEl = form.querySelector('input[name="scan_mode"]:checked');
    var scopeEl = form.querySelector('input[name="content_scope"]:checked');
    var monthEl = form.querySelector('select[name="year_month"]');
    var phaseSizeEl = form.querySelector('input[name="phase_size"]');
    var phaseNumberEl = form.querySelector('select[name="phase_number"]');
    var mode = modeEl ? modeEl.value : "all";
    var scope = scopeEl ? scopeEl.value : "all";
    var yearMonth = monthEl ? String(monthEl.value || "") : "";
    var phaseSize = phaseSizeEl ? (parseInt(phaseSizeEl.value, 10) || 100) : 100;
    if (phaseSize < 1) phaseSize = 1;
    var total = getScopeTotal(scope, yearMonth);
    var phaseCount = Math.max(1, Math.ceil(total / phaseSize));

    form.querySelectorAll('[data-phase-only="1"]').forEach(function (row) {
      row.style.display = mode === "phase" ? "" : "none";
    });

    if (phaseNumberEl) {
      var current = parseInt(phaseNumberEl.value, 10) || 1;
      phaseNumberEl.innerHTML = "";
      for (var i = 1; i <= phaseCount; i++) {
        var option = document.createElement("option");
        option.value = String(i);
        var start = ((i - 1) * phaseSize) + 1;
        var end = Math.min(i * phaseSize, total);
        option.textContent = total > 0 ? ("Phase " + i + " (" + start + "-" + end + ")") : ("Phase " + i);
        if (i === current) option.selected = true;
        phaseNumberEl.appendChild(option);
      }
      if (current > phaseCount) {
        phaseNumberEl.value = String(phaseCount);
      }
    }
  }
  function bindRulesDynamic() {
    var form = document.getElementById("sdt-rule-form");
    if (!form) return;
    form.querySelectorAll('input[name="scan_mode"], input[name="content_scope"], input[name="phase_size"], select[name="year_month"]').forEach(function (el) {
      el.addEventListener("change", updatePhaseControls);
      el.addEventListener("input", updatePhaseControls);
    });
  }
  function collectRules() {
    var form = document.getElementById("sdt-rule-form"), fd = new FormData(form), out = {};
    fd.forEach(function (value, key) { if (key.slice(-2) === "[]") { var realKey = key.slice(0, -2); if (!Array.isArray(out[realKey])) out[realKey] = []; out[realKey].push(value); return; } out[key] = value; });
    var checkboxes = form.querySelectorAll("input[type=checkbox][name]:not([name$='[]'])");
    checkboxes.forEach(function (cb) { out[cb.name] = cb.checked; });
    ["scan_limit", "max_image_kb", "title_min", "title_max", "meta_desc_min", "meta_desc_max", "phase_size", "phase_number"].forEach(function (num) { if (out[num] !== undefined) out[num] = parseInt(out[num], 10) || 0; });
    return out;
  }
  function setSummary(total, issues, passRate) { document.getElementById("sdt-summary").textContent = "Scanned: " + total + " | Issues: " + issues + " | Pass rate: " + passRate + "%"; }
  function rerunCurrentScan(resetState) {
    var body = new URLSearchParams();
    body.set("action", "sdt_run_scan");
    body.set("nonce", SDT_DATA.runScanNonce);
    body.set("module", currentModule);
    body.set("rules", JSON.stringify(currentRules || {}));
    return fetch(SDT_DATA.ajaxUrl, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" }, body: body.toString() })
      .then(function (res) { return res.json(); })
      .then(function (json) {
        if (!json || !json.success) throw new Error((json && json.data && json.data.message) || "Scan failed");
        var data = json.data || {};
        currentRows = Array.isArray(data.rows) ? data.rows : [];
        currentColumns = Array.isArray(data.columns) ? data.columns : columnsFromRules();
        if (resetState) {
          currentPage = 1;
          selectedContentIds = new Set();
          activeColumnSearchField = "";
          activeColumnSearchTerm = "";
          expandedColumns = {};
        }
        setSummary(data.total_scanned || 0, data.issue_count || 0, data.pass_rate || 0);
        renderTablePage();
        return data;
      });
  }
  function columnsFromRules() {
    var selected = Array.isArray(currentRules.fields) ? currentRules.fields : [];
    if (!selected.length) return ["post_link"];
    return ["post_link"].concat(selected.filter(function (x) { return x !== "post_link"; }));
  }
  function prettyColumn(value) {
    var map = {
      post_link: "Post Link",
      seo_title: "SEO Title",
      seo_meta_description: "SEO Meta Description",
      h1: "H1",
      h2: "H2",
      h3: "H3",
      h4: "H4",
      slug: "Slug",
      excerpt: "Excerpt",
      categories: "Categories",
      tags: "Tags",
      page_type: "Page Type",
      featured_image: "Featured Image",
      featured_image_size_kb: "Featured Image Size (KB)",
      featured_alt: "Featured Alt",
      image_content_urls: "Image Content URL(s)",
      image_content_sizes_kb: "Image Content Size(s) (KB)",
      image_content_alt: "Image Content Alt",
      inbound: "Inbound",
      outbound: "Outbound",
      schema_json_ld: "Schema JSON-LD",
      robots: "Robots",
      duplicate_reason: "Duplicate Details"
    };
    return map[value] || String(value || "");
  }
  function normalizedFieldValue(field, value) {
    if (value === null || value === undefined) return "";
    var text = String(value);
    if (field === "schema_json_ld") text = text.replace(/\s+/g, " ").trim();
    return text.toLowerCase();
  }
  function getFilteredRows() {
    var source = Array.isArray(currentRows) ? currentRows : [];
    var field = String(activeColumnSearchField || "");
    var term = String(activeColumnSearchTerm || "").trim().toLowerCase();
    if (!field || !term) return source;
    return source.filter(function (row) {
      return normalizedFieldValue(field, row ? row[field] : "").indexOf(term) !== -1;
    });
  }
  function updateColumnSearchUI() {
    var wrap = document.getElementById("sdt-column-search");
    var label = document.getElementById("sdt-column-search-label");
    var input = document.getElementById("sdt-column-search-input");
    if (!wrap || !label || !input) return;
    if (!activeColumnSearchField) {
      wrap.hidden = true;
      input.value = "";
      return;
    }
    wrap.hidden = false;
    label.textContent = "Search in " + prettyColumn(activeColumnSearchField);
    if (input.value !== activeColumnSearchTerm) input.value = activeColumnSearchTerm;
  }
  function bindColumnHeaderSearch() {
    var input = document.getElementById("sdt-column-search-input");
    var clear = document.getElementById("sdt-column-search-clear");
    if (input && !input.dataset.bound) {
      input.dataset.bound = "1";
      input.addEventListener("input", function () {
        activeColumnSearchTerm = String(input.value || "");
        currentPage = 1;
        renderTablePage();
      });
    }
    if (clear && !clear.dataset.bound) {
      clear.dataset.bound = "1";
      clear.addEventListener("click", function () {
        activeColumnSearchField = "";
        activeColumnSearchTerm = "";
        currentPage = 1;
        updateColumnSearchUI();
        renderTablePage();
      });
    }
    Array.prototype.slice.call(document.querySelectorAll("#sdt-result-head-row th[data-search-field]")).forEach(function (th) {
      th.onclick = function () {
        var field = String(th.getAttribute("data-search-field") || "");
        if (!field) return;
        if (activeColumnSearchField !== field) {
          activeColumnSearchField = field;
          activeColumnSearchTerm = "";
        }
        currentPage = 1;
        updateColumnSearchUI();
        renderTablePage();
        var i = document.getElementById("sdt-column-search-input");
        if (i) i.focus();
      };
    });
  }
  function cellHtml(field, value) {
    var text = String(value || "");
    var columnExpanded = !!(expandedColumns[field] || activeColumnSearchField === field);
    var lines;
    if (field === "schema_json_ld") {
      if (columnExpanded) {
        var prettySchema = text.trim();
        if (prettySchema) {
          try { prettySchema = JSON.stringify(JSON.parse(prettySchema), null, 2); } catch (e) {}
        }
        lines = prettySchema ? [prettySchema] : [];
      } else {
        var compact = text.replace(/\s+/g, " ").trim();
        lines = compact ? [compact] : [];
      }
    } else {
      lines = text.split("\n").filter(function (x) { return x !== ""; });
    }
    if (!lines.length) return '<span class="sdt-link-na">N/A</span>';
    function lineLimit() {
      if (columnExpanded) return 100000;
      if (field === "duplicate_reason") return 180;
      if (field === "schema_json_ld") return 80;
      if (field === "image_content_sizes_kb" || field === "featured_image_size_kb") return 16;
      return 10;
    }
    function expandableText(line) {
      var str = String(line || "");
      var limit = lineLimit();
      if (str.length <= limit) {
        return '<span class="sdt-expandable__value">' + esc(str) + "</span>";
      }
      var short = str.slice(0, limit) + "...";
      return '<span class="sdt-expandable" data-short="' + esc(short) + '" data-full="' + esc(str) + '">'
        + '<span class="sdt-expandable__value">' + esc(short) + "</span>"
        + "</span>";
    }
    function shortLine(line) {
      var str = String(line || "");
      var limit = lineLimit();
      return str.length > limit ? (str.slice(0, limit) + "...") : str;
    }
    if (field === "post_link" || field === "featured_image" || field === "inbound" || field === "outbound" || field === "image_content_urls") {
      return lines.map(function (line) {
        return '<a class="sdt-link-btn" href="' + esc(line) + '" target="_blank" rel="noopener">' + esc(shortLine(line)) + '</a>';
      }).join("<br />");
    }
    if (field === "featured_image_size_kb" || field === "image_content_sizes_kb") {
      return lines.map(function (line) {
        var num = parseFloat(line);
        var warn = isFinite(num) && num >= 150;
        var style = warn ? (field === "featured_image_size_kb" ? ' style="background:#fee2e2;color:#b91c1c;font-weight:600;padding:2px 4px;border-radius:4px;display:inline-block;"' : ' style="color:#b91c1c;font-weight:600;"') : '';
        return '<span' + style + '>' + expandableText(line) + '</span>';
      }).join("<br />");
    }
    if (field === "featured_alt" || field === "image_content_alt") {
      return lines.map(function (line) {
        var warn = String(line).toLowerCase() === "no";
        var style = warn ? (field === "featured_alt" ? ' style="background:#fee2e2;color:#b91c1c;font-weight:600;padding:2px 4px;border-radius:4px;display:inline-block;"' : ' style="color:#b91c1c;font-weight:600;"') : '';
        return '<span' + style + '>' + expandableText(line) + '</span>';
      }).join("<br />");
    }
    if (field === "h1" || field === "h2" || field === "h3" || field === "h4") {
      return lines.map(function (line) {
        var isDup = String(line).indexOf("__DUP__") === 0;
        var clean = isDup ? String(line).replace("__DUP__", "") : String(line);
        var style = isDup ? ' style="background:#fee2e2;color:#b91c1c;font-weight:600;padding:2px 4px;border-radius:4px;display:inline-block;"' : '';
        return '<span' + style + '>' + expandableText(clean) + '</span>';
      }).join("<br />");
    }
    if (field === "schema_json_ld" && columnExpanded) {
      return '<pre class="sdt-code-block">' + esc(lines[0]) + "</pre>";
    }
    return lines.map(function (line) { return expandableText(line); }).join("<br />");
  }
  function renderDynamicHeader() {
    var headRow = document.getElementById("sdt-result-head-row");
    if (!headRow) return;
    var table = document.getElementById("sdt-result-table");
    if (table) table.setAttribute("data-active-field", String(activeColumnSearchField || ""));
    var cols = Array.isArray(currentColumns) && currentColumns.length ? currentColumns : columnsFromRules();
    headRow.innerHTML = '<th style="width:36px;"><input type="checkbox" id="sdt-select-all" aria-label="Select all rows" /></th>'
      + '<th>Content ID</th>'
      + cols.map(function (field) {
        var cls = "sdt-col-head sdt-col-head-searchable" + (activeColumnSearchField === field ? " is-active" : "");
        return '<th class="' + cls + '" data-search-field="' + esc(field) + '" title="Click to search this column">' + esc(prettyColumn(field)) + "</th>";
      }).join("")
      + '<th>Quick Edit</th><th>Edit</th><th>View</th>';
    bindResultSelection();
    bindColumnHeaderSearch();
    updateColumnSearchUI();
  }
  function selectionKey(row) {
    var id = parseInt((row && row.content_id) || 0, 10);
    return (isFinite(id) && id > 0) ? String(id) : "";
  }
  function syncSelectAllCheckbox() {
    var selectAll = document.getElementById("sdt-select-all");
    var rowChecks = Array.prototype.slice.call(document.querySelectorAll(".sdt-row-select"));
    if (!selectAll) return;
    if (!rowChecks.length) {
      selectAll.checked = false;
      selectAll.indeterminate = false;
      return;
    }
    var checkedCount = rowChecks.filter(function (cb) { return cb.checked; }).length;
    selectAll.checked = checkedCount === rowChecks.length;
    selectAll.indeterminate = checkedCount > 0 && checkedCount < rowChecks.length;
  }
  function bindResultSelection() {
    var selectAll = document.getElementById("sdt-select-all");
    var tbody = document.querySelector("#sdt-result-table tbody");
    if (selectAll) {
      selectAll.onchange = function () {
        var rowChecks = Array.prototype.slice.call(document.querySelectorAll(".sdt-row-select"));
        rowChecks.forEach(function (cb) {
          cb.checked = selectAll.checked;
          if (cb.checked) selectedContentIds.add(String(cb.value)); else selectedContentIds.delete(String(cb.value));
        });
        syncSelectAllCheckbox();
      };
    }
    if (tbody) {
      tbody.onchange = function (event) {
        var cb = event.target;
        if (!cb || !cb.classList || !cb.classList.contains("sdt-row-select")) return;
        var key = String(cb.value || "");
        if (cb.checked) selectedContentIds.add(key); else selectedContentIds.delete(key);
        Array.prototype.slice.call(document.querySelectorAll(".sdt-row-select")).forEach(function (other) {
          if (String(other.value || "") === key) other.checked = cb.checked;
        });
        syncSelectAllCheckbox();
      };
    }
    syncSelectAllCheckbox();
  }
  function bindExpandableCells() {
    var tbody = document.querySelector("#sdt-result-table tbody");
    if (!tbody || tbody.dataset.expandBound) return;
    tbody.dataset.expandBound = "1";
    tbody.addEventListener("click", function (event) {
      var directAction = event.target && event.target.closest ? event.target.closest("a, button, input, textarea, select, label") : null;
      // Never block normal link/button/input behavior inside table cells.
      if (directAction && !directAction.classList.contains("sdt-expandable")) return;
      var target = event.target && event.target.closest ? event.target.closest(".sdt-expandable, td[data-field]") : null;
      if (!target) return;
      var cell = target.matches("td[data-field]") ? target : (target.closest ? target.closest("td[data-field]") : null);
      if (!cell) return;
      var field = String(cell.getAttribute("data-field") || "");
      if (!field) return;

      // Image content alt expands/collapses for the whole column in this page view.
      if (field === "image_content_alt" || field === "duplicate_reason") {
        event.preventDefault();
        expandedColumns[field] = !expandedColumns[field];
        renderTablePage();
        return;
      }

      var wrap = target.matches(".sdt-expandable") ? target : (target.closest ? target.closest(".sdt-expandable") : null);
      if (!wrap) return;
      event.preventDefault();
      var value = wrap.querySelector(".sdt-expandable__value");
      if (!value) return;
      var expanded = wrap.classList.contains("is-expanded");
      if (expanded) {
        wrap.classList.remove("is-expanded");
        value.textContent = String(wrap.getAttribute("data-short") || "");
      } else {
        wrap.classList.add("is-expanded");
        value.textContent = String(wrap.getAttribute("data-full") || "");
      }
    });
  }
  function renderTablePage() {
    renderDynamicHeader();
    var tbody = document.querySelector("#sdt-result-table tbody"); tbody.innerHTML = "";
    var sourceRows = getFilteredRows();
    var start = (currentPage - 1) * pageSize, end = start + pageSize, slice = sourceRows.slice(start, end);
    var cols = Array.isArray(currentColumns) && currentColumns.length ? currentColumns : columnsFromRules();
    if (!slice.length) { tbody.innerHTML = '<tr><td colspan="' + String(5 + cols.length) + '">No rows found.</td></tr>'; syncSelectAllCheckbox(); return; }
    slice.forEach(function (row) {
      var key = selectionKey(row);
      var checked = key && selectedContentIds.has(key) ? ' checked="checked"' : "";
      var tr = document.createElement("tr"); tr.className = severityClass(row.issue_type);
      tr.innerHTML = "<td><input type=\"checkbox\" class=\"sdt-row-select\" value=\"" + esc(key) + "\"" + checked + " /></td><td>" + esc(row.content_id) + "</td>"
        + cols.map(function (field) { return "<td data-field=\"" + esc(field) + "\">" + cellHtml(field, row[field]) + "</td>"; }).join("")
        + "<td>" + quickEditLink(row) + "</td><td>" + fullEditLink(row) + "</td><td>" + viewLink(row) + "</td>";
      tbody.appendChild(tr);
    });
    syncSelectAllCheckbox();
    bindExpandableCells();
  }
  function bindExportSelection() {
    var exportForm = document.getElementById("sdt-export-form");
    var selectedInput = document.getElementById("sdt-export-selected-ids");
    if (!exportForm || !selectedInput) return;
    exportForm.addEventListener("submit", function (event) {
      var selected = Array.from(selectedContentIds);
      if (!selected.length) {
        event.preventDefault();
        window.alert("Please select at least one content row before downloading.");
        return;
      }
      selectedInput.value = selected.join(",");
    });
  }
  function bindForm() {
    var form = document.getElementById("sdt-rule-form");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      currentRules = collectRules();
      var submitter = e.submitter || null;
      var isDuplicateRun = !!(submitter && submitter.id === "sdt-find-duplicates");
      currentRules.duplicates_only = isDuplicateRun;
      if (isDuplicateRun) {
        var selectedHeaders = Array.isArray(currentRules.fields) ? currentRules.fields.filter(function (f) { return f !== "post_link"; }) : [];
        if (!selectedHeaders.length) {
          window.alert("Select at least one header first, then click Find Duplicates.");
          return;
        }
      }
      document.getElementById("sdt-export-module").value = currentModule;
      document.getElementById("sdt-export-rules").value = JSON.stringify(currentRules || {});
      rerunCurrentScan(true).catch(function (err) { window.alert(err.message || "Scan failed."); });
    });
  }
  function bindDocumentationToggle() {
    var toggle = document.getElementById("sdt-doc-toggle");
    var closeBtn = document.getElementById("sdt-doc-close");
    var modal = document.getElementById("sdt-doc-modal");
    var backdrop = document.getElementById("sdt-doc-backdrop");
    if (!toggle || !modal) return;
    function setOpen(open) {
      modal.hidden = !open;
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    }
    toggle.addEventListener("click", function () { setOpen(modal.hidden); });
    if (closeBtn) closeBtn.addEventListener("click", function () { setOpen(false); });
    if (backdrop) backdrop.addEventListener("click", function () { setOpen(false); });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !modal.hidden) setOpen(false);
    });
  }
  function bindQuickEditModal() {
    var modal = document.getElementById("sdt-quick-modal");
    var closeBtn = document.getElementById("sdt-quick-close");
    var cancelBtn = document.getElementById("sdt-quick-cancel");
    var backdrop = document.getElementById("sdt-quick-backdrop");
    var form = document.getElementById("sdt-quick-form");
    var statusBox = document.getElementById("sdt-quick-status");
    var idInput = document.getElementById("sdt-quick-post-id");
    var updateTitleInput = document.getElementById("sdt-quick-update-title");
    var updateSeoTitleInput = document.getElementById("sdt-quick-update-seo-title");
    var updateMetaInput = document.getElementById("sdt-quick-update-meta");
    var updateStatusInput = document.getElementById("sdt-quick-update-status");
    var updateSchemaInput = document.getElementById("sdt-quick-update-schema");
    var updateRobotsInput = document.getElementById("sdt-quick-update-robots");
    var updateSlugInput = document.getElementById("sdt-quick-update-slug");
    var updateExcerptInput = document.getElementById("sdt-quick-update-excerpt");
    var updateCategoriesInput = document.getElementById("sdt-quick-update-categories");
    var updateTagsInput = document.getElementById("sdt-quick-update-tags");
    var updatePageTypeInput = document.getElementById("sdt-quick-update-page-type");
    var updateFeaturedImageInput = document.getElementById("sdt-quick-update-featured-image");
    var updateContentImagesInput = document.getElementById("sdt-quick-update-content-images");
    var updateFeaturedAltInput = document.getElementById("sdt-quick-update-featured-alt");
    var updateImageContentAltInput = document.getElementById("sdt-quick-update-image-content-alt");
    var updateH1Input = document.getElementById("sdt-quick-update-h1");
    var updateH2Input = document.getElementById("sdt-quick-update-h2");
    var updateH3Input = document.getElementById("sdt-quick-update-h3");
    var updateH4Input = document.getElementById("sdt-quick-update-h4");
    var statusField = document.getElementById("sdt-quick-field-status");
    var postStatusInput = document.getElementById("sdt-quick-post-status");
    var statusHint = document.getElementById("sdt-quick-status-hint");
    var titleField = document.getElementById("sdt-quick-field-title");
    var titleLabel = titleField ? titleField.querySelector("label strong") : null;
    var robotsField = document.getElementById("sdt-quick-field-robots");
    var metaField = document.getElementById("sdt-quick-field-meta");
    var schemaField = document.getElementById("sdt-quick-field-schema");
    var slugField = document.getElementById("sdt-quick-field-slug");
    var excerptField = document.getElementById("sdt-quick-field-excerpt");
    var categoriesField = document.getElementById("sdt-quick-field-categories");
    var tagsField = document.getElementById("sdt-quick-field-tags");
    var pageTypeField = document.getElementById("sdt-quick-field-page-type");
    var featuredImageField = document.getElementById("sdt-quick-field-featured-image");
    var imageContentUrlsField = document.getElementById("sdt-quick-field-image-content-urls");
    var featuredAltField = document.getElementById("sdt-quick-field-featured-alt");
    var imageContentAltField = document.getElementById("sdt-quick-field-image-content-alt");
    var h1Field = document.getElementById("sdt-quick-field-h1");
    var h2Field = document.getElementById("sdt-quick-field-h2");
    var h3Field = document.getElementById("sdt-quick-field-h3");
    var h4Field = document.getElementById("sdt-quick-field-h4");
    var postTitleInput = document.getElementById("sdt-quick-post-title");
    var titleHint = document.getElementById("sdt-quick-title-hint");
    var robotsInput = document.getElementById("sdt-quick-robots");
    var robotsHint = document.getElementById("sdt-quick-robots-hint");
    var slugInput = document.getElementById("sdt-quick-slug");
    var slugHint = document.getElementById("sdt-quick-slug-hint");
    var excerptInput = document.getElementById("sdt-quick-excerpt");
    var excerptHint = document.getElementById("sdt-quick-excerpt-hint");
    var categoriesInput = document.getElementById("sdt-quick-categories");
    var categoriesHint = document.getElementById("sdt-quick-categories-hint");
    var tagsInput = document.getElementById("sdt-quick-tags");
    var tagsHint = document.getElementById("sdt-quick-tags-hint");
    var pageTypeInput = document.getElementById("sdt-quick-page-type");
    var pageTypeHint = document.getElementById("sdt-quick-page-type-hint");
    var featuredImageIdInput = document.getElementById("sdt-quick-featured-image-id");
    var featuredImageUrlInput = document.getElementById("sdt-quick-featured-image-url");
    var featuredImagePickBtn = document.getElementById("sdt-quick-featured-image-pick");
    var featuredImageClearBtn = document.getElementById("sdt-quick-featured-image-clear");
    var featuredImageHint = document.getElementById("sdt-quick-featured-image-hint");
    var contentImagesJsonInput = document.getElementById("sdt-quick-content-images-json");
    var contentImagesList = document.getElementById("sdt-quick-content-images-list");
    var contentImagesHint = document.getElementById("sdt-quick-content-images-hint");
    var featuredAltInput = document.getElementById("sdt-quick-featured-alt");
    var featuredAltHint = document.getElementById("sdt-quick-featured-alt-hint");
    var imageContentAltInput = document.getElementById("sdt-quick-image-content-alt");
    var imageContentAltHint = document.getElementById("sdt-quick-image-content-alt-hint");
    var h1Input = document.getElementById("sdt-quick-h1-view");
    var h1Hint = document.getElementById("sdt-quick-h1-hint");
    var h2Input = document.getElementById("sdt-quick-h2");
    var h2Hint = document.getElementById("sdt-quick-h2-hint");
    var h3Input = document.getElementById("sdt-quick-h3");
    var h3Hint = document.getElementById("sdt-quick-h3-hint");
    var h4Input = document.getElementById("sdt-quick-h4");
    var h4Hint = document.getElementById("sdt-quick-h4-hint");
    var metaDescInput = document.getElementById("sdt-quick-meta-desc");
    var metaHint = document.getElementById("sdt-quick-meta-hint");
    var schemaInput = document.getElementById("sdt-quick-schema");
    var schemaHint = document.getElementById("sdt-quick-schema-hint");
    var saveBtn = document.getElementById("sdt-quick-save");
    var tbody = document.querySelector("#sdt-result-table tbody");
    if (!modal || !form || !statusBox || !idInput || !updateTitleInput || !updateSeoTitleInput || !updateMetaInput || !updateStatusInput || !updateSchemaInput || !updateRobotsInput || !updateSlugInput || !updateExcerptInput || !updateCategoriesInput || !updateTagsInput || !updatePageTypeInput || !updateFeaturedImageInput || !updateContentImagesInput || !updateFeaturedAltInput || !updateImageContentAltInput || !updateH1Input || !updateH2Input || !updateH3Input || !updateH4Input || !statusField || !postStatusInput || !statusHint || !titleField || !metaField || !schemaField || !robotsField || !slugField || !excerptField || !categoriesField || !tagsField || !pageTypeField || !featuredImageField || !imageContentUrlsField || !featuredAltField || !imageContentAltField || !h1Field || !h2Field || !h3Field || !h4Field || !postTitleInput || !titleHint || !robotsInput || !robotsHint || !slugInput || !slugHint || !excerptInput || !excerptHint || !categoriesInput || !categoriesHint || !tagsInput || !tagsHint || !pageTypeInput || !pageTypeHint || !featuredImageIdInput || !featuredImageUrlInput || !featuredImagePickBtn || !featuredImageClearBtn || !featuredImageHint || !contentImagesJsonInput || !contentImagesList || !contentImagesHint || !featuredAltInput || !featuredAltHint || !imageContentAltInput || !imageContentAltHint || !h1Input || !h1Hint || !h2Input || !h2Hint || !h3Input || !h3Hint || !h4Input || !h4Hint || !metaDescInput || !metaHint || !schemaInput || !schemaHint || !saveBtn || !tbody) return;
    var quickContext = { module: "content_audit", issue: "" };
    var contentImageReplacementMap = {};
    var currentContentImages = [];

    function setStatus(message, kind) {
      statusBox.textContent = message || "";
      statusBox.className = "sdt-quick-status";
      if (kind) statusBox.classList.add("is-" + kind);
    }
    function setOpen(open) {
      modal.hidden = !open;
    }
    function postAjax(payload) {
      return fetch(SDT_DATA.ajaxUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: new URLSearchParams(payload)
      }).then(function (r) { return r.json(); });
    }
    function openMediaPicker(onSelect) {
      if (!window.wp || !window.wp.media) {
        window.alert("WordPress media library is not available.");
        return;
      }
      var frame = window.wp.media({
        title: "Select image",
        button: { text: "Use this image" },
        library: { type: "image" },
        multiple: false
      });
      frame.on("select", function () {
        var selection = frame.state().get("selection");
        var item = selection && selection.first ? selection.first().toJSON() : null;
        if (!item) return;
        var id = parseInt(item.id || 0, 10) || 0;
        var url = String((item.url || (item.sizes && item.sizes.full && item.sizes.full.url) || "") || "");
        if (!url) return;
        onSelect({ id: id, url: url });
      });
      frame.open();
    }
    function syncContentImageReplacementJson() {
      var list = Object.keys(contentImageReplacementMap).map(function (key) {
        var index = parseInt(key, 10);
        var val = contentImageReplacementMap[key] || {};
        var remove = !!val.remove;
        return {
          index: isFinite(index) ? index : 0,
          remove: remove,
          id: parseInt(val.id || 0, 10) || 0,
          url: remove ? "" : String(val.url || "")
        };
      });
      contentImagesJsonInput.value = JSON.stringify(list);
      updateContentImagesInput.value = list.length ? "1" : "0";
    }
    function renderContentImagesEditor() {
      if (!currentContentImages.length) {
        contentImagesList.innerHTML = "<span class=\"sdt-link-na\">N/A</span>";
        return;
      }
      contentImagesList.innerHTML = currentContentImages.map(function (item) {
        var index = parseInt(item.index || 0, 10) || 0;
        var replacement = contentImageReplacementMap[index] || null;
        var isRemoved = !!(replacement && replacement.remove);
        var displayUrl = isRemoved ? "[Will be removed on save]" : (replacement && replacement.url ? replacement.url : String(item.url || ""));
        var attachmentId = (isRemoved ? 0 : (replacement && replacement.id ? replacement.id : (parseInt(item.id || 0, 10) || 0)));
        var attachmentLabel = isRemoved ? "Pending removal" : (attachmentId > 0 ? "Attachment ID: " + attachmentId : "Attachment ID: N/A");
        var escapedUrl = esc(displayUrl || "");
        return ""
          + "<div class=\"sdt-image-edit-row\" data-index=\"" + index + "\">"
          + "<div class=\"sdt-image-edit-row__label\">Image #" + (index + 1) + " <span class=\"description\">(" + esc(attachmentLabel) + ")</span></div>"
          + "<input type=\"text\" class=\"regular-text\" readonly value=\"" + escapedUrl + "\" />"
          + "<div class=\"sdt-image-edit-row__actions\">"
          + "<button type=\"button\" class=\"button sdt-content-image-pick\" data-index=\"" + index + "\">Replace</button>"
          + "<button type=\"button\" class=\"button sdt-content-image-remove\" data-index=\"" + index + "\">Remove</button>"
          + "<button type=\"button\" class=\"button sdt-content-image-reset\" data-index=\"" + index + "\"" + (replacement ? "" : " disabled") + ">Reset</button>"
          + "</div></div>";
      }).join("");
    }
    function hasEditableFields() {
      return updateTitleInput.value === "1" || updateSeoTitleInput.value === "1" || updateMetaInput.value === "1" || updateStatusInput.value === "1" || updateSchemaInput.value === "1" || updateRobotsInput.value === "1" || updateSlugInput.value === "1" || updateExcerptInput.value === "1" || updateCategoriesInput.value === "1" || updateTagsInput.value === "1" || updatePageTypeInput.value === "1" || updateFeaturedImageInput.value === "1" || updateContentImagesInput.value === "1" || updateFeaturedAltInput.value === "1" || updateImageContentAltInput.value === "1" || updateH1Input.value === "1" || updateH2Input.value === "1" || updateH3Input.value === "1" || updateH4Input.value === "1" || !featuredImageField.hidden || !imageContentUrlsField.hidden;
    }
    function setFieldState(input, hintEl, isValid, text) {
      if (!input || !hintEl) return;
      input.classList.remove("sdt-input-valid", "sdt-input-invalid");
      input.classList.add(isValid ? "sdt-input-valid" : "sdt-input-invalid");
      hintEl.textContent = text || "";
    }
    function hasDuplicateLines(rawText) {
      var lines = String(rawText || "").split("\n").map(function (x) { return String(x || "").trim(); }).filter(function (x) { return x !== ""; });
      if (lines.length < 2) return false;
      var seen = {};
      for (var i = 0; i < lines.length; i++) {
        var key = lines[i].toLowerCase().replace(/\s+/g, " ").trim();
        if (!key) continue;
        if (seen[key]) return true;
        seen[key] = true;
      }
      return false;
    }
    function renderHeadingPreview(rawText, container) {
      if (!container) return;
      var lines = String(rawText || "").split("\n").map(function (x) { return String(x || "").trim(); }).filter(function (x) { return x !== ""; });
      if (!lines.length) {
        container.innerHTML = '<span class="sdt-link-na">N/A</span>';
        return;
      }
      var counts = {};
      lines.forEach(function (line) {
        var key = line.toLowerCase().replace(/\s+/g, " ").trim();
        if (!key) return;
        counts[key] = (counts[key] || 0) + 1;
      });
      container.innerHTML = lines.map(function (line) {
        var key = line.toLowerCase().replace(/\s+/g, " ").trim();
        var dup = key && counts[key] > 1;
        var cls = dup ? "sdt-heading-preview__line is-dup" : "sdt-heading-preview__line";
        return '<span class="' + cls + '">' + esc(line) + '</span>';
      }).join("");
    }
    function validateQuickForm() {
      var module = String(quickContext.module || "").toLowerCase();
      function nonEmpty(v) { return String(v || "").trim() !== ""; }
      function resetField(input, hintEl) {
        if (!input || !hintEl) return;
        input.classList.remove("sdt-input-valid", "sdt-input-invalid");
        hintEl.textContent = "";
      }
      if (module === "content_audit") {
        if (!titleField.hidden) setFieldState(postTitleInput, titleHint, nonEmpty(postTitleInput.value), nonEmpty(postTitleInput.value) ? "Set" : "Missing");
        if (!metaField.hidden) setFieldState(metaDescInput, metaHint, nonEmpty(metaDescInput.value), nonEmpty(metaDescInput.value) ? "Set" : "Missing");
        if (!schemaField.hidden) {
          var rawSchema = String(schemaInput.value || "").trim();
          var schemaValid = false;
          if (rawSchema !== "") {
            try { schemaValid = !!JSON.parse(rawSchema); } catch (e) { schemaValid = false; }
          }
          setFieldState(schemaInput, schemaHint, schemaValid, schemaValid ? "Set" : "Missing/Invalid");
        }
        if (!robotsField.hidden) setFieldState(robotsInput, robotsHint, nonEmpty(robotsInput.value), nonEmpty(robotsInput.value) ? "Set" : "Missing");
        if (!slugField.hidden) setFieldState(slugInput, slugHint, nonEmpty(slugInput.value), nonEmpty(slugInput.value) ? "Set" : "Missing");
        if (!excerptField.hidden) setFieldState(excerptInput, excerptHint, nonEmpty(excerptInput.value), nonEmpty(excerptInput.value) ? "Set" : "Missing");
        if (!categoriesField.hidden) setFieldState(categoriesInput, categoriesHint, nonEmpty(categoriesInput.value), nonEmpty(categoriesInput.value) ? "Set" : "Missing");
        if (!tagsField.hidden) setFieldState(tagsInput, tagsHint, nonEmpty(tagsInput.value), nonEmpty(tagsInput.value) ? "Set" : "Missing");
        if (!pageTypeField.hidden) setFieldState(pageTypeInput, pageTypeHint, nonEmpty(pageTypeInput.value), nonEmpty(pageTypeInput.value) ? "Set" : "Missing");
        if (!featuredImageField.hidden) setFieldState(featuredImageUrlInput, featuredImageHint, nonEmpty(featuredImageUrlInput.value), nonEmpty(featuredImageUrlInput.value) ? "Set" : "Missing");
        if (!imageContentUrlsField.hidden) contentImagesHint.textContent = currentContentImages.length ? "Use Replace per image item, then Save." : "No content images detected in this post.";
        if (!featuredAltField.hidden) setFieldState(featuredAltInput, featuredAltHint, nonEmpty(featuredAltInput.value), nonEmpty(featuredAltInput.value) ? "Set" : "Missing");
        if (!imageContentAltField.hidden) setFieldState(imageContentAltInput, imageContentAltHint, true, "Use CSV style: yes,\"new alt\",yes,\"another alt\"");
        if (!h1Field.hidden) h1Hint.textContent = "Read-only in Quick Edit. Red lines are duplicates.";
        if (!h2Field.hidden) {
          var h2Dup = hasDuplicateLines(h2Input.value);
          setFieldState(h2Input, h2Hint, !h2Dup, h2Dup ? "Duplicate H2 found in this list." : "Editable in Quick Edit. One heading per line.");
        }
        if (!h3Field.hidden) {
          var h3Dup = hasDuplicateLines(h3Input.value);
          setFieldState(h3Input, h3Hint, !h3Dup, h3Dup ? "Duplicate H3 found in this list." : "Editable in Quick Edit. One heading per line.");
        }
        if (!h4Field.hidden) {
          var h4Dup = hasDuplicateLines(h4Input.value);
          setFieldState(h4Input, h4Hint, !h4Dup, h4Dup ? "Duplicate H4 found in this list." : "Editable in Quick Edit. One heading per line.");
        }
      } else if (module === "heading_structure") {
        if (!titleField.hidden) setFieldState(postTitleInput, titleHint, nonEmpty(postTitleInput.value), nonEmpty(postTitleInput.value) ? "Set" : "Missing");
        resetField(metaDescInput, metaHint);
        resetField(postStatusInput, statusHint);
        resetField(schemaInput, schemaHint);
      } else if (module === "indexability_checks") {
        var statusVal = String(postStatusInput.value || "");
        var statusValid = statusVal === "publish";
        if (!statusField.hidden) setFieldState(postStatusInput, statusHint, statusValid, statusValid ? "publish" : "Must be publish");
        resetField(postTitleInput, titleHint);
        resetField(metaDescInput, metaHint);
        resetField(schemaInput, schemaHint);
      } else {
        resetField(postTitleInput, titleHint);
        resetField(metaDescInput, metaHint);
        resetField(postStatusInput, statusHint);
        resetField(schemaInput, schemaHint);
        resetField(robotsInput, robotsHint);
        resetField(slugInput, slugHint);
        resetField(excerptInput, excerptHint);
        resetField(categoriesInput, categoriesHint);
        resetField(tagsInput, tagsHint);
        resetField(pageTypeInput, pageTypeHint);
        resetField(featuredImageUrlInput, featuredImageHint);
        contentImagesHint.textContent = "";
        resetField(featuredAltInput, featuredAltHint);
        resetField(imageContentAltInput, imageContentAltHint);
        h1Hint.textContent = "";
        h2Hint.textContent = "";
        h3Hint.textContent = "";
        h4Hint.textContent = "";
      }
    }
    function applyFieldVisibility(moduleKey, issueType) {
      var issue = String(issueType || "").toLowerCase();
      var module = String(moduleKey || "").toLowerCase();
      quickContext.module = module;
      quickContext.issue = issue;
      var flags = moduleFieldFlags(module);
      var showTitle = !!flags.title;
      var showMeta = !!flags.meta;
      var showStatus = !!flags.status;
      var showSchema = !!flags.schema;
      var showRobots = !!flags.robots;
      var showSlug = !!flags.slug;
      var showExcerpt = !!flags.excerpt;
      var showCategories = !!flags.categories;
      var showTags = !!flags.tags;
      var showPageType = !!flags.pageType;
      var showFeaturedImage = !!flags.featuredImage;
      var showImageContentUrls = !!flags.imageContentUrls;
      var showFeaturedAlt = !!flags.featuredAlt;
      var showImageContentAlt = !!flags.imageContentAlt;
      var showH1 = !!flags.h1;
      var showH2 = !!flags.h2;
      var showH3 = !!flags.h3;
      var showH4 = !!flags.h4;
      if (module === "heading_structure") {
        showTitle = true;
        showMeta = false;
        showStatus = false;
        showSchema = false;
        showRobots = false;
        if (titleLabel) titleLabel.textContent = "Content Title";
      } else if (module === "content_audit") {
        // Show only selected fields from this diagnostic run.
        if (titleLabel) titleLabel.textContent = "SEO Title";
      } else if (module === "indexability_checks") {
        showTitle = false;
        showMeta = false;
        showStatus = true;
        showSchema = false;
        showRobots = false;
        showSlug = false;
        showExcerpt = false;
        showCategories = false;
        showTags = false;
        showPageType = false;
        showFeaturedImage = false;
        showImageContentUrls = false;
        showFeaturedAlt = false;
        showImageContentAlt = false;
        showH1 = false;
        showH2 = false;
        showH3 = false;
        showH4 = false;
        if (titleLabel) titleLabel.textContent = "Content Title";
      } else if (module === "image_optimize" || module === "broken_internal_links") {
        showTitle = false;
        showMeta = false;
        showStatus = false;
        showSchema = false;
        showRobots = false;
        showSlug = false;
        showExcerpt = false;
        showCategories = false;
        showTags = false;
        showPageType = false;
        showFeaturedImage = false;
        showImageContentUrls = false;
        showFeaturedAlt = false;
        showImageContentAlt = false;
        showH1 = false;
        showH2 = false;
        showH3 = false;
        showH4 = false;
        setStatus("This module is best fixed via Post Open / Asset Link. Quick Edit is not required here.", "info");
        if (titleLabel) titleLabel.textContent = "Content Title";
      }
      statusField.hidden = !showStatus;
      titleField.hidden = !showTitle;
      metaField.hidden = !showMeta;
      schemaField.hidden = !showSchema;
      robotsField.hidden = !showRobots;
      slugField.hidden = !showSlug;
      excerptField.hidden = !showExcerpt;
      categoriesField.hidden = !showCategories;
      tagsField.hidden = !showTags;
      pageTypeField.hidden = !showPageType;
      featuredImageField.hidden = !showFeaturedImage;
      imageContentUrlsField.hidden = !showImageContentUrls;
      featuredAltField.hidden = !showFeaturedAlt;
      imageContentAltField.hidden = !showImageContentAlt;
      h1Field.hidden = !showH1;
      h2Field.hidden = !showH2;
      h3Field.hidden = !showH3;
      h4Field.hidden = !showH4;
      updateStatusInput.value = showStatus ? "1" : "0";
      updateTitleInput.value = (module === "heading_structure" && showTitle) ? "1" : "0";
      updateSeoTitleInput.value = (module === "content_audit" && showTitle) ? "1" : "0";
      updateMetaInput.value = showMeta ? "1" : "0";
      updateSchemaInput.value = showSchema ? "1" : "0";
      updateRobotsInput.value = showRobots ? "1" : "0";
      updateSlugInput.value = showSlug ? "1" : "0";
      updateExcerptInput.value = showExcerpt ? "1" : "0";
      updateCategoriesInput.value = showCategories ? "1" : "0";
      updateTagsInput.value = showTags ? "1" : "0";
      updatePageTypeInput.value = showPageType ? "1" : "0";
      updateFeaturedImageInput.value = "0";
      if (!showImageContentUrls) {
        contentImageReplacementMap = {};
        contentImagesJsonInput.value = "[]";
      }
      updateContentImagesInput.value = "0";
      updateFeaturedAltInput.value = showFeaturedAlt ? "1" : "0";
      updateImageContentAltInput.value = showImageContentAlt ? "1" : "0";
      // H1 is visible-only in quick edit. H2-H4 remain editable.
      updateH1Input.value = "0";
      updateH2Input.value = showH2 ? "1" : "0";
      updateH3Input.value = showH3 ? "1" : "0";
      updateH4Input.value = showH4 ? "1" : "0";
      if (!hasEditableFields()) {
        setStatus("No editable fields were selected for this run. Select fields in Function Details and run again.", "info");
      }
      saveBtn.disabled = !hasEditableFields();
    }
    function openForPost(postId, moduleKey, issueType) {
      if (!postId) return;
      applyFieldVisibility(moduleKey, issueType);
      idInput.value = String(postId);
      updateContentImagesInput.value = "0";
      updateFeaturedImageInput.value = "0";
      contentImageReplacementMap = {};
      currentContentImages = [];
      contentImagesJsonInput.value = "[]";
      contentImagesList.innerHTML = "";
      featuredImageIdInput.value = "0";
      featuredImageUrlInput.value = "";
      setStatus("Loading current values...", "info");
      saveBtn.disabled = true;
      setOpen(true);
      postAjax({
        action: "sdt_quick_edit_get",
        nonce: SDT_DATA.quickEditNonce,
        post_id: String(postId)
      }).then(function (res) {
        if (!res || !res.success || !res.data) {
          throw new Error((res && res.data && res.data.message) ? res.data.message : "Could not load post values.");
        }
        postTitleInput.value = (quickContext.module === "content_audit") ? (res.data.seo_title || "") : (res.data.post_title || "");
        metaDescInput.value = res.data.meta_description || "";
        postStatusInput.value = res.data.post_status || "draft";
        schemaInput.value = res.data.schema_json || "";
        robotsInput.value = res.data.robots || "";
        slugInput.value = res.data.slug || "";
        excerptInput.value = res.data.excerpt || "";
        categoriesInput.value = res.data.categories || "";
        tagsInput.value = res.data.tags || "";
        pageTypeInput.value = res.data.page_type || "";
        featuredImageIdInput.value = String((res.data.featured_image && res.data.featured_image.id) ? res.data.featured_image.id : 0);
        featuredImageUrlInput.value = String((res.data.featured_image && res.data.featured_image.url) ? res.data.featured_image.url : "");
        currentContentImages = Array.isArray(res.data.content_images) ? res.data.content_images : [];
        renderContentImagesEditor();
        featuredAltInput.value = res.data.featured_alt_text || "";
        imageContentAltInput.value = res.data.image_content_alt_text || "";
        renderHeadingPreview(res.data.h1_lines || "", h1Input);
        h2Input.value = res.data.h2_lines || "";
        h3Input.value = res.data.h3_lines || "";
        h4Input.value = res.data.h4_lines || "";
        validateQuickForm();
        setStatus("Loaded current values. You can now edit and save.", "success");
      }).catch(function (err) {
        setStatus(err.message || "Could not load post values.", "error");
      }).finally(function () {
        saveBtn.disabled = !hasEditableFields();
      });
    }

    tbody.addEventListener("click", function (event) {
      var btn = event.target && event.target.closest ? event.target.closest(".sdt-quick-edit-btn") : null;
      if (!btn) return;
      event.preventDefault();
      var postId = btn.getAttribute("data-post-id");
      var issueType = btn.getAttribute("data-issue") || "";
      var moduleKey = btn.getAttribute("data-module") || currentModule;
      openForPost(postId, moduleKey, issueType);
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var postId = idInput.value;
      if (!postId || !hasEditableFields()) return;
      setStatus("Saving changes...", "info");
      saveBtn.disabled = true;
      postAjax({
        action: "sdt_quick_edit_save",
        nonce: SDT_DATA.quickEditNonce,
        module: quickContext.module,
        post_id: postId,
        update_title: updateTitleInput.value,
        update_seo_title: updateSeoTitleInput.value,
        update_meta_description: updateMetaInput.value,
        update_status: updateStatusInput.value,
        update_schema: updateSchemaInput.value,
        update_robots: updateRobotsInput.value,
        update_slug: updateSlugInput.value,
        update_excerpt: updateExcerptInput.value,
        update_categories: updateCategoriesInput.value,
        update_tags: updateTagsInput.value,
        update_page_type: updatePageTypeInput.value,
        update_featured_image: updateFeaturedImageInput.value,
        update_content_images: updateContentImagesInput.value,
        update_featured_alt: updateFeaturedAltInput.value,
        update_image_content_alt: updateImageContentAltInput.value,
        update_h1: "0",
        update_h2: updateH2Input.value,
        update_h3: updateH3Input.value,
        update_h4: updateH4Input.value,
        post_title: postTitleInput.value,
        seo_title: postTitleInput.value,
        meta_description: metaDescInput.value,
        post_status: postStatusInput.value,
        schema_json: schemaInput.value,
        robots: robotsInput.value,
        slug: slugInput.value,
        excerpt: excerptInput.value,
        categories: categoriesInput.value,
        tags: tagsInput.value,
        page_type: pageTypeInput.value,
        featured_image_id: featuredImageIdInput.value,
        content_images_json: contentImagesJsonInput.value,
        featured_alt_text: featuredAltInput.value,
        image_content_alt_text: imageContentAltInput.value,
        h1_lines: "",
        h2_lines: h2Input.value,
        h3_lines: h3Input.value,
        h4_lines: h4Input.value
      }).then(function (res) {
        if (!res || !res.success) {
          throw new Error((res && res.data && res.data.message) ? res.data.message : "Save failed.");
        }
        setStatus("Saved successfully.", "success");
        return rerunCurrentScan(false).catch(function () {});
      }).catch(function (err) {
        setStatus(err.message || "Save failed.", "error");
      }).finally(function () {
        saveBtn.disabled = false;
      });
    });
    postTitleInput.addEventListener("input", validateQuickForm);
    metaDescInput.addEventListener("input", validateQuickForm);
    postStatusInput.addEventListener("change", validateQuickForm);
    schemaInput.addEventListener("input", validateQuickForm);
    robotsInput.addEventListener("change", validateQuickForm);
    slugInput.addEventListener("input", validateQuickForm);
    excerptInput.addEventListener("input", validateQuickForm);
    categoriesInput.addEventListener("input", validateQuickForm);
    tagsInput.addEventListener("input", validateQuickForm);
    pageTypeInput.addEventListener("change", validateQuickForm);
    featuredImagePickBtn.addEventListener("click", function () {
      openMediaPicker(function (item) {
        featuredImageIdInput.value = String(item.id || 0);
        featuredImageUrlInput.value = String(item.url || "");
        updateFeaturedImageInput.value = "1";
        validateQuickForm();
      });
    });
    featuredImageClearBtn.addEventListener("click", function () {
      featuredImageIdInput.value = "0";
      featuredImageUrlInput.value = "";
      updateFeaturedImageInput.value = "1";
      validateQuickForm();
    });
    contentImagesList.addEventListener("click", function (event) {
      var replaceBtn = event.target && event.target.closest ? event.target.closest(".sdt-content-image-pick") : null;
      if (replaceBtn) {
        event.preventDefault();
        var idxReplace = parseInt(replaceBtn.getAttribute("data-index") || "-1", 10);
        if (!isFinite(idxReplace) || idxReplace < 0) return;
        openMediaPicker(function (item) {
          contentImageReplacementMap[idxReplace] = { id: parseInt(item.id || 0, 10) || 0, url: String(item.url || "") };
          updateContentImagesInput.value = "1";
          syncContentImageReplacementJson();
          renderContentImagesEditor();
          validateQuickForm();
        });
        return;
      }
      var removeBtn = event.target && event.target.closest ? event.target.closest(".sdt-content-image-remove") : null;
      if (removeBtn) {
        event.preventDefault();
        var idxRemove = parseInt(removeBtn.getAttribute("data-index") || "-1", 10);
        if (!isFinite(idxRemove) || idxRemove < 0) return;
        contentImageReplacementMap[idxRemove] = { remove: true, id: 0, url: "" };
        updateContentImagesInput.value = "1";
        syncContentImageReplacementJson();
        renderContentImagesEditor();
        validateQuickForm();
        return;
      }
      var resetBtn = event.target && event.target.closest ? event.target.closest(".sdt-content-image-reset") : null;
      if (resetBtn) {
        event.preventDefault();
        var idxReset = parseInt(resetBtn.getAttribute("data-index") || "-1", 10);
        if (!isFinite(idxReset) || idxReset < 0) return;
        delete contentImageReplacementMap[idxReset];
        syncContentImageReplacementJson();
        renderContentImagesEditor();
        validateQuickForm();
      }
    });
    featuredAltInput.addEventListener("input", validateQuickForm);
    imageContentAltInput.addEventListener("input", validateQuickForm);
    h2Input.addEventListener("input", validateQuickForm);
    h3Input.addEventListener("input", validateQuickForm);
    h4Input.addEventListener("input", validateQuickForm);

    [closeBtn, cancelBtn, backdrop].forEach(function (el) {
      if (!el) return;
      el.addEventListener("click", function () { setOpen(false); });
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !modal.hidden) setOpen(false);
    });
  }
  function bindBulkQuickEditModal() {
    var openBtn = document.getElementById("sdt-bulk-quick-open");
    var modal = document.getElementById("sdt-bulk-quick-modal");
    var closeBtn = document.getElementById("sdt-bulk-quick-close");
    var cancelBtn = document.getElementById("sdt-bulk-quick-cancel");
    var backdrop = document.getElementById("sdt-bulk-quick-backdrop");
    var form = document.getElementById("sdt-bulk-quick-form");
    var statusBox = document.getElementById("sdt-bulk-quick-status");
    var summary = document.getElementById("sdt-bulk-quick-summary");
    var list = document.getElementById("sdt-bulk-quick-list");
    var saveBtn = document.getElementById("sdt-bulk-quick-save");
    if (!openBtn || !modal || !form || !statusBox || !summary || !list || !saveBtn) return;

    function setOpen(open) { modal.hidden = !open; }
    function setStatus(message, kind) {
      statusBox.textContent = message || "";
      statusBox.className = "sdt-quick-status";
      if (kind) statusBox.classList.add("is-" + kind);
    }
    function postAjax(payload) {
      return fetch(SDT_DATA.ajaxUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: new URLSearchParams(payload)
      }).then(function (r) { return r.json(); });
    }
    function selectedEditableRows() {
      var idMap = {};
      currentRows.forEach(function (row) {
        var key = selectionKey(row);
        if (!key || !selectedContentIds.has(key)) return;
        if (String(contentTypeKey(row)) !== "post") return;
        if (!idMap[key]) idMap[key] = row;
      });
      return Object.keys(idMap).map(function (k) { return idMap[k]; });
    }
    function statusOptions(selected) {
      var listOpts = ["publish", "draft", "pending", "future", "private"];
      return listOpts.map(function (value) {
        var chosen = String(selected || "") === value ? " selected" : "";
        return "<option value=\"" + esc(value) + "\"" + chosen + ">" + esc(value) + "</option>";
      }).join("");
    }
    function renderBulkRows(rows, valuesById, flags) {
      list.className = "sdt-bulk-list";
      list.innerHTML = rows.map(function (row) {
        var key = selectionKey(row);
        var val = valuesById[key] || {};
        var html = "<div class=\"sdt-bulk-item\" data-post-id=\"" + esc(key) + "\">";
        html += "<h3>" + esc(row.content_title || ("Post #" + key)) + "</h3>";
        if (flags.title && currentModule === "content_audit") html += "<p><label><strong>SEO Title</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"seo_title\" value=\"" + esc(val.seo_title || "") + "\" /></p>";
        if (flags.title && currentModule !== "content_audit") html += "<p><label><strong>Content Title</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"post_title\" value=\"" + esc(val.post_title || "") + "\" /></p>";
        if (flags.meta) html += "<p><label><strong>Meta Description</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"meta_description\">" + esc(val.meta_description || "") + "</textarea></p>";
        if (flags.status) html += "<p><label><strong>Post Status</strong></label><br /><select data-field=\"post_status\">" + statusOptions(val.post_status || "draft") + "</select></p>";
        if (flags.schema) html += "<p><label><strong>Schema JSON-LD</strong></label><br /><textarea class=\"large-text code\" rows=\"6\" data-field=\"schema_json\">" + esc(val.schema_json || "") + "</textarea></p>";
        if (flags.robots) html += "<p><label><strong>Robots</strong></label><br /><select data-field=\"robots\"><option value=\"\">Default (empty)</option><option value=\"index,follow\"" + (String(val.robots || "") === "index,follow" ? " selected" : "") + ">index,follow</option><option value=\"noindex,follow\"" + (String(val.robots || "") === "noindex,follow" ? " selected" : "") + ">noindex,follow</option><option value=\"index,nofollow\"" + (String(val.robots || "") === "index,nofollow" ? " selected" : "") + ">index,nofollow</option><option value=\"noindex,nofollow\"" + (String(val.robots || "") === "noindex,nofollow" ? " selected" : "") + ">noindex,nofollow</option></select></p>";
        if (flags.slug) html += "<p><label><strong>Slug</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"slug\" value=\"" + esc(val.slug || "") + "\" /></p>";
        if (flags.excerpt) html += "<p><label><strong>Excerpt</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"excerpt\">" + esc(val.excerpt || "") + "</textarea></p>";
        if (flags.categories) html += "<p><label><strong>Categories</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"categories\" value=\"" + esc(val.categories || "") + "\" /></p>";
        if (flags.tags) html += "<p><label><strong>Tags</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"tags\" value=\"" + esc(val.tags || "") + "\" /></p>";
        if (flags.pageType) html += "<p><label><strong>Page Type</strong></label><br /><select data-field=\"page_type\"><option value=\"\">Default (empty)</option><option value=\"Glossary\"" + (String(val.page_type || "") === "Glossary" ? " selected" : "") + ">Glossary</option><option value=\"Pillar\"" + (String(val.page_type || "") === "Pillar" ? " selected" : "") + ">Pillar</option><option value=\"Hub\"" + (String(val.page_type || "") === "Hub" ? " selected" : "") + ">Hub</option><option value=\"Section\"" + (String(val.page_type || "") === "Section" ? " selected" : "") + ">Section</option></select></p>";
        if (flags.featuredAlt) html += "<p><label><strong>Featured Image Alt Text</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"featured_alt_text\" value=\"" + esc(val.featured_alt_text || "") + "\" /></p>";
        if (flags.imageContentAlt) html += "<p><label><strong>Image Content Alt (CSV)</strong></label><br /><input type=\"text\" class=\"regular-text\" data-field=\"image_content_alt_text\" value=\"" + esc(val.image_content_alt_text || "") + "\" placeholder='Example: yes,\"new alt\",yes,\"another alt\"' /></p>";
        if (flags.h1) html += "<p><label><strong>H1 (one per line)</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"h1_lines\">" + esc(val.h1_lines || "") + "</textarea></p>";
        if (flags.h2) html += "<p><label><strong>H2 (one per line)</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"h2_lines\">" + esc(val.h2_lines || "") + "</textarea></p>";
        if (flags.h3) html += "<p><label><strong>H3 (one per line)</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"h3_lines\">" + esc(val.h3_lines || "") + "</textarea></p>";
        if (flags.h4) html += "<p><label><strong>H4 (one per line)</strong></label><br /><textarea class=\"large-text\" rows=\"3\" data-field=\"h4_lines\">" + esc(val.h4_lines || "") + "</textarea></p>";
        html += "<p class=\"description\">Issue: " + esc(row.issue_type || "N/A") + "</p>";
        html += "</div>";
        return html;
      }).join("");
    }

    openBtn.addEventListener("click", function () {
      var flags = moduleFieldFlags(currentModule);
      if (!flags.title && !flags.meta && !flags.h1 && !flags.h2 && !flags.h3 && !flags.h4 && !flags.status && !flags.schema && !flags.robots && !flags.slug && !flags.excerpt && !flags.categories && !flags.tags && !flags.pageType && !flags.featuredAlt && !flags.imageContentAlt) {
        window.alert("This module does not support quick edit fields. Use Post Open / Asset Link.");
        return;
      }
      var rows = selectedEditableRows();
      if (!rows.length) {
        window.alert("Select at least one post row first.");
        return;
      }
      summary.textContent = "Selected posts: " + rows.length + " (" + moduleConfig[currentModule].label + ")";
      setStatus("Loading selected post values...", "info");
      setOpen(true);
      saveBtn.disabled = true;
      var postIds = rows.map(function (row) { return selectionKey(row); }).join(",");
      postAjax({
        action: "sdt_bulk_quick_get",
        nonce: SDT_DATA.quickEditNonce,
        post_ids: postIds
      }).then(function (res) {
        if (!res || !res.success || !res.data || !Array.isArray(res.data.rows)) {
          throw new Error((res && res.data && res.data.message) ? res.data.message : "Could not load selected posts.");
        }
        var valuesById = {};
        res.data.rows.forEach(function (entry) { valuesById[String(entry.post_id)] = entry; });
        renderBulkRows(rows, valuesById, flags);
        setStatus("Loaded. Update fields then click Save All.", "success");
      }).catch(function (err) {
        list.innerHTML = "";
        setStatus(err.message || "Could not load selected posts.", "error");
      }).finally(function () {
        saveBtn.disabled = false;
      });
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var flags = moduleFieldFlags(currentModule);
      var cards = Array.prototype.slice.call(list.querySelectorAll(".sdt-bulk-item"));
      if (!cards.length) {
        setStatus("No editable rows found.", "error");
        return;
      }
      var rows = cards.map(function (card) {
        var postId = card.getAttribute("data-post-id");
        var get = function (name) {
          var input = card.querySelector("[data-field=\"" + name + "\"]");
          return input ? String(input.value || "") : "";
        };
        return {
          post_id: postId,
          update_title: (flags.title && currentModule !== "content_audit") ? "1" : "",
          update_seo_title: (flags.title && currentModule === "content_audit") ? "1" : "",
          update_meta_description: flags.meta ? "1" : "",
          update_status: flags.status ? "1" : "",
          update_schema: flags.schema ? "1" : "",
          update_robots: flags.robots ? "1" : "",
          update_slug: flags.slug ? "1" : "",
          update_excerpt: flags.excerpt ? "1" : "",
          update_categories: flags.categories ? "1" : "",
          update_tags: flags.tags ? "1" : "",
          update_page_type: flags.pageType ? "1" : "",
          update_featured_alt: flags.featuredAlt ? "1" : "",
          update_image_content_alt: flags.imageContentAlt ? "1" : "",
          update_h1: flags.h1 ? "1" : "",
          update_h2: flags.h2 ? "1" : "",
          update_h3: flags.h3 ? "1" : "",
          update_h4: flags.h4 ? "1" : "",
          post_title: get("post_title"),
          seo_title: get("seo_title"),
          meta_description: get("meta_description"),
          post_status: get("post_status"),
          schema_json: get("schema_json"),
          robots: get("robots"),
          slug: get("slug"),
          excerpt: get("excerpt"),
          categories: get("categories"),
          tags: get("tags"),
          page_type: get("page_type"),
          featured_alt_text: get("featured_alt_text"),
          image_content_alt_text: get("image_content_alt_text"),
          h1_lines: get("h1_lines"),
          h2_lines: get("h2_lines"),
          h3_lines: get("h3_lines"),
          h4_lines: get("h4_lines")
        };
      });
      if (flags.schema) {
        for (var i = 0; i < rows.length; i++) {
          var raw = String(rows[i].schema_json || "").trim();
          if (!raw) continue;
          try { JSON.parse(raw); } catch (e) {
            setStatus("Schema JSON is invalid on one or more rows.", "error");
            return;
          }
        }
      }
      setStatus("Saving selected rows...", "info");
      saveBtn.disabled = true;
      postAjax({
        action: "sdt_bulk_quick_save",
        nonce: SDT_DATA.quickEditNonce,
        rows_json: JSON.stringify(rows)
      }).then(function (res) {
        if (!res || !res.success || !res.data) {
          throw new Error((res && res.data && res.data.message) ? res.data.message : "Bulk save failed.");
        }
        setStatus("Saved " + (res.data.updated_count || rows.length) + " row(s) successfully.", "success");
        return rerunCurrentScan(false).catch(function () {});
      }).catch(function (err) {
        setStatus(err.message || "Bulk save failed.", "error");
      }).finally(function () {
        saveBtn.disabled = false;
      });
    });

    [closeBtn, cancelBtn, backdrop].forEach(function (el) {
      if (!el) return;
      el.addEventListener("click", function () { setOpen(false); });
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !modal.hidden) setOpen(false);
    });
  }
  function init() { renderModuleList(); renderRuleFields(); bindForm(); bindExportSelection(); bindResultSelection(); bindDocumentationToggle(); bindQuickEditModal(); bindBulkQuickEditModal(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
JS;
	}
}

namespace SDT\Analyzers;

if (!defined('ABSPATH')) {
	exit;
}

class ImageOptimizeAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		$maxKb = max(1, (int) ($rules['max_image_kb'] ?? 150));
		$allowed = array_values(array_filter(array_map('strtolower', (array) ($rules['allowed_types'] ?? ['webp']))));
		$requireAlt = !empty($rules['require_alt']);
		$checkFeatured = !empty($rules['check_featured']);
		$checkContent = !array_key_exists('check_content_images', $rules) || !empty($rules['check_content_images']);

		foreach ($posts as $post) {
			$postId = (int) $post->ID;
			$base = self::baseRow($post);
			if ($checkFeatured) {
				$thumbId = (int) get_post_thumbnail_id($postId);
				if ($thumbId > 0) {
					self::evaluateAttachment($rows, $base, $thumbId, 'featured', $maxKb, $allowed, $requireAlt);
				}
			}
			if ($checkContent) {
				$attachmentIds = self::extractContentAttachmentIds((string) $post->post_content);
				foreach ($attachmentIds as $aid) {
					self::evaluateAttachment($rows, $base, (int) $aid, 'content', $maxKb, $allowed, $requireAlt);
				}
			}
		}
		return $rows;
	}

	private static function evaluateAttachment(array &$rows, array $base, int $attachmentId, string $context, int $maxKb, array $allowed, bool $requireAlt): void
	{
		$file = get_attached_file($attachmentId);
		$url = wp_get_attachment_url($attachmentId);
		$mime = get_post_mime_type($attachmentId) ?: '';
		$sizeBytes = ($file && file_exists($file)) ? (int) filesize($file) : 0;
		$sizeKb = $sizeBytes > 0 ? round($sizeBytes / 1024, 2) : 0;
		$ext = strtolower((string) pathinfo((string) $file, PATHINFO_EXTENSION));
		$alt = trim((string) get_post_meta($attachmentId, '_wp_attachment_image_alt', true));
		$expectedTypes = implode(', ', $allowed);
		if ($sizeKb > $maxKb) {
			$rows[] = array_merge($base, ['issue_type' => 'Image too large (' . $context . ')', 'actual_value' => $sizeKb . 'KB', 'expected_value' => '<= ' . $maxKb . 'KB', 'asset_link' => (string) $url]);
		}
		if (!empty($allowed) && !in_array($ext, $allowed, true)) {
			$rows[] = array_merge($base, ['issue_type' => 'Disallowed image type (' . $context . ')', 'actual_value' => $ext !== '' ? $ext . ' (' . $mime . ')' : $mime, 'expected_value' => $expectedTypes, 'asset_link' => (string) $url]);
		}
		if ($requireAlt && $alt === '') {
			$rows[] = array_merge($base, ['issue_type' => 'Missing image alt text (' . $context . ')', 'actual_value' => '(empty)', 'expected_value' => 'Non-empty alt text', 'asset_link' => (string) $url]);
		}
	}

	private static function extractContentAttachmentIds(string $content): array
	{
		$ids = [];
		if ($content === '') return [];
		if (preg_match_all('/wp-image-([0-9]+)/', $content, $m)) {
			foreach ($m[1] as $id) $ids[] = (int) $id;
		}
		return array_values(array_unique(array_filter($ids)));
	}

	private static function baseRow($post): array
	{
		return ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => '', 'actual_value' => '', 'expected_value' => '', 'post_link' => get_permalink($post), 'asset_link' => ''];
	}
}

class ContentAuditAnalyzer
{
	private const OUT_IDS = 'vite_outbound_internal_target_ids';
	private const IN_IDS = 'vite_inbound_internal_source_ids';

	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		$selected = isset($rules['fields']) && is_array($rules['fields']) ? $rules['fields'] : [];
		if (!$selected) {
			$selected = ['post_link'];
		}
		$fieldSet = array_fill_keys($selected, true);
		$contentGraph = self::build_content_link_maps($posts);

		foreach ($posts as $post) {
			$postId = (int) $post->ID;
			$row = [
				'content_id' => $postId,
				'content_type' => (string) $post->post_type,
				'status' => (string) $post->post_status,
			];

			foreach ($selected as $field) {
				switch ($field) {
					case 'post_link':
						$row[$field] = (string) get_permalink($postId);
						break;
					case 'seo_title':
						$row[$field] = trim((string) get_post_meta($postId, 'vite_seo_title', true));
						break;
					case 'seo_meta_description':
						$row[$field] = trim((string) get_post_meta($postId, 'vite_meta_description', true));
						break;
					case 'h1':
					case 'h2':
					case 'h3':
					case 'h4':
						$row[$field] = (string) self::headingValues((string) $post->post_content, (int) substr($field, 1), (string) $post->post_title);
						break;
					case 'slug':
						$row[$field] = (string) $post->post_name;
						break;
					case 'excerpt':
						$row[$field] = (string) $post->post_excerpt;
						break;
					case 'categories':
						$row[$field] = self::termsLine($postId, 'category');
						break;
					case 'tags':
						$row[$field] = self::termsLine($postId, 'post_tag');
						break;
					case 'page_type':
						$row[$field] = trim((string) get_post_meta($postId, 'vite_page_type', true));
						break;
					case 'featured_image':
						$row[$field] = self::featuredImageUrl($postId);
						break;
					case 'featured_image_size_kb':
						$row[$field] = self::featuredImageSizeKb($postId);
						break;
					case 'featured_alt':
						$row[$field] = self::featuredAlt($postId);
						break;
					case 'image_content_urls':
						$row[$field] = implode("\n", self::contentImageUrls((string) $post->post_content));
						break;
					case 'image_content_sizes_kb':
						$row[$field] = implode("\n", self::contentImageSizes((string) $post->post_content));
						break;
					case 'image_content_alt':
						$row[$field] = implode("\n", self::contentImageAlt((string) $post->post_content));
						break;
					case 'inbound':
						$metaInbound = (array) get_post_meta($postId, self::IN_IDS, true);
						$contentInbound = $contentGraph['inbound'][$postId] ?? [];
						$row[$field] = self::resolveLinkedPermalinks(array_values(array_unique(array_merge($metaInbound, $contentInbound))));
						break;
					case 'outbound':
						$metaOutbound = array_values(array_filter(array_map('intval', (array) get_post_meta($postId, self::OUT_IDS, true)), static function (int $id) use ($postId): bool {
							return $id > 0 && $id !== $postId;
						}));
						$contentOutboundUrls = self::normalizeOutboundUrlList((array) ($contentGraph['outbound_urls'][$postId] ?? []));
						if (!empty($contentOutboundUrls)) {
							$allOutboundUrls = $contentOutboundUrls;
						} else {
							$contentOutbound = array_values(array_filter(array_map('intval', (array) ($contentGraph['outbound'][$postId] ?? [])), static function (int $id) use ($postId): bool {
								return $id > 0 && $id !== $postId;
							}));
							$allOutboundUrls = self::normalizeOutboundUrlList(self::resolveLinkedPermalinksArray(array_values(array_unique(array_merge($metaOutbound, $contentOutbound)))));
						}
						$row[$field] = implode("\n", $allOutboundUrls);
						break;
					case 'schema_json_ld':
						$row[$field] = trim((string) get_post_meta($postId, 'vite_schema_jsonld', true));
						break;
					case 'robots':
						$row[$field] = trim((string) get_post_meta($postId, 'vite_meta_robots', true));
						break;
				}
			}

			$rows[] = $row;
		}

		return $rows;
	}

	public static function allFields(): array
	{
		return [
			'post_link', 'seo_title', 'seo_meta_description', 'h1', 'h2', 'h3', 'h4', 'slug', 'excerpt',
			'categories', 'tags', 'page_type', 'featured_image', 'featured_image_size_kb', 'featured_alt',
			'image_content_urls', 'image_content_sizes_kb', 'image_content_alt', 'inbound', 'outbound', 'schema_json_ld', 'robots',
		];
	}

	private static function headingValues(string $content, int $level, string $postTitle = ''): string
	{
		$items = [];
		if ($level === 1 && trim($postTitle) !== '') {
			$items[] = trim($postTitle);
		}
		if (preg_match_all('/<h' . $level . '\b[^>]*>(.*?)<\/h' . $level . '>/is', $content, $m)) {
			foreach ((array) $m[1] as $raw) {
				$text = trim(wp_strip_all_tags((string) html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
				if ($text !== '') {
					$items[] = $text;
				}
			}
		}
		if (empty($items)) {
			return '';
		}
		$normalizedCounts = [];
		foreach ($items as $item) {
			$key = function_exists('mb_strtolower') ? mb_strtolower((string) $item, 'UTF-8') : strtolower((string) $item);
			$key = preg_replace('/\s+/u', ' ', trim((string) $key));
			if ($key === '') {
				continue;
			}
			$normalizedCounts[$key] = ($normalizedCounts[$key] ?? 0) + 1;
		}
		$display = [];
		foreach ($items as $item) {
			$key = function_exists('mb_strtolower') ? mb_strtolower((string) $item, 'UTF-8') : strtolower((string) $item);
			$key = preg_replace('/\s+/u', ' ', trim((string) $key));
			$isDup = $key !== '' && isset($normalizedCounts[$key]) && $normalizedCounts[$key] > 1;
			$display[] = ($isDup ? '__DUP__' : '') . $item;
		}
		return implode("\n", $display);
	}

	private static function termsLine(int $postId, string $taxonomy): string
	{
		$terms = wp_get_post_terms($postId, $taxonomy, ['fields' => 'names']);
		if (is_wp_error($terms) || !is_array($terms) || !$terms) {
			return '';
		}
		return implode("\n", array_map('strval', $terms));
	}

	private static function featuredImageUrl(int $postId): string
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return '';
		}
		return (string) wp_get_attachment_url($thumbId);
	}

	private static function featuredImageSizeKb(int $postId): string
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return '';
		}
		$file = get_attached_file($thumbId);
		if (!$file || !file_exists($file)) {
			return '';
		}
		return (string) round(((int) filesize($file)) / 1024, 2);
	}

	private static function featuredAlt(int $postId): string
	{
		$thumbId = (int) get_post_thumbnail_id($postId);
		if ($thumbId < 1) {
			return '';
		}
		$alt = trim((string) get_post_meta($thumbId, '_wp_attachment_image_alt', true));
		return $alt !== '' ? 'yes' : 'no';
	}

	private static function contentImageUrls(string $content): array
	{
		$out = [];
		if ($content === '') {
			return $out;
		}
		if (preg_match_all('/<img[^>]+src=(["\'])(.*?)\1/i', $content, $m)) {
			foreach ((array) $m[2] as $url) {
				$url = trim((string) $url);
				if ($url !== '') {
					$out[] = $url;
				}
			}
		}
		return array_values(array_unique($out));
	}

	private static function contentImageSizes(string $content): array
	{
		$urls = self::contentImageUrls($content);
		$out = [];
		foreach ($urls as $url) {
			$id = attachment_url_to_postid($url);
			if ($id > 0) {
				$file = get_attached_file($id);
				if ($file && file_exists($file)) {
					$out[] = (string) round(((int) filesize($file)) / 1024, 2);
					continue;
				}
			}
			$out[] = 'N/A';
		}
		return $out;
	}

	private static function contentImageAlt(string $content): array
	{
		$out = [];
		if ($content === '') {
			return $out;
		}
		if (preg_match_all('/<img\b[^>]*>/i', $content, $tags)) {
			foreach ((array) $tags[0] as $tag) {
				$alt = '';
				$attachmentId = 0;
				if (preg_match('/\salt=(["\'])(.*?)\1/i', $tag, $m)) {
					$alt = trim((string) $m[2]);
				}
				if (preg_match('/\sclass=(["\'])(.*?)\1/i', $tag, $classMatch) && preg_match('/wp-image-([0-9]+)/', (string) $classMatch[2], $idMatch)) {
					$attachmentId = (int) $idMatch[1];
				}
				if ($attachmentId < 1 && preg_match('/\ssrc=(["\'])(.*?)\1/i', $tag, $srcMatch)) {
					$src = trim((string) $srcMatch[2]);
					if ($src !== '') {
						$attachmentId = (int) attachment_url_to_postid($src);
					}
				}
				$metaAlt = '';
				if ($attachmentId > 0) {
					$metaAlt = trim((string) get_post_meta($attachmentId, '_wp_attachment_image_alt', true));
				}
				$out[] = ($alt !== '' || $metaAlt !== '') ? 'yes' : 'no';
			}
		}
		return $out;
	}

	private static function resolveLinkedPermalinks(array $ids): string
	{
		return implode("\n", self::resolveLinkedPermalinksArray($ids));
	}

	private static function resolveLinkedPermalinksArray(array $ids): array
	{
		$lines = [];
		foreach ($ids as $id) {
			$id = (int) $id;
			if ($id < 1) {
				continue;
			}
			$url = get_permalink($id);
			if ($url) {
				$lines[] = (string) $url;
			}
		}
		return array_values(array_unique($lines));
	}

	private static function normalizeOutboundUrlList(array $urls): array
	{
		$seen = [];
		foreach ($urls as $rawUrl) {
			$normalized = self::normalizeInternalUrlForCompare((string) $rawUrl);
			if ($normalized === '') {
				continue;
			}
			$seen[$normalized] = $normalized;
		}
		return array_values($seen);
	}

	private static function normalizeInternalUrlForCompare(string $url): string
	{
		$url = trim((string) html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
		if ($url === '') {
			return '';
		}
		$url = preg_replace('/#.*$/', '', $url);
		$parts = wp_parse_url((string) $url);
		if (!is_array($parts)) {
			return '';
		}
		$scheme = isset($parts['scheme']) ? strtolower((string) $parts['scheme']) : '';
		$host = isset($parts['host']) ? strtolower((string) $parts['host']) : '';
		$path = (string) ($parts['path'] ?? '/');
		$path = '/' . ltrim($path, '/');
		if ($path !== '/') {
			$path = rtrim($path, '/');
		}
		$query = isset($parts['query']) && $parts['query'] !== '' ? '?' . (string) $parts['query'] : '';
		if ($scheme !== '' && $host !== '') {
			return $scheme . '://' . $host . $path . $query;
		}
		if ($host !== '') {
			return '//' . $host . $path . $query;
		}
		return $path . $query;
	}

	private static function build_content_link_maps(array $posts): array
	{
		$outbound = [];
		$outboundUrls = [];
		$inbound = [];
		foreach ($posts as $post) {
			if (!$post instanceof \WP_Post) {
				continue;
			}
			$postId = (int) $post->ID;
			if ($postId < 1) {
				continue;
			}
			$linkData = self::extract_internal_links((string) $post->post_content, $postId);
			$targets = $linkData['ids'] ?? [];
			$urls = $linkData['urls'] ?? [];
			$outbound[$postId] = $targets;
			$outboundUrls[$postId] = $urls;
			foreach ($targets as $targetId) {
				$targetId = (int) $targetId;
				if ($targetId < 1) {
					continue;
				}
				if (!isset($inbound[$targetId])) {
					$inbound[$targetId] = [];
				}
				$inbound[$targetId][] = $postId;
			}
		}
		foreach ($inbound as $targetId => $sourceIds) {
			$inbound[$targetId] = array_values(array_unique(array_map('intval', $sourceIds)));
		}
		return [
			'outbound' => $outbound,
			'outbound_urls' => $outboundUrls,
			'inbound' => $inbound,
		];
	}

	private static function extract_internal_links(string $content, int $sourcePostId): array
	{
		if ($content === '') {
			return ['ids' => [], 'urls' => []];
		}
		$home = home_url('/');
		$homeHost = (string) wp_parse_url($home, PHP_URL_HOST);
		$homeScheme = (string) wp_parse_url($home, PHP_URL_SCHEME);
		$ids = [];
		$urls = [];
		if (preg_match_all('/<a\b[^>]*href=(["\'])(.*?)\1/i', $content, $m)) {
			foreach ((array) ($m[2] ?? []) as $hrefRaw) {
				$href = trim((string) html_entity_decode((string) $hrefRaw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
				if ($href === '' || str_starts_with($href, '#')) {
					continue;
				}
				if (preg_match('/^(mailto:|tel:|javascript:)/i', $href)) {
					continue;
				}
				$candidate = $href;
				if (str_starts_with($candidate, '/')) {
					$candidate = home_url($candidate);
				}
				if (!preg_match('#^https?://#i', $candidate)) {
					continue;
				}
				$host = (string) wp_parse_url($candidate, PHP_URL_HOST);
				if ($homeHost !== '' && $host !== '' && strcasecmp($homeHost, $host) !== 0) {
					continue;
				}
				$urls[] = $candidate;
				$scheme = (string) wp_parse_url($candidate, PHP_URL_SCHEME);
				if ($scheme !== '' && $homeScheme !== '' && strcasecmp($scheme, $homeScheme) !== 0) {
					$candidate = preg_replace('#^https?://#i', $homeScheme . '://', $candidate);
				}
				$targetId = (int) url_to_postid($candidate);
				if ($targetId > 0 && $targetId !== $sourcePostId) {
					$ids[] = $targetId;
				}
			}
		}
		$urls = array_values(array_unique(array_filter(array_map('strval', $urls))));
		return [
			'ids' => array_values(array_unique(array_map('intval', $ids))),
			'urls' => $urls,
		];
	}
}

class MissingMetaAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		$titleMin = max(1, (int) ($rules['title_min'] ?? 20));
		$titleMax = max($titleMin, (int) ($rules['title_max'] ?? 60));
		$descMin = max(1, (int) ($rules['meta_desc_min'] ?? 50));
		$descMax = max($descMin, (int) ($rules['meta_desc_max'] ?? 160));
		$seoTitleMap = [];
		$metaMap = [];

		foreach ($posts as $post) {
			$postId = (int) $post->ID;
			$base = self::baseRow($post);
			$seoTitle = trim((string) get_post_meta($postId, 'vite_seo_title', true));
			$titleLen = function_exists('mb_strlen') ? mb_strlen($seoTitle) : strlen($seoTitle);
			$metaDesc = self::metaDescription($postId);
			$descLen = function_exists('mb_strlen') ? mb_strlen($metaDesc) : strlen($metaDesc);
			$titleIssue = ($seoTitle === '' || $titleLen < $titleMin || $titleLen > $titleMax);
			$descIssue = ($metaDesc === '' || $descLen < $descMin || $descLen > $descMax);

			$schema = trim((string) get_post_meta($postId, 'vite_schema_jsonld', true));
			$robots = trim((string) get_post_meta($postId, 'vite_meta_robots', true));
			$slug = trim((string) $post->post_name);

			$issueType = [];
			if ($titleIssue) {
				$issueType[] = 'SEO title length/missing issue';
			}
			if ($descIssue) {
				$issueType[] = 'Meta description length/missing issue';
			}
			if ($schema === '') {
				$issueType[] = 'Schema JSON-LD missing';
			}
			if ($robots === '') {
				$issueType[] = 'Robots value missing';
			}
			if ($slug === '') {
				$issueType[] = 'Slug missing';
			}
			if (!empty($issueType)) {
				$rows[] = array_merge($base, [
					'issue_type' => implode(' + ', $issueType),
					'actual_value' => 'SEO Title: ' . $titleLen . ' chars | Meta: ' . $descLen . ' chars | Schema: ' . ($schema !== '' ? 'set' : 'empty') . ' | Robots: ' . ($robots !== '' ? $robots : 'empty') . ' | Slug: ' . ($slug !== '' ? $slug : 'empty'),
					'expected_value' => 'SEO Title: ' . $titleMin . '-' . $titleMax . ' | Meta: ' . $descMin . '-' . $descMax . ' | Schema: set | Robots: set | Slug: set',
				]);
			}

			$seoTitleKey = self::normalize($seoTitle);
			if ($seoTitleKey !== '') {
				$seoTitleMap[$seoTitleKey][] = $post;
			}
			$metaKey = self::normalize($metaDesc);
			if ($metaKey !== '') {
				$metaMap[$metaKey][] = $post;
			}
		}

		foreach ($seoTitleMap as $value => $items) {
			if (count($items) < 2) {
				continue;
			}
			$ids = implode(', ', array_map(static fn($p) => (string) $p->ID, $items));
			foreach ($items as $post) {
				$rows[] = array_merge(self::baseRow($post), [
					'issue_type' => 'Duplicate SEO title',
					'actual_value' => $value,
					'expected_value' => 'Unique SEO title (duplicates with IDs: ' . $ids . ')',
				]);
			}
		}
		foreach ($metaMap as $value => $items) {
			if (count($items) < 2) {
				continue;
			}
			$ids = implode(', ', array_map(static fn($p) => (string) $p->ID, $items));
			foreach ($items as $post) {
				$rows[] = array_merge(self::baseRow($post), [
					'issue_type' => 'Duplicate meta description',
					'actual_value' => $value,
					'expected_value' => 'Unique meta description (duplicates with IDs: ' . $ids . ')',
				]);
			}
		}
		return $rows;
	}

	private static function metaDescription(int $postId): string
	{
		return trim((string) get_post_meta($postId, 'vite_meta_description', true));
	}

	private static function normalize(string $text): string
	{
		$text = wp_strip_all_tags($text);
		return trim((string) preg_replace('/\s+/', ' ', strtolower($text)));
	}

	private static function baseRow($post): array
	{
		return ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => '', 'actual_value' => '', 'expected_value' => '', 'post_link' => get_permalink($post), 'asset_link' => ''];
	}
}

class HeadingStructureAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		foreach ($posts as $post) {
			$content = (string) $post->post_content;
			if ($content === '') continue;
			$title = trim((string) get_the_title($post));
			$levels = [];
			if (preg_match_all('/<h([1-6])\b/i', $content, $m)) {
				foreach ($m[1] as $lvl) $levels[] = (int) $lvl;
			}
			$base = self::baseRow($post);
			$h1Count = count(array_filter($levels, static fn($x) => $x === 1));
			// Treat post title as acceptable primary heading for this workflow.
			if ($h1Count === 0 && $title === '') $rows[] = array_merge($base, ['issue_type' => 'Missing H1', 'actual_value' => '0', 'expected_value' => 'Exactly 1 H1']);
			if ($h1Count > 1) $rows[] = array_merge($base, ['issue_type' => 'Multiple H1 tags', 'actual_value' => (string) $h1Count, 'expected_value' => 'Exactly 1 H1']);
			for ($i = 1; $i < count($levels); $i++) {
				$prev = $levels[$i - 1]; $curr = $levels[$i];
				if (($curr - $prev) > 1) {
					$rows[] = array_merge($base, ['issue_type' => 'Heading level jump', 'actual_value' => 'H' . $prev . ' -> H' . $curr, 'expected_value' => 'No jump greater than 1 level']);
					break;
				}
			}
		}
		return $rows;
	}
	private static function baseRow($post): array
	{
		return ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => '', 'actual_value' => '', 'expected_value' => '', 'post_link' => get_permalink($post), 'asset_link' => ''];
	}
}

class BrokenInternalLinksAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		$homeHost = wp_parse_url(home_url('/'), PHP_URL_HOST);
		foreach ($posts as $post) {
			$content = (string) $post->post_content;
			if ($content === '') continue;
			if (!preg_match_all('/<a[^>]+href=(["\'])(.*?)\1/i', $content, $m)) continue;
			$links = array_values(array_unique($m[2]));
			$base = self::baseRow($post);
			foreach ($links as $href) {
				$href = trim((string) $href);
				if ($href === '' || strpos($href, '#') === 0 || strpos($href, 'mailto:') === 0 || strpos($href, 'tel:') === 0) continue;
				$urlParts = wp_parse_url($href);
				$isInternal = empty($urlParts['host']) ? strpos($href, '/') === 0 : (strcasecmp((string) $urlParts['host'], (string) $homeHost) === 0);
				if (!$isInternal) continue;
				$absolute = empty($urlParts['host']) ? home_url($href) : $href;
				$path = rtrim((string) (wp_parse_url($absolute, PHP_URL_PATH) ?: ''), '/');
				if ($path === '') continue;
				$postId = url_to_postid($absolute);
				if ((int) $postId > 0) continue;
				$rows[] = array_merge($base, ['issue_type' => 'Potential broken internal link', 'actual_value' => $absolute, 'expected_value' => 'Resolvable internal URL', 'asset_link' => $absolute]);
			}
		}
		return $rows;
	}
	private static function baseRow($post): array
	{
		return ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => '', 'actual_value' => '', 'expected_value' => '', 'post_link' => get_permalink($post), 'asset_link' => ''];
	}
}

class IndexabilityAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		foreach ($posts as $post) {
			$base = self::baseRow($post);
			$postId = (int) $post->ID;
			$status = (string) $post->post_status;
			if ($status !== 'publish') $rows[] = array_merge($base, ['issue_type' => 'Not publicly indexable status', 'actual_value' => $status, 'expected_value' => 'publish']);
			$yoastNoindex = (string) get_post_meta($postId, '_yoast_wpseo_meta-robots-noindex', true);
			if ($yoastNoindex === '1') $rows[] = array_merge($base, ['issue_type' => 'Noindex flag detected (Yoast)', 'actual_value' => 'noindex=1', 'expected_value' => 'index']);
			$rankMathRobots = get_post_meta($postId, 'rank_math_robots', true);
			if (is_array($rankMathRobots) && in_array('noindex', $rankMathRobots, true)) $rows[] = array_merge($base, ['issue_type' => 'Noindex flag detected (Rank Math)', 'actual_value' => 'contains noindex', 'expected_value' => 'index']);
		}
		return $rows;
	}
	private static function baseRow($post): array
	{
		return ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => '', 'actual_value' => '', 'expected_value' => '', 'post_link' => get_permalink($post), 'asset_link' => ''];
	}
}

class SchemaPresenceAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		foreach ($posts as $post) {
			$content = (string) $post->post_content;
			$hasInlineJsonLd = stripos($content, 'application/ld+json') !== false;
			$postId = (int) $post->ID;
			$yoastSchema = get_post_meta($postId, '_yoast_wpseo_schema_page_type', true);
			$rankMathSchema = get_post_meta($postId, 'rank_math_rich_snippet', true);
			$viteSchema = trim((string) get_post_meta($postId, 'vite_schema_jsonld', true));
			$hasPluginSchemaHints = !empty($yoastSchema) || !empty($rankMathSchema) || $viteSchema !== '';
			if (!$hasInlineJsonLd && !$hasPluginSchemaHints) {
				$rows[] = ['content_id' => $postId, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => 'No schema signal detected', 'actual_value' => 'No inline JSON-LD, no SEO plugin schema hint, and no vite_schema_jsonld value', 'expected_value' => 'At least one schema signal', 'post_link' => get_permalink($post), 'asset_link' => ''];
			}
		}
		return $rows;
	}
}

class DuplicateContentAnalyzer
{
	public static function analyze(array $posts, array $rules): array
	{
		$rows = [];
		$titleMap = [];
		$metaMap = [];
		foreach ($posts as $post) {
			$postId = (int) $post->ID;
			$titleKey = self::normalize((string) get_the_title($post));
			if ($titleKey !== '') $titleMap[$titleKey][] = $post;
			$metaDesc = self::metaDescription($postId, (string) $post->post_excerpt);
			$metaKey = self::normalize($metaDesc);
			if ($metaKey !== '') $metaMap[$metaKey][] = $post;
		}
		foreach ($titleMap as $title => $items) {
			if (count($items) < 2) continue;
			$ids = implode(', ', array_map(static fn($p) => (string) $p->ID, $items));
			foreach ($items as $post) {
				$rows[] = ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => 'Duplicate title', 'actual_value' => $title, 'expected_value' => 'Unique title (duplicates with IDs: ' . $ids . ')', 'post_link' => get_permalink($post), 'asset_link' => ''];
			}
		}
		foreach ($metaMap as $meta => $items) {
			if (count($items) < 2) continue;
			$ids = implode(', ', array_map(static fn($p) => (string) $p->ID, $items));
			foreach ($items as $post) {
				$rows[] = ['content_id' => (int) $post->ID, 'content_title' => get_the_title($post), 'content_type' => (string) $post->post_type, 'status' => (string) $post->post_status, 'issue_type' => 'Duplicate meta description', 'actual_value' => $meta, 'expected_value' => 'Unique meta description (duplicates with IDs: ' . $ids . ')', 'post_link' => get_permalink($post), 'asset_link' => ''];
			}
		}
		return $rows;
	}
	private static function metaDescription(int $postId, string $fallbackExcerpt): string
	{
		$yoast = trim((string) get_post_meta($postId, '_yoast_wpseo_metadesc', true));
		if ($yoast !== '') return $yoast;
		$rankMath = trim((string) get_post_meta($postId, 'rank_math_description', true));
		if ($rankMath !== '') return $rankMath;
		return trim($fallbackExcerpt);
	}
	private static function normalize(string $text): string
	{
		$text = wp_strip_all_tags($text);
		return trim((string) preg_replace('/\s+/', ' ', strtolower($text)));
	}
}

namespace SDT;

add_action('plugins_loaded', static function () {
	AdminPage::boot();
});

