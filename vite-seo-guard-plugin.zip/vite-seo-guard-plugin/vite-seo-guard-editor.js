
(function (wp) {
    const { registerPlugin } = wp.plugins;
    const { PluginDocumentSettingPanel } = wp.editPost;
    const { TextControl, TextareaControl, Notice, SelectControl } = wp.components;
    const { useSelect, useDispatch } = wp.data;
    const { useMemo } = wp.element;
  
    const META = (window.VITE_SEO_GUARD && window.VITE_SEO_GUARD.meta) || {};
  
    function safeTrim(v) {
      return (v || "").toString().trim();
    }
  
    function validateJson(raw) {
      const t = safeTrim(raw);
      if (!t) return { ok: false, reason: "missing" };
      try {
        JSON.parse(t);
        return { ok: true };
      } catch (e) {
        return { ok: false, reason: "invalid" };
      }
    }
  
    function SeoGuardPanel() {
      const postType = useSelect((select) => select("core/editor").getCurrentPostType(), []);
      const meta = useSelect((select) => select("core/editor").getEditedPostAttribute("meta") || {}, []);
      const { editPost } = useDispatch("core/editor");
  
      const seoTitle = safeTrim(meta[META.title]);
      const seoDesc = safeTrim(meta[META.desc]);
      const schemaRaw = (meta[META.schema] || "").toString();
      const robots = safeTrim(meta[META.robots]);
      const schemaCheck = useMemo(() => validateJson(schemaRaw), [schemaRaw]);
  
      if (postType !== "post") return null;

      const hasAnyValue = seoTitle || seoDesc || safeTrim(schemaRaw) || robots;
      const hasInvalidJson = !schemaCheck.ok && schemaCheck.reason === "invalid";
  
      return wp.element.createElement(
          PluginDocumentSettingPanel,
          { name: "vite-seo-guard", title: "SEO (Optional)", className: "vite-seo-guard" },
          hasInvalidJson
            ? wp.element.createElement(
                Notice,
                { status: "warning", isDismissible: false },
                "Schema JSON-LD is invalid JSON. You can still publish, but fix this when ready."
              )
            : wp.element.createElement(
                Notice,
                { status: "info", isDismissible: false },
                hasAnyValue
                  ? "SEO fields are optional. If left blank, WordPress/default theme output is used."
                  : "SEO fields are optional. You can publish now and fill these later."
              ),
  
          wp.element.createElement(TextControl, {
            label: "SEO Title (optional)",
            value: seoTitle,
            onChange: (v) => editPost({ meta: { [META.title]: v } }),
          }),
  
          wp.element.createElement(TextareaControl, {
            label: "Meta Description (optional)",
            value: seoDesc,
            onChange: (v) => editPost({ meta: { [META.desc]: v } }),
            help: "Recommended ~120–160 chars.",
          }),
  
          wp.element.createElement(TextareaControl, {
            label: "Schema JSON-LD (optional, JSON only)",
            value: schemaRaw,
            onChange: (v) => editPost({ meta: { [META.schema]: v } }),
            help:
              schemaCheck.ok
                ? "JSON looks valid."
                : schemaCheck.reason === "invalid"
                ? "Invalid JSON. Publishing is allowed, but fix quotes/commas/brackets."
                : "Leave blank for now and add later.",
          }),

          wp.element.createElement(SelectControl, {
            label: "Meta Robots (optional)",
            value: robots,
            options: [
              { label: "Use default (theme/global)", value: "" },
              { label: "index, follow", value: "index,follow" },
              { label: "noindex, follow", value: "noindex,follow" },
              { label: "index, nofollow", value: "index,nofollow" },
              { label: "noindex, nofollow", value: "noindex,nofollow" },
            ],
            onChange: (v) => editPost({ meta: { [META.robots]: v } }),
            help: "Applies to this blog post only when selected.",
          })
      );
    }
  
    registerPlugin("vite-seo-guard", { render: SeoGuardPanel });
  })(window.wp);
