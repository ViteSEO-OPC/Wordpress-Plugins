<?php
/**
 * Plugin Name: Vite SEO Guard (Posts)
 * Description: Requires SEO Title, Meta Description, and Schema JSON-LD before publishing blog posts. Adds editor UI + front-end output.
 * Author: Vite SEO
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('vite_render_seo_tools_landing')) {
	function vite_render_seo_tools_landing(): void {
		echo '<div class="wrap"><h1>SEO Tools</h1><p>Use the submenu items to open each SEO tool.</p></div>';
	}
}

if (!function_exists('vite_register_seo_tools_menu')) {
	function vite_register_seo_tools_menu(): void {
		static $added = false;
		if ($added) {
			return;
		}

		add_menu_page(
			'SEO Tools',
			'SEO Tools',
			'edit_posts',
			'vite-seo-tools',
			'vite_render_seo_tools_landing',
			'dashicons-chart-area',
			58
		);

		$added = true;
	}
}

final class Vite_SEO_Guard {
	const META_TITLE  = 'vite_seo_title';
	const META_DESC   = 'vite_meta_description';
	const META_SCHEMA = 'vite_schema_jsonld';
	const META_ROBOTS = 'vite_meta_robots';
	const TOOLS_PAGE_SLUG = 'vite-seo-guard';
	const TOOLS_PER_PAGE = 25;

	public static function init(): void {
		add_action('init', [__CLASS__, 'register_meta']);
		add_action('enqueue_block_editor_assets', [__CLASS__, 'enqueue_editor']);
		add_action('admin_menu', [__CLASS__, 'register_tools_page']);
		add_action('wp_ajax_vite_seo_guard_get_row', [__CLASS__, 'ajax_get_row']);
		add_action('wp_ajax_vite_seo_guard_save_row', [__CLASS__, 'ajax_save_row']);
		add_action('wp_ajax_vite_seo_guard_live_search', [__CLASS__, 'ajax_live_search']);
		add_action('wp_ajax_vite_seo_guard_bulk_get', [__CLASS__, 'ajax_bulk_get']);
		add_action('wp_ajax_vite_seo_guard_bulk_save', [__CLASS__, 'ajax_bulk_save']);
		add_action('admin_post_vite_seo_guard_download_selected', [__CLASS__, 'handle_download_selected']);

		// Front-end output (blog posts only)
		add_filter('pre_get_document_title', [__CLASS__, 'filter_document_title'], 20);
		add_action('wp_head', [__CLASS__, 'output_meta_description'], 1);
		add_action('wp_head', [__CLASS__, 'output_meta_robots'], 2);
		add_action('wp_head', [__CLASS__, 'output_schema_jsonld'], 20);
	}

	public static function sanitize_meta_robots($value): string {
		$value = strtolower(trim((string) $value));
		$allowed = [
			'',
			'index,follow',
			'noindex,follow',
			'index,nofollow',
			'noindex,nofollow',
		];
		return in_array($value, $allowed, true) ? $value : '';
	}

	private static function normalize_schema_json(string $raw): array {
		$value = trim(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
		if ($value === '') {
			return ['ok' => true, 'json' => ''];
		}

		$candidate = $value;
		if (preg_match('~<script[^>]*application/ld\+json[^>]*>(.*?)</script>~is', $value, $m)) {
			$candidate = trim((string) ($m[1] ?? ''));
		}
		$candidate = trim($candidate);
		if ($candidate === '') {
			return ['ok' => false, 'json' => '', 'message' => 'Schema JSON-LD is empty after removing script wrapper.'];
		}

		$decoded = json_decode($candidate, true);
		if (!is_array($decoded)) {
			$first = strpos($candidate, '{');
			$last = strrpos($candidate, '}');
			if ($first !== false && $last !== false && $last > $first) {
				$extracted = substr($candidate, $first, $last - $first + 1);
				$decoded = json_decode($extracted, true);
			}
		}
		if (!is_array($decoded)) {
			return ['ok' => false, 'json' => '', 'message' => 'Schema JSON-LD is invalid JSON.'];
		}

		$normalized = wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if (!is_string($normalized) || trim($normalized) === '') {
			return ['ok' => false, 'json' => '', 'message' => 'Schema JSON-LD could not be normalized.'];
		}
		return ['ok' => true, 'json' => $normalized];
	}

	public static function sanitize_schema_meta($value): string {
		$normalized = self::normalize_schema_json((string) $value);
		return $normalized['ok'] ? (string) $normalized['json'] : '';
	}

	public static function register_meta(): void {
		$auth = function() { return current_user_can('edit_posts'); };

		register_post_meta('post', self::META_TITLE, [
			'type' => 'string',
			'single' => true,
			'show_in_rest' => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback' => $auth,
		]);

		register_post_meta('post', self::META_DESC, [
			'type' => 'string',
			'single' => true,
			'show_in_rest' => true,
			'sanitize_callback' => 'sanitize_textarea_field',
			'auth_callback' => $auth,
		]);

		register_post_meta('post', self::META_SCHEMA, [
			'type' => 'string',
			'single' => true,
			'show_in_rest' => true,
			'sanitize_callback' => [__CLASS__, 'sanitize_schema_meta'],
			'auth_callback' => $auth,
		]);

		register_post_meta('post', self::META_ROBOTS, [
			'type' => 'string',
			'single' => true,
			'show_in_rest' => true,
			'sanitize_callback' => [__CLASS__, 'sanitize_meta_robots'],
			'auth_callback' => $auth,
		]);
	}

	public static function enqueue_editor(): void {
		if (!function_exists('get_current_screen')) return;
		$screen = get_current_screen();
		if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'post') return;

		$src = plugin_dir_url(__FILE__) . 'vite-seo-guard-editor.js';

		wp_enqueue_script(
			'vite-seo-guard-editor',
			$src,
			['wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-i18n'],
			filemtime(__DIR__ . '/vite-seo-guard-editor.js'),
			true
		);

		wp_add_inline_script(
			'vite-seo-guard-editor',
			'window.VITE_SEO_GUARD = ' . wp_json_encode([
				'meta' => [
					'title'  => self::META_TITLE,
					'desc'   => self::META_DESC,
					'schema' => self::META_SCHEMA,
					'robots' => self::META_ROBOTS,
				],
			]) . ';',
			'before'
		);
	}

	public static function filter_document_title(string $title): string {
		if (!is_singular('post')) return $title;

		$seo = (string) get_post_meta(get_queried_object_id(), self::META_TITLE, true);
		$seo = trim($seo);
		return $seo !== '' ? $seo : $title;
	}

	public static function output_meta_description(): void {
		if (!is_singular('post')) return;

		$desc = (string) get_post_meta(get_queried_object_id(), self::META_DESC, true);
		$desc = trim($desc);
		if ($desc === '') return;

		echo "<meta name=\"description\" content=\"" . esc_attr($desc) . "\">\n";
	}

	public static function output_meta_robots(): void {
		if (!is_singular('post')) return;

		$robots = (string) get_post_meta(get_queried_object_id(), self::META_ROBOTS, true);
		$robots = self::sanitize_meta_robots($robots);
		if ($robots === '') return;

		echo "<meta name=\"robots\" content=\"" . esc_attr($robots) . "\">\n";
	}

	public static function output_schema_jsonld(): void {
		if (!is_singular('post')) return;

		$raw = (string) get_post_meta(get_queried_object_id(), self::META_SCHEMA, true);
		$normalized = self::normalize_schema_json($raw);
		if (!$normalized['ok']) return;
		$json = (string) $normalized['json'];
		if ($json === '') return;

		$data = json_decode($json, true);
		if (!is_array($data)) return;

		echo "\n<script type=\"application/ld+json\">"
			. wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
			. "</script>\n";
	}

	public static function register_tools_page(): void {
		vite_register_seo_tools_menu();
		add_submenu_page(
			'vite-seo-tools',
			'SEO Guard',
			'SEO Guard',
			'edit_posts',
			self::TOOLS_PAGE_SLUG,
			[__CLASS__, 'render_tools_page']
		);
	}

	private static function sanitize_month_filter(string $value): string {
		$value = trim($value);
		if ($value === '') {
			return '';
		}
		if (!preg_match('/^\d{4}-\d{2}$/', $value)) {
			return '';
		}
		return $value;
	}

	private static function sanitize_date_filter(string $value): string {
		$value = trim($value);
		if ($value === '') {
			return '';
		}
		if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
			return '';
		}
		return $value;
	}

	private static function sanitize_sort_filter(string $value): string {
		$allowed = ['date_desc', 'date_asc', 'id_desc', 'id_asc', 'title_asc', 'title_desc'];
		return in_array($value, $allowed, true) ? $value : 'date_desc';
	}

	private static function build_date_query(string $month, string $date_from, string $date_to): array {
		if ($month !== '') {
			$parts = explode('-', $month);
			$year = isset($parts[0]) ? (int) $parts[0] : 0;
			$month_num = isset($parts[1]) ? (int) $parts[1] : 0;
			if ($year > 0 && $month_num >= 1 && $month_num <= 12) {
				return [[
					'year' => $year,
					'monthnum' => $month_num,
				]];
			}
		}

		if ($date_from !== '' || $date_to !== '') {
			$rule = ['inclusive' => true];
			if ($date_from !== '') {
				$rule['after'] = $date_from;
			}
			if ($date_to !== '') {
				$rule['before'] = $date_to;
			}
			return [$rule];
		}

		return [];
	}

	private static function build_query_args(string $search, int $paged, string $month, string $date_from, string $date_to, string $sort): array {
		$args = [
			'post_type' => 'post',
			'post_status' => ['publish', 'draft', 'pending', 'future', 'private'],
			'paged' => max(1, $paged),
			's' => $search,
			'search_columns' => ['post_title'],
			'no_found_rows' => false,
		];

		// Month/range mode should show all matching posts.
		$has_date_filter = ($month !== '' || $date_from !== '' || $date_to !== '');
		$args['posts_per_page'] = $has_date_filter ? -1 : self::TOOLS_PER_PAGE;
		if ($has_date_filter) {
			$args['paged'] = 1;
		}

		$date_query = self::build_date_query($month, $date_from, $date_to);
		if ($date_query) {
			$args['date_query'] = $date_query;
		}

		switch ($sort) {
			case 'id_asc':
				$args['orderby'] = 'ID';
				$args['order'] = 'ASC';
				break;
			case 'id_desc':
				$args['orderby'] = 'ID';
				$args['order'] = 'DESC';
				break;
			case 'title_asc':
				$args['orderby'] = 'title';
				$args['order'] = 'ASC';
				break;
			case 'title_desc':
				$args['orderby'] = 'title';
				$args['order'] = 'DESC';
				break;
			case 'date_asc':
				$args['orderby'] = 'date';
				$args['order'] = 'ASC';
				break;
			case 'date_desc':
			default:
				$args['orderby'] = 'date';
				$args['order'] = 'DESC';
				break;
		}

		return $args;
	}

	public static function render_tools_page(): void {
		if (!current_user_can('edit_posts')) {
			wp_die('Forbidden');
		}

		self::render_admin_styles();

		$paged = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
		$search = isset($_GET['seo_guard_search']) ? sanitize_text_field((string) $_GET['seo_guard_search']) : '';
		$month = isset($_GET['seo_guard_month']) ? self::sanitize_month_filter((string) $_GET['seo_guard_month']) : '';
		$date_from = isset($_GET['seo_guard_date_from']) ? self::sanitize_date_filter((string) $_GET['seo_guard_date_from']) : '';
		$date_to = isset($_GET['seo_guard_date_to']) ? self::sanitize_date_filter((string) $_GET['seo_guard_date_to']) : '';
		$sort = isset($_GET['seo_guard_sort']) ? self::sanitize_sort_filter((string) $_GET['seo_guard_sort']) : 'date_desc';
		$query = new WP_Query(self::build_query_args($search, $paged, $month, $date_from, $date_to, $sort));

		$total_pages = max(1, (int) $query->max_num_pages);
		$total_items = (int) $query->found_posts;
		$has_date_filter = ($month !== '' || $date_from !== '' || $date_to !== '');
		$effective_page_size = $has_date_filter ? max(1, $total_items) : self::TOOLS_PER_PAGE;
		$effective_paged = $has_date_filter ? 1 : $paged;
		$start_num = $total_items > 0 ? (($effective_paged - 1) * $effective_page_size + 1) : 0;
		$end_num = min($total_items, $effective_paged * $effective_page_size);

		echo '<div class="wrap vite-seo-guard-page">';
		echo '<div class="vite-seo-guard-page__header">';
		echo '<h1 style="margin:0;">SEO Guard</h1>';
		echo '</div>';

		self::render_docs_modal();
		self::render_quick_edit_modal();
		self::render_bulk_quick_edit_modal();

		echo '<div class="vite-seo-guard-card">';
		echo '<p>This page helps your team review SEO fields for blog posts in one place.</p>';
		echo '<form method="get" class="vite-seo-guard-search-form">';
		echo '<input type="hidden" name="page" value="' . esc_attr(self::TOOLS_PAGE_SLUG) . '" />';
		echo '<label for="vite-seo-guard-search" class="screen-reader-text">Search posts</label>';
		echo '<input id="vite-seo-guard-search" class="vite-seo-guard-search-input" type="search" name="seo_guard_search" value="' . esc_attr($search) . '" placeholder="Search by post title only..." />';
		echo '<label for="vite-seo-guard-month" class="screen-reader-text">Filter by month</label>';
		echo '<input id="vite-seo-guard-month" type="month" name="seo_guard_month" value="' . esc_attr($month) . '" />';
		echo '<label for="vite-seo-guard-date-from" class="screen-reader-text">Date from</label>';
		echo '<input id="vite-seo-guard-date-from" type="date" name="seo_guard_date_from" value="' . esc_attr($date_from) . '" />';
		echo '<label for="vite-seo-guard-date-to" class="screen-reader-text">Date to</label>';
		echo '<input id="vite-seo-guard-date-to" type="date" name="seo_guard_date_to" value="' . esc_attr($date_to) . '" />';
		echo '<label for="vite-seo-guard-sort" class="screen-reader-text">Sort</label>';
		echo '<select id="vite-seo-guard-sort" name="seo_guard_sort">';
		echo '<option value="date_desc"' . selected($sort, 'date_desc', false) . '>Newest first</option>';
		echo '<option value="date_asc"' . selected($sort, 'date_asc', false) . '>Oldest first</option>';
		echo '<option value="id_desc"' . selected($sort, 'id_desc', false) . '>ID high to low</option>';
		echo '<option value="id_asc"' . selected($sort, 'id_asc', false) . '>ID low to high</option>';
		echo '<option value="title_asc"' . selected($sort, 'title_asc', false) . '>Title A-Z</option>';
		echo '<option value="title_desc"' . selected($sort, 'title_desc', false) . '>Title Z-A</option>';
		echo '</select>';
		echo '<button type="submit" class="button button-secondary">Search</button>';
		if ($search !== '' || $month !== '' || $date_from !== '' || $date_to !== '' || $sort !== 'date_desc') {
			$clear_url = add_query_arg(['page' => self::TOOLS_PAGE_SLUG], admin_url('admin.php'));
			echo '<a class="button" href="' . esc_url($clear_url) . '">Clear</a>';
		}
		echo '</form>';
		echo '<p class="description" style="margin-top:0;">Live search is on. Results refresh while you type.</p>';
		echo '<p id="vite-seo-guard-showing"><strong>Showing:</strong> ' . esc_html((string) $start_num) . ' - ' . esc_html((string) $end_num) . ' of ' . esc_html((string) $total_items) . ' posts</p>';
		if ($search !== '') {
			echo '<p class="description" id="vite-seo-guard-search-label"><strong>Search:</strong> ' . esc_html($search) . '</p>';
		} else {
			echo '<p class="description" id="vite-seo-guard-search-label" hidden></p>';
		}
		echo '</div>';

		echo '<div class="vite-seo-guard-card">';
		echo '<div class="vite-seo-guard-overview-header">';
		echo '<h2 style="margin:0;">SEO Post Overview</h2>';
		echo '<button type="button" class="button vite-seo-guard-guide-btn" id="vite-seo-guard-open-guide" aria-haspopup="dialog" aria-controls="vite-seo-guard-guide-modal">Open Guide</button>';
		echo '</div>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="vite-seo-guard-bulk-form">';
		wp_nonce_field('vite_seo_guard_download_selected');
		echo '<input type="hidden" name="action" value="vite_seo_guard_download_selected" />';
		echo '<p class="vite-seo-guard-bulk-actions">';
		echo '<button type="submit" class="button button-secondary">Download Selected</button>';
		echo '<button type="button" class="button button-primary" id="vite-seo-guard-bulk-edit-open">Quick Edit Selected</button>';
		echo '<span class="description">Select rows, then download a CSV for only those posts.</span>';
		echo '</p>';
		echo '<table class="widefat striped vite-seo-guard-table">';
		echo '<thead><tr>';
		echo '<th style="width:70px;">Post ID</th>';
		echo '<th style="width:36px;"><input type="checkbox" id="vite-seo-guard-select-all" aria-label="Select all posts" /></th>';
		echo '<th style="width:22%;">Post Title</th>';
		echo '<th style="width:18%;">SEO Title</th>';
		echo '<th style="width:20%;">Meta Description</th>';
		echo '<th style="width:5%;">Schema JSON-LD</th>';
		echo '<th style="width:10%;">Robots</th>';
		echo '<th style="width:20%;">Links</th>';
		echo '</tr></thead>';
		echo '<tbody id="vite-seo-guard-table-body">';
		echo self::render_table_rows($query->posts);
		echo '</tbody></table>';
		echo '</form>';

		echo '</div>';

		echo self::render_pagination($effective_paged, $total_pages, $search, $month, $date_from, $date_to, $sort);
		echo '<script>
		(function () {
			document.addEventListener("DOMContentLoaded", function () {
				var searchInput = document.getElementById("vite-seo-guard-search");
				var monthInput = document.getElementById("vite-seo-guard-month");
				var dateFromInput = document.getElementById("vite-seo-guard-date-from");
				var dateToInput = document.getElementById("vite-seo-guard-date-to");
				var sortInput = document.getElementById("vite-seo-guard-sort");
				var searchForm = searchInput ? searchInput.form : null;
				var tableBody = document.getElementById("vite-seo-guard-table-body");
				var showing = document.getElementById("vite-seo-guard-showing");
				var searchLabel = document.getElementById("vite-seo-guard-search-label");
				var pagination = document.querySelector(".vite-seo-guard-pagination");
				var liveNonce = ' . wp_json_encode(wp_create_nonce('vite_seo_guard_live_search')) . ';
				var liveTimer = null;
				var liveRequestId = 0;

				function bindSelectionControls() {
					var selectAll = document.getElementById("vite-seo-guard-select-all");
					var rowChecks = Array.prototype.slice.call(document.querySelectorAll(".vite-seo-guard-row-check"));
					if (!selectAll) return;
					function syncSelectAllState() {
						if (!rowChecks.length) {
							selectAll.checked = false;
							selectAll.indeterminate = false;
							return;
						}
						var checkedCount = rowChecks.filter(function (cb) { return cb.checked; }).length;
						selectAll.checked = checkedCount === rowChecks.length;
						selectAll.indeterminate = checkedCount > 0 && checkedCount < rowChecks.length;
					}
					selectAll.onchange = function () {
						rowChecks.forEach(function (cb) { cb.checked = selectAll.checked; });
						syncSelectAllState();
					};
					rowChecks.forEach(function (cb) {
						cb.onchange = syncSelectAllState;
					});
					syncSelectAllState();
				}

				function postAjax(payload) {
					return fetch(ajaxurl, {
						method: "POST",
						headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
						body: new URLSearchParams(payload)
					}).then(function (r) { return r.json(); });
				}

				function runLiveSearch() {
					if (!searchInput || !tableBody || !showing || !searchLabel) return;
					var currentRequestId = ++liveRequestId;
					var value = searchInput.value || "";
					postAjax({
						action: "vite_seo_guard_live_search",
						nonce: liveNonce,
						search: value,
						month: monthInput ? monthInput.value : "",
						date_from: dateFromInput ? dateFromInput.value : "",
						date_to: dateToInput ? dateToInput.value : "",
						sort: sortInput ? sortInput.value : "date_desc"
					}).then(function (res) {
						if (currentRequestId !== liveRequestId) return;
						if (!res || !res.success || !res.data) return;
						tableBody.innerHTML = res.data.rows_html || "";
						showing.innerHTML = "<strong>Showing:</strong> " + res.data.start_num + " - " + res.data.end_num + " of " + res.data.total_items + " posts";
						if (res.data.search && String(res.data.search).trim() !== "") {
							searchLabel.hidden = false;
							searchLabel.innerHTML = "<strong>Search:</strong> " + (res.data.search_label || res.data.search);
						} else {
							searchLabel.hidden = true;
							searchLabel.innerHTML = "";
						}
						if (pagination) pagination.style.display = "none";
						bindSelectionControls();
					}).catch(function () {
						// keep current rows on request errors
					});
				}

				if (searchInput) {
					searchInput.addEventListener("input", function () {
						if (liveTimer) window.clearTimeout(liveTimer);
						liveTimer = window.setTimeout(runLiveSearch, 300);
					});
				}
				[monthInput, dateFromInput, dateToInput, sortInput].forEach(function (input) {
					if (!input) return;
					input.addEventListener("change", function () {
						if (liveTimer) window.clearTimeout(liveTimer);
						runLiveSearch();
					});
				});
				if (searchForm) {
					searchForm.addEventListener("submit", function (event) {
						event.preventDefault();
						runLiveSearch();
					});
				}

				bindSelectionControls();
			});
		})();
		</script>';
		echo '</div>';

		wp_reset_postdata();
	}

	private static function render_table_value(string $value): string {
		if ($value === '') {
			return '<span class="vite-seo-guard-empty">Empty</span>';
		}
		$short = mb_substr($value, 0, 140);
		if (mb_strlen($value) > 140) {
			$short .= '...';
		}
		return esc_html($short);
	}

	private static function render_table_rows(array $posts): string {
		if (!$posts) {
			return '<tr><td colspan="8">No posts found.</td></tr>';
		}

		$html = '';
		foreach ($posts as $post) {
			if (!$post instanceof WP_Post) {
				continue;
			}
			$post_id = (int) $post->ID;
			$post_title = (string) get_the_title($post_id);
			$seo_title = trim((string) get_post_meta($post_id, self::META_TITLE, true));
			$meta_desc = trim((string) get_post_meta($post_id, self::META_DESC, true));
			$schema = trim((string) get_post_meta($post_id, self::META_SCHEMA, true));
			$robots = trim((string) get_post_meta($post_id, self::META_ROBOTS, true));
			$edit_link = get_edit_post_link($post_id, 'raw');
			$view_link = get_permalink($post_id);

			$html .= '<tr data-post-id="' . esc_attr((string) $post_id) . '">';
			$html .= '<td><code>' . esc_html((string) $post_id) . '</code></td>';
			$html .= '<td><input type="checkbox" class="vite-seo-guard-row-check" name="post_ids[]" value="' . esc_attr((string) $post_id) . '" /></td>';
			$html .= '<td><strong>' . esc_html($post_title !== '' ? $post_title : ('#' . $post_id)) . '</strong></td>';
			$html .= '<td class="vite-seo-guard-col-seo-title">' . self::render_table_value($seo_title) . '</td>';
			$html .= '<td class="vite-seo-guard-col-meta-desc">' . self::render_table_value($meta_desc) . '</td>';
			$html .= '<td class="vite-seo-guard-col-schema">' . self::render_schema_preview($schema) . '</td>';
			$html .= '<td class="vite-seo-guard-col-robots">' . self::render_robots_value($robots) . '</td>';
			$html .= '<td>';
			$html .= '<button type="button" class="button-link vite-seo-guard-quick-edit" data-post-id="' . esc_attr((string) $post_id) . '">Quick Edit</button>';
			if ($edit_link) {
				$html .= ' | <a href="' . esc_url($edit_link) . '" target="_blank" rel="noopener noreferrer">Edit</a>';
			}
			if ($view_link) {
				$html .= ' | <a href="' . esc_url($view_link) . '" target="_blank" rel="noopener noreferrer">View</a>';
			}
			$html .= '</td>';
			$html .= '</tr>';
		}

		if ($html === '') {
			return '<tr><td colspan="8">No posts found.</td></tr>';
		}
		return $html;
	}

	private static function render_schema_preview(string $schema): string {
		if ($schema === '') {
			return '<span class="vite-seo-guard-empty">Empty</span>';
		}
		$schema_one_line = preg_replace('~\s+~', ' ', $schema);
		$short = mb_substr((string) $schema_one_line, 0, 120);
		if (mb_strlen((string) $schema_one_line) > 120) {
			$short .= '...';
		}
		return '<code>' . esc_html($short) . '</code>';
	}

	private static function render_robots_value(string $robots): string {
		$robots = self::sanitize_meta_robots($robots);
		if ($robots === '') {
			return '<span class="vite-seo-guard-empty">Default</span>';
		}
		return '<code>' . esc_html($robots) . '</code>';
	}

	private static function render_pagination(
		int $paged,
		int $total_pages,
		string $search = '',
		string $month = '',
		string $date_from = '',
		string $date_to = '',
		string $sort = 'date_desc'
	): string {
		if ($total_pages <= 1) {
			return '';
		}

		$prev_page = max(1, $paged - 1);
		$next_page = min($total_pages, $paged + 1);
		$base_url = admin_url('admin.php?page=' . self::TOOLS_PAGE_SLUG);
		$args_prev = ['paged' => $prev_page];
		$args_next = ['paged' => $next_page];
		if ($search !== '') {
			$args_prev['seo_guard_search'] = $search;
			$args_next['seo_guard_search'] = $search;
		}
		if ($month !== '') {
			$args_prev['seo_guard_month'] = $month;
			$args_next['seo_guard_month'] = $month;
		}
		if ($date_from !== '') {
			$args_prev['seo_guard_date_from'] = $date_from;
			$args_next['seo_guard_date_from'] = $date_from;
		}
		if ($date_to !== '') {
			$args_prev['seo_guard_date_to'] = $date_to;
			$args_next['seo_guard_date_to'] = $date_to;
		}
		if ($sort !== '' && $sort !== 'date_desc') {
			$args_prev['seo_guard_sort'] = $sort;
			$args_next['seo_guard_sort'] = $sort;
		}
		$prev_url = add_query_arg($args_prev, $base_url);
		$next_url = add_query_arg($args_next, $base_url);

		$html = '<div class="vite-seo-guard-card vite-seo-guard-pagination">';
		$html .= '<div><strong>Page ' . esc_html((string) $paged) . '</strong> of ' . esc_html((string) $total_pages) . '</div>';
		$html .= '<div class="vite-seo-guard-pagination__actions">';
		if ($paged > 1) {
			$html .= '<a class="button" href="' . esc_url($prev_url) . '">&larr; Previous</a>';
		}
		if ($paged < $total_pages) {
			$html .= '<a class="button button-primary" href="' . esc_url($next_url) . '">Next &rarr;</a>';
		}
		$html .= '</div></div>';
		return $html;
	}

	private static function render_docs_modal(): void {
		echo '<div id="vite-seo-guard-guide-modal" class="vite-seo-guard-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="vite-seo-guard-guide-title">';
		echo '<div class="vite-seo-guard-guide__panel">';
		echo '<div class="vite-seo-guard-guide__header">';
		echo '<strong id="vite-seo-guard-guide-title">SEO Guard Guide</strong>';
		echo '<button type="button" class="button" id="vite-seo-guard-close-guide" aria-label="Close guide">Close</button>';
		echo '</div>';
		echo '<div class="vite-seo-guard-guide__body">';
		echo '<p>SEO Guard helps your team manage core SEO fields for each blog post.</p>';
		echo '<h3>What this plugin does</h3>';
		echo '<ul>';
		echo '<li>Adds SEO fields in the post editor (SEO title, meta description, schema, robots).</li>';
		echo '<li>Uses those fields on the front-end for post SEO output.</li>';
		echo '<li>Provides this review table under SEO Tools so non-technical users can audit posts quickly.</li>';
		echo '</ul>';
		echo '<h3>Step-by-step</h3>';
		echo '<ol>';
		echo '<li>Open <strong>SEO Tools &gt; SEO Guard</strong>.</li>';
		echo '<li>Use filters to review data your way: title search, month, date range, and sort by date/ID/title.</li>';
		echo '<li>Review the SEO fields row by row (Post ID is shown in the first column for easier reference).</li>';
		echo '<li>Use <strong>Quick Edit</strong> for one post, or <strong>Quick Edit Selected</strong> to load each selected post with its own existing values and save them together.</li>';
		echo '<li>Default view is paginated by 25 posts. Month/range filters show all matching results in one table.</li>';
		echo '</ol>';
		echo '<h3>Table notes</h3>';
		echo '<ul>';
		echo '<li><strong>Empty</strong> means the field has not been saved for that post.</li>';
		echo '<li><strong>Default</strong> under Robots means no custom robots value was set.</li>';
		echo '<li>Schema is previewed in short form to keep the page fast.</li>';
		echo '</ul>';
		echo '</div>';
		echo '</div>';
		echo '</div>';

		echo '<script>
		(function () {
			document.addEventListener("DOMContentLoaded", function () {
				var openBtn = document.getElementById("vite-seo-guard-open-guide");
				var closeBtn = document.getElementById("vite-seo-guard-close-guide");
				var modal = document.getElementById("vite-seo-guard-guide-modal");
				if (!openBtn || !closeBtn || !modal) return;
				function openGuide() { modal.hidden = false; modal.setAttribute("aria-hidden", "false"); }
				function closeGuide() { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); }
				openBtn.addEventListener("click", openGuide);
				closeBtn.addEventListener("click", closeGuide);
				modal.addEventListener("click", function (event) { if (event.target === modal) closeGuide(); });
				document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !modal.hidden) closeGuide(); });
			});
		})();
		</script>';
	}

	private static function render_bulk_quick_edit_modal(): void {
		$nonce = wp_create_nonce('vite_seo_guard_quick_edit');
		echo '<div id="vite-seo-guard-bulk-edit-modal" class="vite-seo-guard-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="vite-seo-guard-bulk-edit-title">';
		echo '<div class="vite-seo-guard-guide__panel">';
		echo '<div class="vite-seo-guard-guide__header">';
		echo '<strong id="vite-seo-guard-bulk-edit-title">Bulk Quick Edit SEO Fields</strong>';
		echo '<button type="button" class="button" id="vite-seo-guard-bulk-edit-close" aria-label="Close bulk quick edit">Close</button>';
		echo '</div>';
		echo '<div class="vite-seo-guard-guide__body">';
		echo '<div id="vite-seo-guard-bulk-edit-status" class="vite-seo-guard-quick-edit-status" aria-live="polite"></div>';
		echo '<form id="vite-seo-guard-bulk-edit-form">';
		echo '<input type="hidden" id="vite-seo-guard-bulk-edit-post-ids" value="" />';
		echo '<p class="description" id="vite-seo-guard-bulk-edit-count">No posts selected.</p>';
		echo '<div id="vite-seo-guard-bulk-edit-list" class="vite-seo-guard-bulk-list"></div>';
		echo '<p class="vite-seo-guard-quick-edit-actions">';
		echo '<button type="submit" class="button button-primary" id="vite-seo-guard-bulk-edit-save">Save All Selected</button>';
		echo '<button type="button" class="button" id="vite-seo-guard-bulk-edit-cancel">Cancel</button>';
		echo '</p>';
		echo '</form>';
		echo '</div></div></div>';

		echo '<script>
		(function () {
			document.addEventListener("DOMContentLoaded", function () {
				var nonce = ' . wp_json_encode($nonce) . ';
				var modal = document.getElementById("vite-seo-guard-bulk-edit-modal");
				var openBtn = document.getElementById("vite-seo-guard-bulk-edit-open");
				var closeBtn = document.getElementById("vite-seo-guard-bulk-edit-close");
				var cancelBtn = document.getElementById("vite-seo-guard-bulk-edit-cancel");
				var form = document.getElementById("vite-seo-guard-bulk-edit-form");
				var statusBox = document.getElementById("vite-seo-guard-bulk-edit-status");
				var countBox = document.getElementById("vite-seo-guard-bulk-edit-count");
				var idsInput = document.getElementById("vite-seo-guard-bulk-edit-post-ids");
				var listBox = document.getElementById("vite-seo-guard-bulk-edit-list");
				var saveBtn = document.getElementById("vite-seo-guard-bulk-edit-save");
				if (!modal || !openBtn || !form || !statusBox || !countBox || !idsInput || !listBox || !saveBtn) return;

				function setStatus(message, kind) {
					statusBox.textContent = message || "";
					statusBox.className = "vite-seo-guard-quick-edit-status";
					if (kind) statusBox.classList.add("is-" + kind);
				}
				function openModal() { modal.hidden = false; modal.setAttribute("aria-hidden", "false"); }
				function closeModal() { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); }
				function escapeHtml(value) {
					return String(value || "").replace(/[&<>"\u0027]/g, function (ch) {
						switch (ch) {
							case "&": return "&amp;";
							case "<": return "&lt;";
							case ">": return "&gt;";
							case "\"": return "&quot;";
							case "\u0027": return "&#039;";
							default: return ch;
						}
					});
				}
				function selectedIds() {
					return Array.prototype.slice.call(document.querySelectorAll(".vite-seo-guard-row-check:checked")).map(function (cb) { return cb.value; }).filter(Boolean);
				}
				function robotOptions(selected) {
					var options = [
						{ value: "", label: "Default (empty)" },
						{ value: "index,follow", label: "index,follow" },
						{ value: "noindex,follow", label: "noindex,follow" },
						{ value: "index,nofollow", label: "index,nofollow" },
						{ value: "noindex,nofollow", label: "noindex,nofollow" }
					];
					return options.map(function (opt) {
						var isSelected = String(selected || "") === opt.value ? " selected" : "";
						return "<option value=\"" + escapeHtml(opt.value) + "\"" + isSelected + ">" + escapeHtml(opt.label) + "</option>";
					}).join("");
				}
				function renderRows(rows) {
					listBox.innerHTML = rows.map(function (row) {
						return "<div class=\"vite-seo-guard-bulk-item\" data-post-id=\"" + escapeHtml(row.post_id) + "\">"
							+ "<h3>" + escapeHtml(row.title || ("#" + row.post_id)) + "</h3>"
							+ "<p><label><strong>SEO Title</strong></label><br /><input type=\"text\" class=\"large-text vite-seo-guard-bulk-field\" data-field=\"seo_title\" value=\"" + escapeHtml(row.seo_title || "") + "\" /></p>"
							+ "<p><label><strong>Meta Description</strong></label><br /><textarea rows=\"3\" class=\"large-text vite-seo-guard-bulk-field\" data-field=\"meta_description\">" + escapeHtml(row.meta_description || "") + "</textarea></p>"
							+ "<p><label><strong>Schema JSON-LD</strong></label><br /><textarea rows=\"5\" class=\"large-text code vite-seo-guard-bulk-field\" data-field=\"schema\">" + escapeHtml(row.schema || "") + "</textarea></p>"
							+ "<p><label><strong>Robots</strong></label><br /><select class=\"vite-seo-guard-bulk-field\" data-field=\"robots\">" + robotOptions(row.robots || "") + "</select></p>"
							+ "</div>";
					}).join("");
				}
				function collectRows() {
					return Array.prototype.slice.call(listBox.querySelectorAll(".vite-seo-guard-bulk-item")).map(function (item) {
						var postId = item.getAttribute("data-post-id");
						var fields = {};
						item.querySelectorAll(".vite-seo-guard-bulk-field").forEach(function (input) {
							var field = input.getAttribute("data-field");
							fields[field] = input.value || "";
						});
						return {
							post_id: postId,
							seo_title: fields.seo_title || "",
							meta_description: fields.meta_description || "",
							schema: fields.schema || "",
							robots: fields.robots || ""
						};
					});
				}
				function postAjax(payload) {
					return fetch(ajaxurl, {
						method: "POST",
						headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
						body: new URLSearchParams(payload)
					}).then(function (r) { return r.json(); });
				}

				openBtn.addEventListener("click", function () {
					var ids = selectedIds();
					if (!ids.length) {
						window.alert("Select at least one post first.");
						return;
					}
					idsInput.value = ids.join(",");
					countBox.textContent = "Selected posts: " + ids.length;
					setStatus("Loading selected posts...", "info");
					openModal();
					saveBtn.disabled = true;
					postAjax({
						action: "vite_seo_guard_bulk_get",
						nonce: nonce,
						post_ids: ids.join(",")
					}).then(function (res) {
						if (!res || !res.success || !res.data || !Array.isArray(res.data.rows)) {
							throw new Error((res && res.data && res.data.message) ? res.data.message : "Could not load selected post values.");
						}
						renderRows(res.data.rows);
						setStatus("Loaded. Edit each post one by one, then click Save All Selected.", "success");
					}).catch(function (err) {
						listBox.innerHTML = "";
						setStatus(err.message || "Could not load selected post values.", "error");
					}).finally(function () {
						saveBtn.disabled = false;
					});
				});

				form.addEventListener("submit", function (event) {
					event.preventDefault();
					var rows = collectRows();
					if (!rows.length) {
						setStatus("No posts selected.", "error");
						return;
					}
					setStatus("Applying updates to selected posts...", "info");
					saveBtn.disabled = true;
					postAjax({
						action: "vite_seo_guard_bulk_save",
						nonce: nonce,
						rows_json: JSON.stringify(rows)
					}).then(function (res) {
						if (!res || !res.success || !res.data) {
							throw new Error((res && res.data && res.data.message) ? res.data.message : "Bulk update failed.");
						}
						var updatedRows = Array.isArray(res.data.updated_rows) ? res.data.updated_rows : [];
						updatedRows.forEach(function (updatedRow) {
							var row = document.querySelector("tr[data-post-id=\"" + updatedRow.post_id + "\"]");
							if (!row) return;
							if (updatedRow.seo_title_html !== undefined) {
								var seoCell = row.querySelector(".vite-seo-guard-col-seo-title");
								if (seoCell) seoCell.innerHTML = updatedRow.seo_title_html;
							}
							if (updatedRow.meta_description_html !== undefined) {
								var descCell = row.querySelector(".vite-seo-guard-col-meta-desc");
								if (descCell) descCell.innerHTML = updatedRow.meta_description_html;
							}
							if (updatedRow.schema_html !== undefined) {
								var schemaCell = row.querySelector(".vite-seo-guard-col-schema");
								if (schemaCell) schemaCell.innerHTML = updatedRow.schema_html;
							}
							if (updatedRow.robots_html !== undefined) {
								var robotsCell = row.querySelector(".vite-seo-guard-col-robots");
								if (robotsCell) robotsCell.innerHTML = updatedRow.robots_html;
							}
						});
						setStatus("Bulk quick edit saved for " + updatedRows.length + " post(s).", "success");
					}).catch(function (err) {
						setStatus(err.message || "Bulk update failed.", "error");
					}).finally(function () {
						saveBtn.disabled = false;
					});
				});

				[closeBtn, cancelBtn].forEach(function (btn) {
					if (!btn) return;
					btn.addEventListener("click", closeModal);
				});
				modal.addEventListener("click", function (event) { if (event.target === modal) closeModal(); });
				document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !modal.hidden) closeModal(); });
			});
		})();
		</script>';
	}

	private static function render_quick_edit_modal(): void {
		$nonce = wp_create_nonce('vite_seo_guard_quick_edit');
		echo '<div id="vite-seo-guard-quick-edit-modal" class="vite-seo-guard-guide-modal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="vite-seo-guard-quick-edit-title">';
		echo '<div class="vite-seo-guard-guide__panel">';
		echo '<div class="vite-seo-guard-guide__header">';
		echo '<strong id="vite-seo-guard-quick-edit-title">Quick Edit SEO Fields</strong>';
		echo '<button type="button" class="button" id="vite-seo-guard-quick-edit-close" aria-label="Close quick edit">Close</button>';
		echo '</div>';
		echo '<div class="vite-seo-guard-guide__body">';
		echo '<div id="vite-seo-guard-quick-edit-status" class="vite-seo-guard-quick-edit-status" aria-live="polite"></div>';
		echo '<form id="vite-seo-guard-quick-edit-form">';
		echo '<input type="hidden" id="vite-seo-guard-quick-edit-post-id" />';
		echo '<p><label for="vite-seo-guard-quick-edit-seo-title"><strong>SEO Title</strong></label><br />';
		echo '<input type="text" class="regular-text" id="vite-seo-guard-quick-edit-seo-title" /></p>';
		echo '<p><label for="vite-seo-guard-quick-edit-meta-desc"><strong>Meta Description</strong></label><br />';
		echo '<textarea class="large-text" rows="3" id="vite-seo-guard-quick-edit-meta-desc"></textarea></p>';
		echo '<p><label for="vite-seo-guard-quick-edit-schema"><strong>Schema JSON-LD</strong></label><br />';
		echo '<textarea class="large-text code" rows="7" id="vite-seo-guard-quick-edit-schema"></textarea></p>';
		echo '<p><label for="vite-seo-guard-quick-edit-robots"><strong>Robots</strong></label><br />';
		echo '<select id="vite-seo-guard-quick-edit-robots">';
		echo '<option value="">Default (empty)</option>';
		echo '<option value="index,follow">index,follow</option>';
		echo '<option value="noindex,follow">noindex,follow</option>';
		echo '<option value="index,nofollow">index,nofollow</option>';
		echo '<option value="noindex,nofollow">noindex,nofollow</option>';
		echo '</select></p>';
		echo '<p class="vite-seo-guard-quick-edit-actions">';
		echo '<button type="submit" class="button button-primary" id="vite-seo-guard-quick-edit-save">Save</button>';
		echo '<button type="button" class="button" id="vite-seo-guard-quick-edit-cancel">Cancel</button>';
		echo '</p>';
		echo '</form>';
		echo '</div></div></div>';

		echo '<script>
		(function () {
			document.addEventListener("DOMContentLoaded", function () {
				var nonce = ' . wp_json_encode($nonce) . ';
				var modal = document.getElementById("vite-seo-guard-quick-edit-modal");
				var closeBtn = document.getElementById("vite-seo-guard-quick-edit-close");
				var cancelBtn = document.getElementById("vite-seo-guard-quick-edit-cancel");
				var form = document.getElementById("vite-seo-guard-quick-edit-form");
				var statusBox = document.getElementById("vite-seo-guard-quick-edit-status");
				var idInput = document.getElementById("vite-seo-guard-quick-edit-post-id");
				var seoTitleInput = document.getElementById("vite-seo-guard-quick-edit-seo-title");
				var metaDescInput = document.getElementById("vite-seo-guard-quick-edit-meta-desc");
				var schemaInput = document.getElementById("vite-seo-guard-quick-edit-schema");
				var robotsInput = document.getElementById("vite-seo-guard-quick-edit-robots");
				var saveBtn = document.getElementById("vite-seo-guard-quick-edit-save");
				if (!modal || !form || !statusBox || !idInput || !seoTitleInput || !metaDescInput || !schemaInput || !robotsInput || !saveBtn) return;

				function setStatus(message, kind) {
					statusBox.textContent = message || "";
					statusBox.className = "vite-seo-guard-quick-edit-status";
					if (kind) statusBox.classList.add("is-" + kind);
				}
				function openModal() { modal.hidden = false; modal.setAttribute("aria-hidden", "false"); }
				function closeModal() { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); }
				function postAjax(payload) {
					return fetch(ajaxurl, {
						method: "POST",
						headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
						body: new URLSearchParams(payload)
					}).then(function (r) { return r.json(); });
				}
				function openQuickEditForPost(postId) {
					if (!postId) return;
					idInput.value = String(postId);
					setStatus("Loading current values...", "info");
					saveBtn.disabled = true;
					openModal();
					postAjax({
						action: "vite_seo_guard_get_row",
						nonce: nonce,
						post_id: String(postId)
					}).then(function (res) {
						if (!res || !res.success || !res.data) {
							throw new Error((res && res.data && res.data.message) ? res.data.message : "Could not load post values.");
						}
						seoTitleInput.value = res.data.seo_title || "";
						metaDescInput.value = res.data.meta_description || "";
						schemaInput.value = res.data.schema || "";
						robotsInput.value = res.data.robots || "";
						setStatus("Loaded current values. You can now edit and save.", "success");
					}).catch(function (err) {
						setStatus(err.message || "Could not load post values.", "error");
					}).finally(function () {
						saveBtn.disabled = false;
					});
				}

				document.addEventListener("click", function (event) {
					var btn = event.target && event.target.closest ? event.target.closest(".vite-seo-guard-quick-edit") : null;
					if (!btn) return;
					var postId = btn.getAttribute("data-post-id");
					openQuickEditForPost(postId);
				});

				(function openFromQuery() {
					try {
						var params = new URLSearchParams(window.location.search || "");
						var quickId = params.get("quick_edit_post");
						if (!quickId) return;
						openQuickEditForPost(quickId);
					} catch (e) {}
				})();

				form.addEventListener("submit", function (event) {
					event.preventDefault();
					var postId = idInput.value;
					if (!postId) return;
					setStatus("Saving changes...", "info");
					saveBtn.disabled = true;
					postAjax({
						action: "vite_seo_guard_save_row",
						nonce: nonce,
						post_id: postId,
						seo_title: seoTitleInput.value,
						meta_description: metaDescInput.value,
						schema: schemaInput.value,
						robots: robotsInput.value
					}).then(function (res) {
						if (!res || !res.success || !res.data) {
							throw new Error((res && res.data && res.data.message) ? res.data.message : "Save failed.");
						}
						var row = document.querySelector("tr[data-post-id=\"" + postId + "\"]");
						if (row) {
							var seoCell = row.querySelector(".vite-seo-guard-col-seo-title");
							var descCell = row.querySelector(".vite-seo-guard-col-meta-desc");
							var schemaCell = row.querySelector(".vite-seo-guard-col-schema");
							var robotsCell = row.querySelector(".vite-seo-guard-col-robots");
							if (seoCell) seoCell.innerHTML = res.data.seo_title_html || "";
							if (descCell) descCell.innerHTML = res.data.meta_description_html || "";
							if (schemaCell) schemaCell.innerHTML = res.data.schema_html || "";
							if (robotsCell) robotsCell.innerHTML = res.data.robots_html || "";
						}
						setStatus("Saved successfully.", "success");
					}).catch(function (err) {
						setStatus(err.message || "Save failed.", "error");
					}).finally(function () {
						saveBtn.disabled = false;
					});
				});

				[closeBtn, cancelBtn].forEach(function (btn) {
					if (!btn) return;
					btn.addEventListener("click", closeModal);
				});
				modal.addEventListener("click", function (event) { if (event.target === modal) closeModal(); });
				document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !modal.hidden) closeModal(); });
			});
		})();
		</script>';
	}

	public static function ajax_get_row(): void {
		check_ajax_referer('vite_seo_guard_quick_edit', 'nonce');
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		$post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
		$post = $post_id > 0 ? get_post($post_id) : null;
		if (!$post instanceof WP_Post || $post->post_type !== 'post') {
			wp_send_json_error(['message' => 'Post not found.'], 404);
		}
		if (!current_user_can('edit_post', $post_id)) {
			wp_send_json_error(['message' => 'You do not have permission to edit this post.'], 403);
		}

		wp_send_json_success([
			'seo_title' => trim((string) get_post_meta($post_id, self::META_TITLE, true)),
			'meta_description' => trim((string) get_post_meta($post_id, self::META_DESC, true)),
			'schema' => trim((string) get_post_meta($post_id, self::META_SCHEMA, true)),
			'robots' => trim((string) get_post_meta($post_id, self::META_ROBOTS, true)),
		]);
	}

	public static function ajax_live_search(): void {
		check_ajax_referer('vite_seo_guard_live_search', 'nonce');
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		$search = isset($_POST['search']) ? sanitize_text_field((string) wp_unslash($_POST['search'])) : '';
		$month = isset($_POST['month']) ? self::sanitize_month_filter((string) wp_unslash($_POST['month'])) : '';
		$date_from = isset($_POST['date_from']) ? self::sanitize_date_filter((string) wp_unslash($_POST['date_from'])) : '';
		$date_to = isset($_POST['date_to']) ? self::sanitize_date_filter((string) wp_unslash($_POST['date_to'])) : '';
		$sort = isset($_POST['sort']) ? self::sanitize_sort_filter((string) wp_unslash($_POST['sort'])) : 'date_desc';
		$query = new WP_Query(self::build_query_args($search, 1, $month, $date_from, $date_to, $sort));

		$total_items = (int) $query->found_posts;
		$start_num = $total_items > 0 ? 1 : 0;
		$end_num = ($month !== '' || $date_from !== '' || $date_to !== '')
			? $total_items
			: min($total_items, self::TOOLS_PER_PAGE);

		wp_send_json_success([
			'rows_html' => self::render_table_rows($query->posts),
			'total_items' => $total_items,
			'start_num' => $start_num,
			'end_num' => $end_num,
			'search' => $search,
			'search_label' => esc_html($search),
		]);
	}

	public static function ajax_save_row(): void {
		check_ajax_referer('vite_seo_guard_quick_edit', 'nonce');
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		$post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
		$post = $post_id > 0 ? get_post($post_id) : null;
		if (!$post instanceof WP_Post || $post->post_type !== 'post') {
			wp_send_json_error(['message' => 'Post not found.'], 404);
		}
		if (!current_user_can('edit_post', $post_id)) {
			wp_send_json_error(['message' => 'You do not have permission to edit this post.'], 403);
		}

		$seo_title = isset($_POST['seo_title']) ? sanitize_text_field((string) wp_unslash($_POST['seo_title'])) : '';
		$meta_description = isset($_POST['meta_description']) ? sanitize_textarea_field((string) wp_unslash($_POST['meta_description'])) : '';
		$schema_raw = isset($_POST['schema']) ? (string) wp_unslash($_POST['schema']) : '';
		$schema_norm = self::normalize_schema_json($schema_raw);
		if (!$schema_norm['ok']) {
			wp_send_json_error(['message' => (string) ($schema_norm['message'] ?? 'Invalid schema JSON-LD.')], 400);
		}
		$schema = (string) $schema_norm['json'];
		$robots = isset($_POST['robots']) ? self::sanitize_meta_robots((string) wp_unslash($_POST['robots'])) : '';

		if ($seo_title === '') {
			delete_post_meta($post_id, self::META_TITLE);
		} else {
			update_post_meta($post_id, self::META_TITLE, $seo_title);
		}
		if ($meta_description === '') {
			delete_post_meta($post_id, self::META_DESC);
		} else {
			update_post_meta($post_id, self::META_DESC, $meta_description);
		}
		if ($schema === '') {
			delete_post_meta($post_id, self::META_SCHEMA);
		} else {
			update_post_meta($post_id, self::META_SCHEMA, $schema);
		}
		if ($robots === '') {
			delete_post_meta($post_id, self::META_ROBOTS);
		} else {
			update_post_meta($post_id, self::META_ROBOTS, $robots);
		}

		wp_send_json_success([
			'seo_title_html' => self::render_table_value($seo_title),
			'meta_description_html' => self::render_table_value($meta_description),
			'schema_html' => self::render_schema_preview($schema),
			'robots_html' => self::render_robots_value($robots),
		]);
	}

	public static function ajax_bulk_get(): void {
		check_ajax_referer('vite_seo_guard_quick_edit', 'nonce');
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		$raw_ids = isset($_POST['post_ids']) ? (string) wp_unslash($_POST['post_ids']) : '';
		$post_ids = array_values(array_unique(array_filter(array_map('intval', explode(',', $raw_ids)))));
		if (!$post_ids) {
			wp_send_json_error(['message' => 'No posts selected.'], 400);
		}

		$rows = [];
		foreach ($post_ids as $post_id) {
			$post = get_post($post_id);
			if (!$post instanceof WP_Post || $post->post_type !== 'post') {
				continue;
			}
			if (!current_user_can('edit_post', $post_id)) {
				continue;
			}
			$rows[] = [
				'post_id' => $post_id,
				'title' => (string) get_the_title($post_id),
				'seo_title' => trim((string) get_post_meta($post_id, self::META_TITLE, true)),
				'meta_description' => trim((string) get_post_meta($post_id, self::META_DESC, true)),
				'schema' => trim((string) get_post_meta($post_id, self::META_SCHEMA, true)),
				'robots' => trim((string) get_post_meta($post_id, self::META_ROBOTS, true)),
			];
		}

		if (!$rows) {
			wp_send_json_error(['message' => 'No editable posts found in the selection.'], 400);
		}

		wp_send_json_success(['rows' => $rows]);
	}

	public static function ajax_bulk_save(): void {
		check_ajax_referer('vite_seo_guard_quick_edit', 'nonce');
		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Forbidden'], 403);
		}

		$rows_json = isset($_POST['rows_json']) ? (string) wp_unslash($_POST['rows_json']) : '';
		if ($rows_json === '') {
			wp_send_json_error(['message' => 'No rows submitted.'], 400);
		}
		$rows = json_decode($rows_json, true);
		if (!is_array($rows) || !$rows) {
			wp_send_json_error(['message' => 'Invalid bulk payload.'], 400);
		}

		$updated_rows = [];
		foreach ($rows as $row) {
			$post_id = isset($row['post_id']) ? (int) $row['post_id'] : 0;
			if ($post_id <= 0) {
				continue;
			}
			$post = get_post($post_id);
			if (!$post instanceof WP_Post || $post->post_type !== 'post') {
				continue;
			}
			if (!current_user_can('edit_post', $post_id)) {
				continue;
			}

			$seo_title = isset($row['seo_title']) ? sanitize_text_field((string) $row['seo_title']) : '';
			$meta_description = isset($row['meta_description']) ? sanitize_textarea_field((string) $row['meta_description']) : '';
			$schema_raw = isset($row['schema']) ? (string) $row['schema'] : '';
			$schema_norm = self::normalize_schema_json($schema_raw);
			if (!$schema_norm['ok']) {
				continue;
			}
			$schema = (string) $schema_norm['json'];
			$robots = isset($row['robots']) ? self::sanitize_meta_robots((string) $row['robots']) : '';

			if ($seo_title === '') {
				delete_post_meta($post_id, self::META_TITLE);
			} else {
				update_post_meta($post_id, self::META_TITLE, $seo_title);
			}
			if ($meta_description === '') {
				delete_post_meta($post_id, self::META_DESC);
			} else {
				update_post_meta($post_id, self::META_DESC, $meta_description);
			}
			if ($schema === '') {
				delete_post_meta($post_id, self::META_SCHEMA);
			} else {
				update_post_meta($post_id, self::META_SCHEMA, $schema);
			}
			if ($robots === '') {
				delete_post_meta($post_id, self::META_ROBOTS);
			} else {
				update_post_meta($post_id, self::META_ROBOTS, $robots);
			}

			$updated_rows[] = [
				'post_id' => $post_id,
				'seo_title_html' => self::render_table_value($seo_title),
				'meta_description_html' => self::render_table_value($meta_description),
				'schema_html' => self::render_schema_preview($schema),
				'robots_html' => self::render_robots_value($robots),
			];
		}

		if (!$updated_rows) {
			wp_send_json_error(['message' => 'No posts were updated.'], 400);
		}

		wp_send_json_success(['updated_rows' => $updated_rows]);
	}

	public static function handle_download_selected(): void {
		if (!current_user_can('edit_posts')) {
			wp_die('Forbidden');
		}
		check_admin_referer('vite_seo_guard_download_selected');

		$raw_ids = isset($_POST['post_ids']) && is_array($_POST['post_ids']) ? $_POST['post_ids'] : [];
		$post_ids = array_values(array_unique(array_filter(array_map('intval', $raw_ids))));
		if (!$post_ids) {
			wp_die('No posts selected. Please select at least one post.');
		}

		$posts = get_posts([
			'post_type' => 'post',
			'post_status' => 'any',
			'numberposts' => count($post_ids),
			'post__in' => $post_ids,
			'orderby' => 'post__in',
		]);

		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="seo-guard-selected-' . gmdate('Ymd-His') . '.csv"');
		$out = fopen('php://output', 'w');
		if ($out === false) {
			wp_die('Could not generate CSV.');
		}

		fputcsv($out, ['POST_ID', 'POST_TITLE', 'PERMALINK', 'SEO_TITLE', 'META_DESCRIPTION', 'SCHEMA_JSONLD', 'ROBOTS']);
		foreach ($posts as $post) {
			if (!$post instanceof WP_Post) {
				continue;
			}
			$post_id = (int) $post->ID;
			fputcsv($out, [
				$post_id,
				(string) $post->post_title,
				(string) get_permalink($post_id),
				(string) get_post_meta($post_id, self::META_TITLE, true),
				(string) get_post_meta($post_id, self::META_DESC, true),
				(string) get_post_meta($post_id, self::META_SCHEMA, true),
				(string) get_post_meta($post_id, self::META_ROBOTS, true),
			]);
		}

		fclose($out);
		exit;
	}

	private static function render_admin_styles(): void {
		echo '<style>
		.vite-seo-guard-page { max-width: none; width: 95%; }
		.vite-seo-guard-page__header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom: 12px; flex-wrap: wrap; }
		.vite-seo-guard-card { background:#fff; border:1px solid #dcdcde; border-radius:10px; box-shadow:0 1px 2px rgba(16,24,40,.04); padding:16px 18px; margin:0 0 14px; }
		.vite-seo-guard-card p { margin: 8px 0; line-height: 1.55; }
		.vite-seo-guard-overview-header { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:10px; }
		.vite-seo-guard-guide-btn { background:#ffcc00 !important; border-color:#d6a800 !important; color:#1d2327 !important; }
		.vite-seo-guard-guide-btn:hover,
		.vite-seo-guard-guide-btn:focus { background:#f0bf00 !important; border-color:#bf9600 !important; color:#1d2327 !important; }
		.vite-seo-guard-search-form { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:8px 0 10px; }
		.vite-seo-guard-search-input { min-width:300px; max-width:100%; }
		.vite-seo-guard-search-form input[type="month"],
		.vite-seo-guard-search-form input[type="date"],
		.vite-seo-guard-search-form select { min-width: 150px; }
		.vite-seo-guard-bulk-form { margin:0; }
		.vite-seo-guard-bulk-actions { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin:0 0 10px; }
		.vite-seo-guard-table th { font-weight:600; }
		.vite-seo-guard-table td { vertical-align: top; line-height: 1.5; }
		.vite-seo-guard-empty { color:#6c7781; font-style: italic; }
		.vite-seo-guard-pagination { display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap: wrap; }
		.vite-seo-guard-pagination__actions { display:flex; gap:8px; align-items:center; }
		#vite-seo-guard-guide-modal[hidden],
		#vite-seo-guard-quick-edit-modal[hidden],
		#vite-seo-guard-bulk-edit-modal[hidden] { display:none !important; }
		.vite-seo-guard-guide-modal { position:fixed; inset:0; z-index:100000; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; padding:20px; }
		.vite-seo-guard-guide__panel { width:min(960px, calc(100vw - 24px)); max-height:86vh; overflow:auto; background:#fff; border-radius:10px; box-shadow:0 16px 38px rgba(0,0,0,.18); }
		.vite-seo-guard-guide__header { position:sticky; top:0; background:#fff; border-bottom:1px solid #dcdcde; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; gap:12px; }
		.vite-seo-guard-guide__body { padding:16px; }
		.vite-seo-guard-guide__body h3 { margin:18px 0 8px; }
		.vite-seo-guard-guide__body p { margin:8px 0; line-height:1.5; }
		.vite-seo-guard-guide__body ul, .vite-seo-guard-guide__body ol { margin:8px 0 10px 18px; }
		.vite-seo-guard-bulk-list { display:grid; grid-template-columns:1fr; gap:12px; margin:10px 0 12px; }
		.vite-seo-guard-bulk-item { border:1px solid #dcdcde; border-radius:8px; padding:12px; background:#fcfcfd; }
		.vite-seo-guard-bulk-item h3 { margin:0 0 8px; font-size:14px; line-height:1.4; }
		.vite-seo-guard-quick-edit-actions { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
		.vite-seo-guard-quick-edit-status { margin:0 0 10px; padding:8px 10px; border-radius:6px; background:#f6f7f7; color:#1d2327; display:none; }
		.vite-seo-guard-quick-edit-status.is-info,
		.vite-seo-guard-quick-edit-status.is-success,
		.vite-seo-guard-quick-edit-status.is-error { display:block; }
		.vite-seo-guard-quick-edit-status.is-info { background:#eef4ff; color:#1e3a8a; }
		.vite-seo-guard-quick-edit-status.is-success { background:#edfaef; color:#0f6f2e; }
		.vite-seo-guard-quick-edit-status.is-error { background:#fdecec; color:#9f2626; }
		</style>';
	}
}

Vite_SEO_Guard::init();
